import { defineConfig } from "vitest/config";
import base from "../vitest.config";

const baseTest = base.test ?? {};
const setupFiles =
  typeof baseTest.setupFiles === "string" ? [baseTest.setupFiles] : (baseTest.setupFiles ?? []);

export default defineConfig({
  ...base,
  envDir: false,
  test: {
    ...baseTest,
    setupFiles: [
      ...setupFiles,
      ".runtime/calendar-existing-edit-atomicity-draft/existingEditAtomicity.setup.ts",
    ],
    env: {
      NODE_ENV: "test",
      // Real fixture clients use provided testPg; an accidental global DB use fails closed.
      DATABASE_URL: "postgres://synthetic:synthetic@127.0.0.1:1/calendar_global_unused",
      BASE_URL: "https://calendar-test.example.invalid",
      GOOGLE_CALENDAR_OAUTH_CLIENT_ID: "",
      GOOGLE_CALENDAR_OAUTH_CLIENT_SECRET: "",
      AUTH_MAIL_TRANSPORT: "capture",
      AUTH_SMTP_HOST: "",
    },
    maxWorkers: 1,
    fileParallelism: false,
    testNamePattern:
      /^(?:keeps a raw old-writer activity legacy while consuming its rebuild without native policy or intent activation|persists intent ownership for a new native calendar event with explicit personal notification rules|persists intent ownership and automatic-reminder suppression across a later rebuild|fires a notification for an open activity and skips a completed one|inserts no notification for a done activity \(done-skip guard\)|targets the activity's parent deal, not the activity id|leaves the target null for a parentless activity rather than pointing at the activity|does not lose a default change racing initial assignment bootstrap reconciliation|consumes direct legacy rebuilds without adopting reminders on date or assignee changes|replaces reminders for intent-owned direct writes while respecting automatic reminder suppression|rebuilds inherited default changes in bounded batches without losing a later activity)$/,
    projects: [
      {
        extends: true,
        test: {
          name: "integration",
          include: [
            ".runtime/calendar-reminder-engine-candidate/engineOwnership.integration.test.ts",
            "src/features/activities/reminders.test.ts",
            "src/features/activities/reminderDefaultsConcurrency.integration.test.ts",
            "src/features/activities/reminderRebuild.integration.test.ts",
          ],
          globalSetup: [
            ".runtime/calendar-existing-edit-atomicity-draft/existingEditAtomicity.globalSetup.ts",
          ],
        },
      },
    ],
  },
});
