import { eq } from "drizzle-orm";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import {
  activityReminderIntents,
  activityReminderSettings,
  activityTypes,
  reminderRebuilds,
} from "@/db/schema";
import { seedUser } from "@/db/testing/factories";
import { createCalendar } from "@/features/activities/calendars";
import type { PermSetUser } from "@/features/permissions/effective";
import { makeTestDb, type TestDb } from "@/test/db";

export interface EngineActivity {
  id: string;
  reminder_engine: "legacy" | "intent";
  reminder_automation_enabled: boolean;
  calendar_id: string | null;
  due_at: Date | null;
}

export async function engineFixture(signal: AbortSignal) {
  signal.throwIfAborted();
  const ctx = await makeTestDb();
  try {
    signal.throwIfAborted();
    const owner = await seedUser(ctx.db, { name: "Engine owner", isAdmin: true });
    signal.throwIfAborted();
    const actor: PermSetUser = {
      id: owner.id,
      type: "admin",
      isActive: true,
      groupIds: new Set(),
      flags: new Set(),
    };
    const [type] = await ctx.db
      .select()
      .from(activityTypes)
      .where(eq(activityTypes.key, "meeting"));
    signal.throwIfAborted();
    if (type === undefined)
      throw new AppError(ERROR_IDS.DB_INVARIANT, "engine meeting seed absent");
    const calendar = await createCalendar(
      ctx.db,
      actor,
      {
        name: "Engine candidate",
        timeZone: "Asia/Tehran",
      },
      signal,
    );
    signal.throwIfAborted();
    if (!calendar.ok) throw calendar.error;
    return {
      ctx,
      actor,
      calendarId: calendar.value.id,
      typeId: type.id,
      dueAt: new Date(Date.now() + 24 * 60 * 60_000).toISOString(),
    };
  } catch (error) {
    await ctx.close();
    throw error;
  }
}

export type EngineFixture = Awaited<ReturnType<typeof engineFixture>>;

export async function engineActivity(ctx: TestDb, id: string, signal: AbortSignal) {
  signal.throwIfAborted();
  const result = await ctx.pool.query<EngineActivity>(
    `SELECT id, reminder_engine,
    reminder_automation_enabled, calendar_id, due_at FROM activities WHERE id=$1`,
    [id],
  );
  signal.throwIfAborted();
  const row = result.rows[0];
  if (row === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "engine activity readback absent");
  return row;
}

export async function reminderState(ctx: TestDb, id: string, signal: AbortSignal) {
  signal.throwIfAborted();
  const [settings, intents, rebuilds] = await Promise.all([
    ctx.db
      .select()
      .from(activityReminderSettings)
      .where(eq(activityReminderSettings.activityId, id))
      .orderBy(activityReminderSettings.id),
    ctx.db
      .select()
      .from(activityReminderIntents)
      .where(eq(activityReminderIntents.activityId, id))
      .orderBy(activityReminderIntents.id),
    ctx.db.select().from(reminderRebuilds).where(eq(reminderRebuilds.activityId, id)),
  ]);
  signal.throwIfAborted();
  return { settings, intents, rebuilds };
}
