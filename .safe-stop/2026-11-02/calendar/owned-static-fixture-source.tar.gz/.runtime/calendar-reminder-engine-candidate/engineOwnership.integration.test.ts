import { afterEach, beforeEach, expect, it } from "vitest";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { processReminderRebuilds } from "@/features/activities/reminderRebuild";
import { createActivity } from "@/features/activities/repo";
import { type EngineFixture, engineActivity, engineFixture, reminderState } from "./fixture";

let fixture: EngineFixture | undefined;
const signal = () => AbortSignal.timeout(10_000);
beforeEach(async () => {
  fixture = await engineFixture(signal());
});
afterEach(async () => {
  await fixture?.ctx.close();
  fixture = undefined;
});
function current(): EngineFixture {
  if (fixture === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "engine fixture absent");
  return fixture;
}

it("keeps a raw old-writer activity legacy while consuming its rebuild without native policy or intent activation", async () => {
  const { ctx, actor, typeId, dueAt } = current();
  const sig = signal();
  // Old writer supplies neither calendar ownership nor engine authority.
  const inserted = await ctx.pool.query<{ id: string }>(
    `INSERT INTO activities
    (type_id, subject, due_at, owner_id, assignee_id) VALUES ($1,$2,$3,$4,$4) RETURNING id`,
    [typeId, "Raw legacy writer", dueAt, actor.id],
  );
  sig.throwIfAborted();
  const id = inserted.rows[0]?.id;
  if (id === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "raw legacy insert absent");
  expect(await engineActivity(ctx, id, sig)).toMatchObject({
    id,
    reminder_engine: "legacy",
    reminder_automation_enabled: true,
    calendar_id: null,
    due_at: new Date(dueAt),
  });
  const before = await reminderState(ctx, id, sig);
  expect(before.settings).toEqual([]);
  expect(before.intents).toEqual([]);
  expect(before.rebuilds).toHaveLength(1);

  expect(await processReminderRebuilds(ctx.db, sig)).toBe(1);
  sig.throwIfAborted();
  const after = await reminderState(ctx, id, sig);
  expect(after.rebuilds).toEqual([]);
  expect((await engineActivity(ctx, id, sig)).reminder_engine).toBe("legacy");
  // Expected baseline RED: the current reconciler creates assignment policy and intent here.
  expect({ settings: after.settings, intents: after.intents }).toEqual({
    settings: [],
    intents: [],
  });
});

it("persists intent ownership for a new native calendar event with explicit personal notification rules", async () => {
  const { ctx, actor, calendarId, typeId, dueAt } = current();
  const sig = signal();
  const rules = { timed: [{ method: "notification" as const, minutesBefore: 30 }], allDay: [] };
  const input = {
    typeId,
    subject: "Native personal ownership",
    calendarId,
    eventTimeZone: "Asia/Tehran",
    dueAt,
    reminderEngine: "legacy",
    reminderAutomationEnabled: false,
    personalReminders: { expectedRevision: 0, selection: { useDefault: false as const, ...rules } },
  };
  const created = await createActivity(ctx.db, actor, input, sig);
  sig.throwIfAborted();
  expect(created.ok).toBe(true);
  if (!created.ok) throw created.error;
  const state = await reminderState(ctx, created.value.id, sig);
  expect(state.rebuilds).toEqual([]);
  expect(state.settings).toMatchObject([
    {
      activityId: created.value.id,
      userId: actor.id,
      source: "personal",
      useDefault: false,
      version: 1,
      timeZone: "Asia/Tehran",
      rules,
    },
  ]);
  expect(state.intents).toMatchObject([
    {
      activityId: created.value.id,
      assigneeId: actor.id,
      state: "pending",
      settingsId: state.settings[0]?.id,
      settingsVersion: 1,
      inApp: true,
      email: false,
      dueAt: new Date(dueAt),
      fireAt: new Date(new Date(dueAt).getTime() - 30 * 60_000),
      notificationId: null,
      deliveredAt: null,
    },
  ]);
  const row = await engineActivity(ctx, created.value.id, sig);
  expect(row).toMatchObject({ calendar_id: calendarId, reminder_automation_enabled: true });
  // Expected baseline RED is durable ownership, after real write/rule/intent controls passed.
  expect(row.reminder_engine).toBe("intent");
});

it("persists intent ownership and automatic-reminder suppression across a later rebuild", async () => {
  const { ctx, actor, calendarId, typeId, dueAt } = current();
  const sig = signal();
  const input = {
    typeId,
    subject: "Native suppressed ownership",
    calendarId,
    eventTimeZone: "Asia/Tehran",
    dueAt,
    reminderEngine: "intent",
    reminderAutomationEnabled: true,
  };
  const created = await createActivity(ctx.db, actor, input, sig, { scheduleReminder: false });
  sig.throwIfAborted();
  expect(created.ok).toBe(true);
  if (!created.ok) throw created.error;
  const id = created.value.id;
  expect(await engineActivity(ctx, id, sig)).toMatchObject({
    calendar_id: calendarId,
    reminder_automation_enabled: false,
  });
  const shifted = new Date(new Date(dueAt).getTime() + 60_000);
  await ctx.pool.query("UPDATE activities SET due_at=$1 WHERE id=$2", [shifted, id]);
  sig.throwIfAborted();
  expect((await reminderState(ctx, id, sig)).rebuilds).toHaveLength(1);
  expect(await processReminderRebuilds(ctx.db, sig)).toBe(1);
  sig.throwIfAborted();
  const state = await reminderState(ctx, id, sig);
  expect(state.rebuilds).toEqual([]);
  // Harmless assignment-policy metadata or cancelled history does not constitute delivery work.
  expect(state.intents.filter((intent) => intent.state !== "cancelled")).toEqual([]);
  const row = await engineActivity(ctx, id, sig);
  expect(row).toMatchObject({ due_at: shifted, reminder_automation_enabled: false });
  expect(row.reminder_engine).toBe("intent");
});
