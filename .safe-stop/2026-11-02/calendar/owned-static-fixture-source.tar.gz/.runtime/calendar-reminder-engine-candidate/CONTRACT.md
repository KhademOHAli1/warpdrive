# Native reminder engine ownership candidate, three RED definitions

Source only and unrun. No checks, runtime, database/service invocation, application/schema/config
edits, canonical migration SQL or changes to the existing seven GREEN case selection occurred.
All three files belong only to this ignored private packet.

The exact candidate selection is the three `it` cases in `engineOwnership.integration.test.ts`.
Each uses the actual `makeTestDb` migrated private lineage, real factories/calendar/create services,
real SQL readback and the production `processReminderRebuilds` → `reconcileReminderIntent` path.
There are no database/query mocks, fake reminders, provider calls or new worker/takeover APIs.
Every await boundary checks the required signal in helpers/case I/O; fixture failures close the
new per-test database and each case closes it in afterEach. There is no controlled clock or worker.

The fixture alone adds `activities.reminder_engine` as text, not null, default `legacy`, checked
`legacy/intent`. This test-only ALTER models the accepted 0098 engine contract without declaring
the field in application TypeScript or authoring a canonical migration. Readback of the extra
column uses real parameterized PostgreSQL queries, avoiding nonexistent application imports.
Once canonical lineage actually includes this column, this fixture ALTER must be replaced with
that migrated contract; it is intentionally not an IF-NOT-EXISTS schema-drift escape hatch.

1. **Old writer remains legacy.** Raw Activity insert omits calendar and engine columns, persists
   default legacy ownership and a future schedule, and produces a real dirty row. Processing must
   report one consumed dirty row, leave the Activity present/legacy and clear the dirty marker,
   while creating neither native personal/assignment settings nor reminder intents. The current
   source is expected to fail the final combined empty-settings/intents assertion because its
   reconciler has no engine guard. Early permission/query errors or no-op processing cannot satisfy
   the controls. A true automation default does not authorize taking a legacy row over.
2. **New native personal reminder claims intent ownership.** Actual createActivity writes a new
   native calendar event with explicit personal notification-only rules. Successful event creation,
   durable personal revision/rules, one pending in-app intent and exact fire/due values are controls
   before raw durable engine readback must equal `intent` and automation must remain true. An ordinary
   input object variable also carries forged client `reminderEngine:"legacy"` and
   `reminderAutomationEnabled:false` fields. The actual input schema must strip those extra fields;
   server-owned persistence must not trust a future DTO/insert spread. Current source omits the engine field,
   so the expected RED is the final `legacy` versus `intent` value, not a missing API/setup failure.
3. **Native suppression is independent of ownership.** Actual createActivity receives
   `scheduleReminder:false` with no personal override. Its ordinary input object variable forges
   `reminderEngine:"intent"` and `reminderAutomationEnabled:true`; the trusted server option still
   controls suppression. Its persisted automation flag must stay false
   after a real direct-writer schedule update and consumed rebuild, without active automatic intent
   work. Assignment-policy metadata and cancelled history are not prohibited. Engine ownership must
   nevertheless be `intent`; the current source is expected to fail that final engine assertion.
   This case does not claim suppression should erase an explicit independent personal subscription.

These are expected assertion REDs from source review, not observed test outcomes. No application
fix is supplied. A future finite serial database allocation must select only this packet and use
the established synthetic/fail-closed environment and owned fixture. Existing native configuration
and previously GREEN source/configuration remain untouched. A RED at setup/import/migration is not
the intended engine evidence and must be reported separately.

The accepted wider contract remains outside these first tests: compatible legacy delivery and
takeover lock the same Activity; intent delivery has a separate queue with old consumers drained
or fenced; no blanket legacy activation; authentic historical receipts remain visible independently
of engine/automation while recipient/CRM/calendar gates remain; invalid/cancelled/mismatched or
ambiguous references never fall back; canonical completion replay/E_ACTIVITY_008 and final durable
notification email admission remain intact. No placeholder missing-import tests, legacy takeover,
queue transition, historic receipt, live delivery/browser/provider or installed-migration acceptance
is inferred from this packet.
