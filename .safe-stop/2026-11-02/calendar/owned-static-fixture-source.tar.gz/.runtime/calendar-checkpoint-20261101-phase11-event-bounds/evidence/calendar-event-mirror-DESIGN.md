# Proposed raw Google event mirror, source planning only

This file remains a source design, with no implemented mirror, migration or provider acceptance. Prerequisite clock/cache corrections are locally qualified; migration0092 and actual synthetic catalog browser acceptance/exactcleanup are complete. The ignored event-collector bounds candidate has observed9originalpolicyRED/3controls and4cursorRED/12controls, followed by a source-only cursor fix. Its16-case GREEN and app promotion remain pending. No next migration is generated or reserved.

The next slice is a server-only raw mirror for explicitly selected provider calendars. It creates no Activities, reminders, notifications, outbound writes or Meet readiness. Existing Activity creation allocates new IDs and enables reminders, so it cannot be reused as an idempotent import adapter.

## Proposed model

- Mirror state: latest run UUID/deadline, captured account generation, binding version, catalog authority and base publication revision; separate published revision, full snapshot epoch, cursor and query-contract version.
- Stable events: local UUID, provider calendar UUID, exact opaque event ID plus generated hash uniqueness and exact collision guard, raw JSON, nullable ETag, tombstone reason and publication/epoch markers. Never apply the insertion-ID regex to provider recurring-instance IDs.
- Run staging: private page data keyed by run UUID and event identity. Superseded/expired staging has no query authority and needs bounded reclamation.

## Authority and publication

Obtain a fresh access grant, then begin under owner-first locks. Require active owner, connected/current generation, selected/current binding, nondeleted provider-source local calendar and current readable catalog authority. Capture and recheck all conditions for staging/publication; routine credential rotation keeps generation, while reconnect, deselection/re-addition, permission changes and newer runs fence older work.

Publish changes, cursor and revision atomically. Sample deadlines after locks and before final publication. Roll back tentative batches on expiry/storage failure. Failure bookkeeping may change only its own current run. Read the starting cursor under state lock and fence against its base publication revision. Changed generation, binding version or query contract forces full sync.

Full publication advances the full-snapshot epoch. Omitted rows become unavailable tombstones while retaining IDs. Incremental publication changes only returned rows; absence means unchanged. HTTP 410 invalidates cursor authority and sets needsFull. Retain prior data as unavailable history until a complete full rebuild publishes.

Preserve raw recurrence masters/rules, exception recurringEventId and exact originalStartTime, including sparse cancellations. Do not reconstruct missing fields or expand occurrences in this package. Owner-only queries recheck current authority and expose bounded safe DTOs, never raw payloads/cursors.

## Transport prerequisite

Reuse getCalendarAccessGrant, eventsList and ownership/binding/catalog seams. Qualify and promote the staged sync.ts page/item/byte/depth/Unicode/duplicate and cursor guards first. Limits are event-specific, and are not Google API or streaming response-body limits. A later mirror-only sequential visitor must preserve page authority and stage each validated page privately before requesting the next one, returning only a complete terminal cursor. No flat collector result alone establishes publication authority.

## Proposed real-PostgreSQL scenarios

1. Multipage full publication, long opaque IDs, recurrence preservation.
2. Incremental update/cancellation with unchanged rows retained.
3. Empty full versus empty incremental results.
4. Later-page failure, abort and witnessed mid-batch storage rollback.
5. Competing successes and newer-failure/older-success ordering.
6. HTTP 410 followed by successful/failed full rebuilds.
7. Refresh, reconnect, deselection/re-addition and permission races.
8. Wrong/inactive owner and deleted local-calendar denial.
9. Stable identity, hash collisions, deadlines and zero Activity/reminder side effects.

## Official-contract research for the next implementation

Public Google documentation confirms that free/busy callers receive expanded instances
as though singleEvents were true. A query flag alone therefore cannot establish the
proposed unexpanded mirror contract. [Recurring-events guide](https://developers.google.com/workspace/calendar/api/guides/recurringevents#access_instances).

Proposed fail-closed policy: preserve each page envelope; require a known readable
accessRole on every page, consistent with the captured catalog role and all other pages.
Reject missing/unknown/free-busy/no-access authority and require metadata refresh after
a mismatch. The reference lists accessRole but does not explicitly define omission,
so rejecting omission is our policy. The existing flattened collector alone cannot
carry this authority. [List response](https://developers.google.com/workspace/calendar/api/v3/reference/events/list#response).

With incremental sync, repeat the original syncToken and compatible query parameters
while advancing pageToken; take the new cursor only from the last page. HTTP 410 may
reflect expiry or ACL change and requires a full reset/rebuild. Atomic staged publication
is our design choice. [Sync guide](https://developers.google.com/workspace/calendar/api/guides/sync).

Keep cancelled recurring exceptions for the parent's lifetime, retaining original
occurrence identity even after a move. Sparse ordinary deletions need only their ID;
never require a normal event body on tombstones. [Event resource](https://developers.google.com/workspace/calendar/api/v3/reference/events#resource).

Creation-ID alphabet/length validation applies to caller-provided insertion IDs. It
must not restrict returned recurring-instance identities. Our read storage preserves
exact opaque IDs with hash collision guards. Raw byte/depth/page/count limits remain
Warpdrive policy. [Insert reference](https://developers.google.com/workspace/calendar/api/v3/reference/events/insert#request-body).
