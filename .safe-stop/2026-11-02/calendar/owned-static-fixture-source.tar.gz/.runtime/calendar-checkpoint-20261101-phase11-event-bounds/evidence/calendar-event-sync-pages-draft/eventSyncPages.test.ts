import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { err, ok } from "@/types/result";
import {
  deferred, input, invalidPages, jsonBytes, loadVisitor, pageSignal,
  rawRecurrenceEvents, readableRoles, recordingStage, response,
  type StagedPage, syntheticPages, waitGate,
} from "./eventSyncPagesFixture";

const network = vi.fn<typeof fetch>();
beforeEach(() => {
  network.mockClear();
  network.mockRejectedValue(new AppError(ERROR_IDS.DB_INVARIANT, "unexpected external page request"));
  vi.stubGlobal("fetch", network);
});
afterEach(() => {
  try { expect(network).not.toHaveBeenCalled(); }
  finally { vi.unstubAllGlobals(); }
});

it("preserves page accessRole while ordinary role-less reads remain compatible", async () => {
  const missing = syntheticPages([{ items: [], nextSyncToken: "ordinary" }]);
  expect(await missing.client.eventsList(input())).toEqual({ ok: true, value: { items: [], nextSyncToken: "ordinary" } });
  for (const accessRole of [...readableRoles, "futureRole"]) {
    const source = syntheticPages([{ items: [], accessRole, nextSyncToken: "role" }]);
    expect(await source.client.eventsList(input())).toEqual({ ok: true, value: { items: [], accessRole, nextSyncToken: "role" } });
  }
});

it("visits every matching readable-role page and returns only final completion metadata", async () => {
  const visit = await loadVisitor();
  const event = { id: "one", summary: "تقویم / Kalender" };
  for (const role of readableRoles) {
    const source = syntheticPages([
      { accessRole: role, items: [event], nextPageToken: "next" },
      { accessRole: role, nextSyncToken: "complete" },
    ]);
    const sink = recordingStage();
    expect(await visit(source.client, input({ expectedAccessRole: role }), sink.stage)).toEqual({
      ok: true, value: { accessRole: role, syncToken: "complete", pages: 2, events: 1, bytes: jsonBytes(event) },
    });
    expect(sink.pages).toEqual([
      { ordinal: 0, accessRole: role, items: [event] },
      { ordinal: 1, accessRole: role, items: [] },
    ]);
  }
});

it("rejects missing unknown unreadable and mismatching first-page authority before staging", async () => {
  const visit = await loadVisitor();
  for (const role of [undefined, "futureRole", "none", "freeBusyReader", "reader"]) {
    for (const items of [[], [{ id: "private" }]]) {
      const source = syntheticPages([{ ...(role === undefined ? {} : { accessRole: role }), items, nextSyncToken: "unsafe" }]);
      const sink = recordingStage();
      expect(await visit(source.client, input(), sink.stage)).toEqual({ ok: false, error: { kind: "catalog_changed" } });
      expect(sink.pages).toEqual([]);
      expect(source.urls).toHaveLength(1);
    }
  }
});

it("rejects later authority changes without staging that page or releasing its cursor", async () => {
  const visit = await loadVisitor();
  for (const role of [undefined, "futureRole", "none", "freeBusyReader", "reader", "owner"]) {
    for (const items of [[], [{ id: "unsafe" }]]) {
      const source = syntheticPages([
        { accessRole: "writer", items: [{ id: "private-stage" }], nextPageToken: "next" },
        { ...(role === undefined ? {} : { accessRole: role }), items, nextSyncToken: "unsafe" },
      ]);
      const sink = recordingStage();
      expect(await visit(source.client, input(), sink.stage)).toEqual({ ok: false, error: { kind: "catalog_changed" } });
      expect(sink.pages).toEqual([{ ordinal: 0, accessRole: "writer", items: [{ id: "private-stage" }] }]);
      expect(source.urls).toHaveLength(2);
    }
  }
});

it("preserves the original full or incremental query while advancing only pageToken", async () => {
  const visit = await loadVisitor();
  for (const syncToken of [undefined, "original+/= تقویم"]) {
    const source = syntheticPages([
      { accessRole: "writer", nextPageToken: "next+/=" },
      { accessRole: "writer", nextSyncToken: "complete+/=" },
    ]);
    const request = input({ syncToken });
    expect((await visit(source.client, request, recordingStage().stage)).ok).toBe(true);
    for (const [index, raw] of source.urls.entries()) {
      const url = new URL(raw);
      expect(url.pathname).toContain("team%2Fa%3Fb%40example.invalid");
      expect(url.searchParams.get("syncToken")).toBe(syncToken ?? null);
      expect(url.searchParams.get("pageToken")).toBe(index === 0 ? null : "next+/=");
      expect(url.searchParams.get("showDeleted")).toBe("true");
      expect(url.searchParams.get("singleEvents")).toBe("false");
      expect(url.searchParams.get("maxResults")).toBe("2500");
      for (const forbidden of ["timeMin", "timeMax", "updatedMin", "q", "orderBy", "iCalUID", "privateExtendedProperty", "sharedExtendedProperty"])
        expect(url.searchParams.has(forbidden)).toBe(false);
    }
    expect(source.signals).toEqual([request.signal, request.signal]);
  }
});

it("awaits each stage before fetching again and withholds completion until terminal staging", async () => {
  const visit = await loadVisitor();
  const source = syntheticPages([{ accessRole: "writer", nextPageToken: "next" }, { accessRole: "writer", nextSyncToken: "complete" }]);
  const entered = [deferred<void>(), deferred<void>()] as const;
  const release = [deferred<void>(), deferred<void>()] as const;
  const pages: StagedPage[] = [];
  const request = input();
  const running = visit(source.client, request, async (page, signal) => {
    expect(signal).toBe(request.signal);
    pages.push(page);
    const gate = entered[page.ordinal];
    const wait = release[page.ordinal];
    if (gate === undefined || wait === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "unexpected stage ordinal");
    gate.resolve();
    await waitGate(wait.promise, signal);
    return ok(undefined);
  });
  let settled = false;
  const observed = running.then(() => { settled = true; }, () => { settled = true; });
  try {
    await waitGate(entered[0].promise, request.signal);
    expect(source.urls).toHaveLength(1);
    expect(settled).toBe(false);
    release[0].resolve();
    await waitGate(entered[1].promise, request.signal);
    expect(source.urls).toHaveLength(2);
    expect(settled).toBe(false);
    expect(pages).toEqual([{ ordinal: 0, accessRole: "writer", items: [] }, { ordinal: 1, accessRole: "writer", items: [] }]);
    release[1].resolve();
    expect(await running).toMatchObject({ ok: true, value: { syncToken: "complete" } });
  } finally {
    for (const gate of release) gate.resolve();
    await running.catch(() => undefined);
    await observed;
  }
});

it("propagates stage Result errors unchanged and makes no later request", async () => {
  const visit = await loadVisitor();
  for (const kind of ["storage", "conflict"] as const) for (const failAt of [0, 1]) {
    const error = { kind };
    const source = syntheticPages([{ accessRole: "writer", nextPageToken: "next" }, { accessRole: "writer", nextSyncToken: "unsafe" }]);
    const result = await visit(source.client, input(), async (page) => page.ordinal === failAt ? err(error) : ok(undefined));
    expect(result).toEqual({ ok: false, error });
    if (!result.ok) expect(result.error).toBe(error);
    expect(source.urls).toHaveLength(failAt + 1);
  }
});

it("preserves later provider failures including expired sync without a completion cursor", async () => {
  const visit = await loadVisitor();
  for (const [status, expected] of [
    [410, { kind: "sync_expired", status: 410 }],
    [429, { kind: "rate_limited", status: 429, retryAfterSeconds: 15 }],
    [503, { kind: "provider_unavailable", status: 503, retryAfterSeconds: 15 }],
  ] as const) {
    const source = syntheticPages([{ accessRole: "writer", items: [{ id: "private-stage" }], nextPageToken: "later" }, response({ error: { code: status } }, status, status === 410 ? {} : { "Retry-After": "15" })]);
    const sink = recordingStage();
    expect(await visit(source.client, input(), sink.stage)).toEqual({ ok: false, error: expected });
    expect(sink.pages).toHaveLength(1);
    expect(source.urls).toHaveLength(2);
  }
});

it("validates the whole page and its cursor before staging any offending page", async () => {
  const visit = await loadVisitor();
  for (const scenario of invalidPages()) {
    const source = syntheticPages(scenario.pages);
    const sink = recordingStage();
    expect(await visit(source.client, input(), sink.stage)).toEqual({ ok: false, error: { kind: "invalid_response" } });
    expect(sink.pages).toHaveLength(scenario.staged);
    expect(source.urls).toHaveLength(scenario.pages.length);
  }
});

it("stages raw recurrence moved exceptions sparse cancellations and future fields intact", async () => {
  const visit = await loadVisitor();
  const events = rawRecurrenceEvents();
  const source = syntheticPages([{ accessRole: "writer", items: events.slice(0, 2), nextPageToken: "next" }, { accessRole: "writer", items: events.slice(2), nextSyncToken: "complete" }]);
  const sink = recordingStage();
  expect(await visit(source.client, input(), sink.stage)).toEqual({ ok: true, value: {
    accessRole: "writer", syncToken: "complete", pages: 2, events: events.length,
    bytes: events.reduce((total, event) => total + jsonBytes(event), 0),
  } });
  expect(sink.pages.flatMap((page) => page.items)).toEqual(events);
});

it("propagates exact abort reasons before fetch after fetch and after staging", async () => {
  const visit = await loadVisitor();
  for (const phase of ["before", "after-fetch", "after-stage", "after-terminal-stage"] as const) {
    const controller = new AbortController();
    const reason = new DOMException(`Cancelled ${phase}`, "AbortError");
    const terminal = phase === "after-terminal-stage";
    const source = syntheticPages([terminal ? { accessRole: "writer", nextSyncToken: "unsafe" } : { accessRole: "writer", nextPageToken: "later" }]);
    let stages = 0;
    if (phase === "before") controller.abort(reason);
    const client = { eventsList: async (request: Parameters<typeof source.client.eventsList>[0]) => {
      const result = await source.client.eventsList(request);
      if (phase === "after-fetch") controller.abort(reason);
      return result;
    } };
    await expect(visit(client, input({ signal: AbortSignal.any([controller.signal, pageSignal()]) }), async () => {
      stages += 1;
      controller.abort(reason);
      return ok(undefined);
    })).rejects.toBe(reason);
    expect(source.urls).toHaveLength(phase === "before" ? 0 : 1);
    expect(stages).toBe(phase === "after-stage" || terminal ? 1 : 0);
  }
});
