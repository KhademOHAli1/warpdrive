import type { GoogleCalendarClient } from "@/features/activities/providers/google/client";
import type { GoogleResult, SignalInput } from "@/features/activities/providers/google/contracts";
import type { GoogleEvent } from "@/features/activities/providers/google/schemas";
import { err, ok } from "@/types/result";
import {
  eventCursorBytes,
  eventStorageBytes,
  MAX_EVENT_PAGE_TOKEN_BYTES,
  MAX_EVENT_SYNC_BYTES,
  MAX_EVENT_SYNC_EVENTS,
  MAX_EVENT_SYNC_PAGES,
} from "./eventStorage";

interface EventCollection {
  events: GoogleEvent[];
  ids: Set<string>;
  bytes: number;
}

interface PageCursors {
  tokens: Set<string>;
  bytes: number;
}

function retainPageCursor(cursors: PageCursors, token: string): boolean {
  if (cursors.tokens.has(token)) return false;
  const bytes = eventCursorBytes(token);
  if (bytes === null || cursors.bytes + bytes > MAX_EVENT_PAGE_TOKEN_BYTES) return false;
  cursors.tokens.add(token);
  cursors.bytes += bytes;
  return true;
}

function appendEvents(collection: EventCollection, events: GoogleEvent[]): boolean {
  if (collection.events.length + events.length > MAX_EVENT_SYNC_EVENTS) return false;
  for (const event of events) {
    if (collection.ids.has(event.id)) return false;
    const bytes = eventStorageBytes(event);
    if (bytes === null || collection.bytes + bytes > MAX_EVENT_SYNC_BYTES) return false;
    collection.ids.add(event.id);
    collection.bytes += bytes;
    collection.events.push(event);
  }
  return true;
}

// Transport collection only. The future mirror must publish the complete result
// atomically; invalid/failed pages expose neither partial events nor a cursor.
export async function collectGoogleEventSync(
  client: GoogleCalendarClient,
  input: SignalInput & { calendarId: string; syncToken?: string },
): Promise<GoogleResult<{ events: GoogleEvent[]; syncToken: string }>> {
  const collection: EventCollection = { events: [], ids: new Set(), bytes: 0 };
  const cursors: PageCursors = { tokens: new Set(), bytes: 0 };
  let pageToken: string | undefined;
  for (let page = 0; page < MAX_EVENT_SYNC_PAGES; page += 1) {
    input.signal.throwIfAborted();
    const result = await client.eventsList({ ...input, pageToken });
    input.signal.throwIfAborted();
    if (!result.ok) return result;
    if (!appendEvents(collection, result.value.items)) return err({ kind: "invalid_response" });
    const next = result.value.nextPageToken;
    if (next === undefined) {
      const final = result.value.nextSyncToken;
      return final === undefined || eventCursorBytes(final) === null
        ? err({ kind: "invalid_response" })
        : ok({ events: collection.events, syncToken: final });
    }
    if (result.value.nextSyncToken !== undefined || !retainPageCursor(cursors, next))
      return err({ kind: "invalid_response" });
    pageToken = next;
  }
  return err({ kind: "invalid_response" });
}
