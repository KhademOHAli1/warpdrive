# Event-sync bounds: unqualified source candidate

This ignored folder contains 16 unit cases across two test files against the public
`collectGoogleEventSync` collector. Imports resolve existing `@/features/...` modules;
the collector API is unchanged and there is no missing-module structural test.
Only this ignored folder was written. No application source, docs or migrations were
edited, and no source-hash verification was run.

Root observed baseline RED in `.runtime/calendar-google-event-sync-bounds-red.log`:
12 cases in 197 ms, nine intended policy failures and three preservation/abort controls,
PID 89146/session 88046 terminal exit 1. Root added a global external-fetch rejection
before that run. Those tests and their fixture remain frozen.

The candidate adds `eventStorage.ts` and a replacement `sync.ts` in this ignored
folder only. Storage validation follows the qualified catalog JSON/Unicode algorithm
with event-specific limits. The collector validates exact event IDs and payloads
before retaining them, bounds paging/count/aggregate bytes, and retains its existing
error, cursor, full/incremental query and abort semantics. No roles or event-shape
requirements are added. This cursor-fix revision has not been executed or qualified.

These are Warpdrive operational policies, not Google API limits:

- At most 1,000 pages, accepting a terminal cursor on page 1,000.
- At most 50,000 events across the complete result.
- At most 1 MiB of UTF8 `JSON.stringify(event)` bytes per raw event.
- At most 32 MiB for the sum of those raw event payloads; page envelopes are excluded.
- Maximum JSON depth 32: the event object is depth 0, direct property values depth 1.
- Reject PostgreSQL-unsafe NUL keys/values and lone surrogate code points in keys/values.
- Event IDs are exact opaque strings; reject duplicates within or across pages.
- Each returned page/final cursor is at most 64 KiB UTF8 text; retained distinct
  page-token text totals at most 1 MiB. NUL/lone surrogates are rejected without
  normalization or truncation. The final cursor is excluded from the page-token sum.
- Failure yields `invalid_response` with no partial value or commit cursor.
- Preserve recurrence, sparse cancellation, unknown fields, final cursors and abort reasons.

The payload limits do not claim HTTP body streaming or a pre-parse network-byte limit.
Synthetic Responses still use the current JSON transport/schema boundary.

The retained event-entry payload sum is capped at 32 MiB; separate cursor budgets
apply. Aggregate payloads are produced one event/page and boundary/overflow probes
return compact summaries rather than retaining their raw results. No giant eager
response array, explicit GC, sleep, timer
benchmark, performance campaign, provider request or database is involved.

Original twelve case names, in order:

1. accepts a terminal cursor on page 1000 and rejects a continuation beyond the page budget
2. accepts 50000 events and rejects the 50001st event across otherwise valid pages
3. measures the one-MiB raw event budget in UTF8 bytes and accepts its exact boundary
4. accepts 32MiB of aggregate entries and rejects another small event without violating the per-event cap
5. accepts raw JSON depth 32 and rejects depth 33 in otherwise opaque provider fields
6. rejects PostgreSQL-unsafe NUL characters in event values and opaque object keys
7. rejects lone high and low surrogates in values and keys while preserving valid Unicode
8. rejects duplicate opaque event IDs within a page without case-folding or Unicode normalization
9. rejects duplicate event IDs across pages even when the later entry is a cancellation
10. preserves recurrence masters, sparse cancelled exceptions and unknown fields with only a complete final cursor
11. propagates an already-aborted signal before any event provider request
12. propagates abort after awaiting a later page without returning partial events or its cursor

Next verification requires a fresh named 16-case GREEN grant with the exact public
sync-module import aliased to this candidate `sync.ts`. Its sibling `./eventStorage`
import stays local; all source type/result imports use existing rooted aliases.

After browser acceptance and root promotion authorization, move `eventStorage.ts`,
the replacement `sync.ts`, `eventSyncBounds.test.ts`, `eventSyncCursorBounds.test.ts`
and `eventSyncBoundsFixture.ts`
together into `src/features/activities/providers/google/`, preserving both sibling
imports. The fixture name avoids the test classifier's database-fixture filename
marker. The application's 61-source-file frozen boundary remains untouched here.


Read-only audit found retained-cursor defects before promotion: event byte budgets did
not cover tokens retained in the page-token Set or the final cursor, and cursors accepted
PostgreSQL-unsafe Unicode. Root observed `.runtime/calendar-google-event-sync-cursors-red.log`:
four intended cursor failures plus twelve existing passing controls, two files/392 ms;
canonical guard exit 1 in 1.54 seconds, all 61 app hashes conserved and owned group gone.
The resource was released. Both tests, the fixture and config remain frozen.

This revision exports cursor-byte validation/constants from `eventStorage.ts`, reusing
its safeText/UTF8 encoder. The collector checks final cursors separately and checks
distinct continuation-token bytes before retaining or requesting the next token. Cycles
and mixed cursor responses still reject with no partial result. No candidate GREEN,
static check, database, provider request or application promotion was performed here.

Proposed Warpdrive cursor policy, not Google limits: accept at most 64 KiB of UTF8
text per returned page/final cursor and at most 1 MiB total for retained distinct
page-token text, rejecting NUL and lone surrogates without normalization/truncation.
The final cursor is separately capped; page envelopes and transient URL/JSON parsing
allocations are not part of the retained event/page-token budgets. The current entry
validator traverses and serializes a full parsed entry before rejecting it, so these
limits do not bound peak validation memory or work.


Actual candidate GREEN is now recorded: all16cases/twofiles passed in384ms,
`.runtime/calendar-google-event-sync-cursors-green.log`, PID34114/session92353,
exit0/no guardstop,1.53s wrapper, all61frozeninputs unchanged, ownedgroupempty.
The five collector/helper/test/fixture files were then copied exactly into app source.
Their final app-source static/affected-unit/type qualification remains queued.
This ignored folder remains the historical candidate, not the current app contract.
