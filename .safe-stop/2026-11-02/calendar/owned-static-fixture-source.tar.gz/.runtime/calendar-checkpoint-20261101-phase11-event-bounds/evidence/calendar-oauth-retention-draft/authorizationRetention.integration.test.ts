import { eq } from "drizzle-orm";
import { afterEach, beforeEach, expect, it } from "vitest";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { users } from "@/db/schema";
import { calendarProviderAccounts } from "@/db/schema/calendarProviderAccounts";
import { seedUser } from "@/db/testing/factories";
import { finishCalendarAuthorization } from "@/features/activities/providers/google/accountAuthorization";
import { beginTestCalendar, calendarTestConfig, calendarTestTransport, connectTestCalendar, deferredValue } from "@/features/activities/providers/google/accountTestHelpers";
import { forbidProviderNetwork } from "@/features/activities/providers/google/calendarCatalog.test-helpers";
import type { GoogleTransport } from "@/features/activities/providers/google/contracts";
import { makeTestDb } from "@/test/db";
import { DELETE_GATE, holdDatabaseLock, installDeleteGate, loadSweep, orderedAttempts, retentionSignal, seedAttempt, seedMany, seedOrderedBacklog, sweep, waitBlocked, waitForGate } from "./authorizationRetentionFixture";

let ctx: Awaited<ReturnType<typeof makeTestDb>>;
let network: ReturnType<typeof forbidProviderNetwork>;
beforeEach(async () => {
  ctx = await makeTestDb();
  network = forbidProviderNetwork();
});
afterEach(async () => {
  try { expect(network).not.toHaveBeenCalled(); }
  finally { network.mockRestore(); await ctx.close(); }
});

it("deletes at the exact expiry cutoff while preserving every unexpired lifecycle state byte-for-byte", async () => {
  const owner = await seedUser(ctx.db);
  const cutoff = new Date();
  for (const phase of ["pending", "consumed", "cancelled"] as const) {
    await seedAttempt(ctx.db, owner.id, new Date(cutoff.getTime() - 1), phase);
    await seedAttempt(ctx.db, owner.id, cutoff, phase);
    await seedAttempt(ctx.db, owner.id, new Date(cutoff.getTime() + 1), phase);
  }
  const keep = (await orderedAttempts(ctx.db)).filter((row) => row.expiresAt.getTime() > cutoff.getTime());
  expect(await sweep(ctx.db, cutoff)).toEqual({ ok: true, value: { deleted: 6 } });
  expect(await orderedAttempts(ctx.db)).toEqual(keep);
});

it("deletes only the oldest 200 rows per call with deterministic state-hash ties and idempotent retries", async () => {
  const owner = await seedUser(ctx.db);
  const cutoff = new Date();
  await seedOrderedBacklog(ctx.db, owner.id, cutoff);
  const before = await orderedAttempts(ctx.db);
  expect(await sweep(ctx.db, cutoff)).toEqual({ ok: true, value: { deleted: 200 } });
  expect(await orderedAttempts(ctx.db)).toEqual(before.slice(200));
  expect(await sweep(ctx.db, cutoff)).toEqual({ ok: true, value: { deleted: 5 } });
  expect(await sweep(ctx.db, cutoff)).toEqual({ ok: true, value: { deleted: 0 } });
});

it("skips an expired row locked by another transaction without blocking or losing the row", async () => {
  const prune = await loadSweep();
  const owner = await seedUser(ctx.db);
  const cutoff = new Date();
  const locked = await seedAttempt(ctx.db, owner.id, new Date(cutoff.getTime() - 1));
  await seedAttempt(ctx.db, owner.id, cutoff);
  const gate = await holdDatabaseLock(ctx, "SELECT state_hash FROM calendar_oauth_attempts WHERE state_hash=$1 FOR UPDATE", [locked.stateHash]);
  const running = prune(ctx.db, retentionSignal(), { now: () => cutoff });
  try {
    expect(await waitForGate(running, AbortSignal.timeout(1_500))).toEqual({ ok: true, value: { deleted: 1 } });
    expect((await orderedAttempts(ctx.db)).map((row) => row.stateHash)).toEqual([locked.stateHash]);
  } finally { await gate.release(); await running.catch(() => undefined); }
  expect(await sweep(ctx.db, cutoff)).toEqual({ ok: true, value: { deleted: 1 } });
});

it("two overlapping sweep transactions delete disjoint batches while the first is still uncommitted", async () => {
  const prune = await loadSweep();
  const owner = await seedUser(ctx.db);
  const cutoff = new Date();
  await seedMany(ctx.db, owner.id, cutoff, 400);
  const drop = await installDeleteGate(ctx, "first");
  const gate = await holdDatabaseLock(ctx, "SELECT pg_advisory_xact_lock($1,$2)", DELETE_GATE);
  const first = prune(ctx.db, retentionSignal(), { now: () => cutoff });
  const settled = first.catch(() => undefined);
  let second: ReturnType<typeof prune> | undefined;
  try {
    await waitBlocked(ctx, gate.pid);
    second = prune(ctx.db, retentionSignal(), { now: () => cutoff });
    expect(await waitForGate(second, AbortSignal.timeout(1_500))).toEqual({ ok: true, value: { deleted: 200 } });
    await gate.release();
    expect(await first).toEqual({ ok: true, value: { deleted: 200 } });
    expect(await orderedAttempts(ctx.db)).toEqual([]);
  } finally {
    await gate.release(); await settled; await second?.catch(() => undefined); await drop();
  }
});

it("cleans active and inactive owners equally without modifying their Calendar accounts or live attempts", async () => {
  const cutoff = new Date();
  const active = await seedUser(ctx.db);
  const inactive = await seedUser(ctx.db);
  await connectTestCalendar(ctx.db, active.id);
  await connectTestCalendar(ctx.db, inactive.id);
  const accounts = await ctx.db.select().from(calendarProviderAccounts);
  for (const account of accounts) await seedAttempt(ctx.db, account.userId, cutoff, "pending", account);
  await ctx.db.update(users).set({ isActive: false }).where(eq(users.id, inactive.id));
  const keep = (await orderedAttempts(ctx.db)).filter((row) => row.expiresAt.getTime() > cutoff.getTime());
  expect(await sweep(ctx.db, cutoff)).toEqual({ ok: true, value: { deleted: 2 } });
  expect(await orderedAttempts(ctx.db)).toEqual(keep);
  expect(await ctx.db.select().from(calendarProviderAccounts)).toEqual(accounts);
});

it("does not take an owner lock behind a callback already holding owner and waiting on its attempt", async () => {
  const prune = await loadSweep();
  const owner = await seedUser(ctx.db);
  const cutoff = new Date();
  const blocked = await seedAttempt(ctx.db, owner.id, cutoff);
  await seedAttempt(ctx.db, owner.id, cutoff);
  const gate = await holdDatabaseLock(ctx, "SELECT state_hash FROM calendar_oauth_attempts WHERE state_hash=$1 FOR UPDATE", [blocked.stateHash]);
  const transport = calendarTestTransport();
  const callback = finishCalendarAuthorization(ctx.db, owner.id, calendarTestConfig,
    { state: blocked.state, browserNonce: blocked.browserNonce, code: "expired-held-attempt" },
    retentionSignal(), { transport, now: () => cutoff });
  const settled = callback.catch(() => undefined);
  let pruning: ReturnType<typeof prune> | undefined;
  try {
    await waitBlocked(ctx, gate.pid);
    pruning = prune(ctx.db, retentionSignal(), { now: () => cutoff });
    expect(await waitForGate(pruning, AbortSignal.timeout(1_500))).toEqual({ ok: true, value: { deleted: 1 } });
    await gate.release();
    expect(await callback).toEqual({ ok: false, error: { kind: "invalid_state" } });
    expect(transport).not.toHaveBeenCalled();
  } finally { await gate.release(); await settled; await pruning?.catch(() => undefined); }
});

it("deleting an expired consumed attempt cannot let its already-started provider exchange bind a grant", async () => {
  await loadSweep();
  const owner = await seedUser(ctx.db);
  const start = await beginTestCalendar(ctx.db, owner.id);
  const cutoff = new Date(start.expiresAt);
  let now = new Date(cutoff.getTime() - 1);
  const entered = deferredValue<void>();
  const release = deferredValue<void>();
  const deadline = AbortSignal.timeout(3_000);
  const upstream: GoogleTransport = calendarTestTransport();
  const callback = finishCalendarAuthorization(ctx.db, owner.id, calendarTestConfig,
    { ...start, code: "expires-during-exchange" }, deadline,
    { now: () => now, transport: async (url, init) => {
      if (url.endsWith("/token")) { entered.resolve(); await waitForGate(release.promise, init.signal); }
      init.signal.throwIfAborted(); return upstream(url, init);
    } });
  try {
    await waitForGate(Promise.race([entered.promise, callback.then(() => {
      throw new AppError(ERROR_IDS.DB_INVARIANT, "callback missed retention exchange gate");
    })]), deadline);
    now = cutoff;
    expect(await sweep(ctx.db, cutoff)).toEqual({ ok: true, value: { deleted: 1 } });
  } finally { release.resolve(); await callback.catch(() => undefined); }
  expect(await callback).toEqual({ ok: false, error: { kind: "invalid_state" } });
  expect(await orderedAttempts(ctx.db)).toEqual([]);
  expect(await ctx.db.select().from(calendarProviderAccounts)).toEqual([]);
});

it("propagates abort and rolls back a batch whose DELETE has already executed", async () => {
  const prune = await loadSweep();
  const owner = await seedUser(ctx.db);
  const cutoff = new Date();
  await seedMany(ctx.db, owner.id, cutoff, 2);
  const before = await orderedAttempts(ctx.db);
  const early = new AbortController();
  const earlyReason = new DOMException("Before sweep", "AbortError");
  early.abort(earlyReason);
  await expect(prune(ctx.db, early.signal, { now: () => cutoff })).rejects.toBe(earlyReason);
  expect(await orderedAttempts(ctx.db)).toEqual(before);
  const drop = await installDeleteGate(ctx, "after-delete");
  const gate = await holdDatabaseLock(ctx, "SELECT pg_advisory_xact_lock($1,$2)", DELETE_GATE);
  const controller = new AbortController();
  const reason = new DOMException("After tentative delete", "AbortError");
  const running = prune(ctx.db, AbortSignal.any([controller.signal, retentionSignal()]), { now: () => cutoff });
  const settled = running.catch(() => undefined);
  try {
    await waitBlocked(ctx, gate.pid);
    const probe = await ctx.pool.query<{ last_value: string }>("SELECT last_value FROM retention_delete_probe");
    expect(Number(probe.rows[0]?.last_value)).toBe(0);
    controller.abort(reason);
    await gate.release();
    await expect(running).rejects.toBe(reason);
    expect(await orderedAttempts(ctx.db)).toEqual(before);
  } finally { await gate.release(); await settled; await drop(); }
});
