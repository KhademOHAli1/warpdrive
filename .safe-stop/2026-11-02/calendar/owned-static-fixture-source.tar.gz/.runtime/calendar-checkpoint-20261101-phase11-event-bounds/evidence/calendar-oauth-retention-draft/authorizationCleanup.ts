import type { Db } from "@/db/client";
import { err, type Result } from "@/types/result";

// Importable fail-closed RED scaffold only. No cleanup is implemented here.
export async function pruneExpiredCalendarOAuthAttempts(
  _db: Db,
  signal: AbortSignal,
  _options: { now?: () => Date } = {},
): Promise<Result<{ deleted: number }, { kind: "storage" }>> {
  signal.throwIfAborted();
  return err({ kind: "storage" });
}
