import { expect } from "vitest";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import type { Db } from "@/db/client";
import { calendarOAuthAttempts } from "@/db/schema/calendarProviderAccounts";
import {
  createCalendarAuthorizationMaterial,
} from "@/features/activities/providers/google/authorization";
import { calendarTestConfig } from "@/features/activities/providers/google/accountTestHelpers";
import { encryptCalendarSecret } from "@/features/activities/providers/google/tokenCrypto";
import type { TestDb } from "@/test/db";

export const retentionSignal = () => AbortSignal.timeout(5_000);
type Phase = "pending" | "consumed" | "cancelled";
type Account = { id: string; connectionGeneration: number };

function attempt(userId: string, expiresAt: Date, phase: Phase, account?: Account) {
  const material = createCalendarAuthorizationMaterial();
  const createdAt = new Date(expiresAt.getTime() - 600_000);
  return {
    reference: { state: material.state, browserNonce: material.browserNonce, stateHash: material.stateHash },
    values: {
      stateHash: material.stateHash, userId,
      browserBindingHash: material.browserBindingHash,
      codeVerifierEnc: phase === "pending" ? encryptCalendarSecret(material.codeVerifier) : null,
      clientId: calendarTestConfig.clientId, redirectUri: calendarTestConfig.redirectUri,
      requestedAccess: calendarTestConfig.access,
      accountId: account?.id ?? null,
      accountConnectionGeneration: account?.connectionGeneration ?? null,
      accountConnectionGenerations: account === undefined ? {} : { [account.id]: account.connectionGeneration },
      createdAt, expiresAt,
      consumedAt: phase === "consumed" ? createdAt : null,
      cancelledAt: phase === "cancelled" ? createdAt : null,
    },
  };
}

export async function seedAttempt(
  db: Db, userId: string, expiresAt: Date, phase: Phase = "pending", account?: Account,
) {
  const seeded = attempt(userId, expiresAt, phase, account);
  await db.insert(calendarOAuthAttempts).values(seeded.values);
  return seeded.reference;
}

export async function seedMany(db: Db, userId: string, expiresAt: Date, count: number) {
  const seeded = Array.from({ length: count }, () => attempt(userId, expiresAt, "pending"));
  await db.insert(calendarOAuthAttempts).values(seeded.map((row) => row.values));
  return seeded.map((row) => row.reference);
}

// Backlog-only identities make expiry ordering disagree with hash and insertion order.
// These synthetic hashes are never passed through a callback.
export async function seedOrderedBacklog(db: Db, userId: string, cutoff: Date) {
  const cohorts = [
    { expiresAt: cutoff, prefix: "0", count: 105 },
    { expiresAt: new Date(cutoff.getTime() - 1), prefix: "f", count: 100 },
  ];
  const rows = cohorts.flatMap((cohort) => Array.from({ length: cohort.count }, (_, offset) => {
    const seeded = attempt(userId, cohort.expiresAt, "pending");
    return {
      ...seeded.values,
      stateHash: cohort.prefix + (cohort.count - offset).toString(16).padStart(63, "0"),
    };
  }));
  await db.insert(calendarOAuthAttempts).values(rows);
}

export async function loadSweep() {
  const api = await import("@/features/activities/providers/google/authorizationCleanup");
  return api.pruneExpiredCalendarOAuthAttempts;
}

export async function sweep(db: Db, cutoff: Date, signal: AbortSignal = retentionSignal()) {
  const prune = await loadSweep();
  return prune(db, signal, { now: () => cutoff });
}

export function orderedAttempts(db: Db) {
  return db.select().from(calendarOAuthAttempts)
    .orderBy(calendarOAuthAttempts.expiresAt, calendarOAuthAttempts.stateHash);
}

export async function holdDatabaseLock(ctx: TestDb, query: string, values: unknown[]) {
  const client = await ctx.pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(query, values);
    const pid = (await client.query<{ pid: number }>("SELECT pg_backend_pid() AS pid")).rows[0]?.pid;
    if (pid === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "retention lock PID missing");
    let released = false;
    return { pid, release: async () => {
      if (released) return;
      released = true;
      let healthy = false;
      try {
        await client.query("ROLLBACK");
        healthy = true;
      } finally {
        client.release(!healthy);
      }
    } };
  } catch (error) {
    client.release(true);
    throw error;
  }
}

export async function waitBlocked(ctx: TestDb, blockerPid: number) {
  await expect.poll(async () => {
    const rows = await ctx.pool.query<{ waiting: boolean }>(
      "SELECT EXISTS (SELECT 1 FROM pg_stat_activity WHERE datname=current_database() AND $1::integer=ANY(pg_blocking_pids(pid))) AS waiting",
      [blockerPid],
    );
    return rows.rows[0]?.waiting === true;
  }, { timeout: 1_500, interval: 10 }).toBe(true);
}

export async function waitForGate<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  signal.throwIfAborted();
  let onAbort: (() => void) | undefined;
  const aborted = new Promise<never>((_, reject) => {
    onAbort = () => reject(signal.reason instanceof Error
      ? signal.reason : new AppError(ERROR_IDS.DB_INVARIANT, "retention gate aborted"));
    signal.addEventListener("abort", onAbort, { once: true });
  });
  try {
    return await Promise.race([promise, aborted]);
  } finally {
    if (onAbort !== undefined) signal.removeEventListener("abort", onAbort);
  }
}

export const DELETE_GATE = [47103, 30215];

export async function installDeleteGate(ctx: TestDb, mode: "first" | "after-delete") {
  const pause = mode === "first"
    ? "IF nextval('retention_delete_probe') = 1 THEN PERFORM pg_advisory_xact_lock(47103,30215); END IF;"
    : "PERFORM setval('retention_delete_probe',(SELECT count(*) FROM calendar_oauth_attempts),true); PERFORM pg_advisory_xact_lock(47103,30215);";
  await ctx.pool.query(`
    CREATE SEQUENCE retention_delete_probe MINVALUE 0 START 1;
    CREATE FUNCTION pause_retention_delete_test() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN ${pause} RETURN NULL; END $$;
    CREATE TRIGGER pause_retention_delete AFTER DELETE ON calendar_oauth_attempts
      FOR EACH STATEMENT EXECUTE FUNCTION pause_retention_delete_test();
  `);
  return async () => {
    await ctx.pool.query(`
      DROP TRIGGER IF EXISTS pause_retention_delete ON calendar_oauth_attempts;
      DROP FUNCTION IF EXISTS pause_retention_delete_test();
      DROP SEQUENCE IF EXISTS retention_delete_probe;
    `);
  };
}
