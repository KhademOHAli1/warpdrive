# OAuth retention: unexecuted test-only draft

Scope: one bounded, trusted maintenance command. No provider calls, account mutation,
credential decryption, browser-cookie response, client endpoint or new retention UI.
Only this ignored folder is written. No source/docs/migration edits or execution.

## Proposed production boundary

`authorizationCleanup.ts` exports
`pruneExpiredCalendarOAuthAttempts(db, signal, { now?: () => Date })` returning
`Result<{ deleted: number }, { kind: "storage" }>`; AbortError propagates unchanged.
The clock is trusted dependency injection, never a client-supplied cutoff. Sample it
once for a finite batch. There is no owner/status filter or caller-controlled limit.

Delete at most 200 rows where `expires_at <= cutoff`, ordered by `(expires_at,state_hash)`.
An expired pending, consumed or cancelled attempt is equally eligible. Preserve every
unexpired row, including consumed/cancelled records: they still count toward the eight
unexpired-attempt admission bound and their browser responses may remain in transit.
Delete the whole expired row, including any remaining encrypted verifier. Keeping audit
metadata after verifier erasure would be a separate explicit retention policy.

Use a single transaction with a bounded attempt-only `FOR UPDATE SKIP LOCKED` candidate
selection and guarded DELETE/RETURNING. Count deleted rows, not selected rows. Never
subsequently acquire owner/account locks. Existing callbacks lock owner then attempt;
this attempt-only sweep introduces no reverse dependency, including for inactive owners.
Recheck the cutoff in DELETE. Check AbortSignal before I/O and after DELETE inside the
transaction, so abort rolls back the current batch. Use finite local lock/statement
timeouts (proposed 1s/5s) because Drizzle query awaits do not themselves cancel on signal.

Add a global `(expires_at,state_hash)` index in the existing attempt schema through a
later authorized generated migration. The owner/expiry index stays for admission.
No migration is reserved/generated here.

A new feature-local `authorizationMaintenance.ts` can register one fixed pg-boss queue
and a minute schedule through `registerAllJobs`. One batch per invocation; retries and
overlapping workers are safe through row locking/idempotency. A bounded job signal and
count-only diagnostics suffice. Keep this separate from auth maintenance's provider
revocation work. Registry/job wiring and its small registration test remain a later slice.

Fixed attempt-cookie Expires already handles late start responses. Cleanup never emits
Set-Cookie. A callback whose expired row was purged must fail its durable bind reread.
The qualified clock-callback checks after owner/attempt locks must remain intact.

## Draft tests and fixtures

`authorizationRetention.integration.test.ts` has exactly eight real-PostgreSQL cases:

1. Exact cutoff equality and byte-for-byte preservation of every unexpired lifecycle state.
2. Deterministic oldest-200 batch across two expiry cohorts, state-hash ties, five-row remainder and idempotent empty retry.
3. A locked expired attempt is skipped without waiting or losing it.
4. A second sweep finishes a disjoint batch while the first deletion remains uncommitted.
5. Active/inactive owners are equally eligible; live attempts and account credentials/generations stay intact.
6. An owner-holding callback waiting on its attempt does not block the sweep through a reverse owner lock.
7. An expired consumed attempt is deleted during synthetic HTTP; its callback cannot bind.
8. Pre-call abort and an abort after tentative DELETE both preserve rows; the latter proves transactional rollback.

`authorizationRetentionFixture.ts` seeds isolated synthetic attempt rows using existing
crypto/config and the current schema. Direct seeding bypasses admission only to construct
expired backlogs/status combinations. The ordering case seeds 100 older rows with
`f`-prefixed 64-hex identities and 105 newer rows with `0`-prefixed 64-hex identities,
inserted newer-first with descending hashes in each cohort. Thus expiry, hash-only
and insertion ordering disagree. These deterministic identities are backlog-only;
callback scenarios retain genuine state-derived hashes. All HTTP is synthetic and
global fetch is rejected.
Real row/advisory locks, bounded pg_blocking_pids observation, statement triggers and a
nontransactional sequence probe establish interleavings. Gate clients release and running
operations settle in finally; triggers/functions/sequences are dropped before teardown.

Use the existing `makeTestDb`/injected testPg mechanism and a fresh named one-worker native
configuration under the owned run guard (finite deadline/live 5GiB floor). No harness,
private environment or database was launched/read by this preparation.

The production module is absent and dynamically imported inside calls. Root prepared an ignored fail-closed `authorizationCleanup.ts` scaffold and a specific alias in `.runtime/calendar-google-oauth-retention-red-pg.config.mts` so the future run can reach behavioral assertions without adding production code. Neither scaffold nor tests have executed. Missing-module collection would be structural only; root must reserve the lane and establish behavioral failures before production implementation. After authorization, promote both TS files together into
`src/features/activities/providers/google/`; keep their sibling fixture import unchanged.

No blocking design question: immediate deletion at expiry is the proposed minimum.
Any need to retain expired attempt metadata would change that policy and deserves a
separate explicit decision rather than silently adding an audit grace period.
