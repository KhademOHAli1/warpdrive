import { defineConfig } from "vitest/config";
import base from "../vitest.config";
export default defineConfig({
  ...base,
  test: {
    ...base.test,
    maxWorkers: 1,
    projects: [{ extends: true, test: {
      name: "unit", environment: "node",
      include: [
        "src/features/activities/providers/google/eventSyncBounds.test.ts",
        "src/features/activities/providers/google/eventSyncPayloadBounds.test.ts",
        "src/features/activities/providers/google/eventSyncCursorBounds.test.ts",
        "src/features/activities/providers/google/client.test.ts",
        "src/features/activities/providers/google/pathSafety.test.ts",
        "src/features/activities/providers/google/transport.test.ts",
        "src/features/activities/providers/google/errorReasons.test.ts",
      ],
    } }],
  },
});
