# Catalog preview shutdown correction, source only

The completed local browser acceptance used `calendar-catalog-preview-guard.py` with SHA256 `0916cb05b5da9e4931b40a5e01d8edfaf2f685ff51caa517c7266cfcf97791ac`. Those exact bytes are preserved in `calendar-catalog-preview-guard-used-20261101.py`.

During the manual owner stop, the used guard raised `PermissionError` from `os.killpg(process.pid, 0)` after the owned group had disappeared. Root independently verified with `ps` and `lsof` that group **96044** had no members and port **3169** was closed. The browser acceptance and exact fixture cleanup completed; their captured receipts and state files were preserved unchanged by this correction.

The current guard now derives group membership and numeric UID from `ps` before signaling. It refuses live unexpected ownership and treats failed/unparseable inventory as failure, not absence. If the group disappears between inventory and a signal, `ProcessLookupError` or `PermissionError` is accepted only when a new inventory proves no members remain. Signals still target only the owned process group. Existing disk, bootstrap, preview, overlap and escalation limits are unchanged.

This is an **unrun future harness correction**. Neither guard was run or imported during preparation, no app was started, and no evidence/state file was rewritten. The corrected shutdown path has no new runtime qualification.
