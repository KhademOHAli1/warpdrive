import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({...base,test:{...base.test,name:'calendar-google-generation-migration',maxWorkers:1,include:['src/features/activities/providers/google/accountConnectionMigration.integration.test.ts']}});
