import { resolveLocalePreferences } from '../src/features/i18n/preferences';
import { checkWorkspace, demand, exclusiveJson, FIXTURE, newPool, privateJson } from './calendar-browser-catalog-seed.mts';
const phase = process.argv[2];
demand(phase === 'before' || phase === 'after', 'Expected before or after phase');
checkWorkspace();
const pool = newPool();
try {
  const result = await pool.query<{ timezone: string; preferences: Record<string, string> | null }>(
    "SELECT timezone,ui->'localePreferences' AS preferences FROM user_preferences WHERE user_id=$1", [FIXTURE.ownerId]);
  demand(result.rows.length === 1, 'Known preference row missing');
  const raw = result.rows[0]!;
  const effective = resolveLocalePreferences({ ...raw.preferences, timeZone: raw.preferences?.timeZone ?? raw.timezone });
  const current = { timezone: raw.timezone, effective };
  if (phase === 'after') {
    const before = privateJson('.runtime/calendar-browser-catalog-preferences-before.json') as { current: typeof current };
    demand(JSON.stringify(before.current) === JSON.stringify(current), 'Original effective preferences were not restored');
  }
  exclusiveJson(`.runtime/calendar-browser-catalog-preferences-${phase}.json`, { observedAt: new Date().toISOString(), current });
  console.log(JSON.stringify({ phase, ...current }));
} finally { await pool.end(); }
