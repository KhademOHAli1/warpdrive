import {readFileSync,writeFileSync} from 'node:fs';
import {Pool} from 'pg';
import {env} from '../src/config/env';
const fixture=JSON.parse(readFileSync('.runtime/calendar-browser-fixture.json','utf8'));
const target=new URL(env.DATABASE_URL);
if(target.hostname!=='127.0.0.1'||target.port!=='54673'||target.pathname!==`/${fixture.database}`) throw new Error('Only preserved synthetic fixture allowed');
const owner=fixture.users.find((row:{email:string})=>row.email==='owner@calendar-review.invalid');
if(owner===undefined) throw new Error('Synthetic owner missing');
const pool=new Pool({connectionString:env.DATABASE_URL,max:2});
try{
 const [actor,accounts,attempts,events]=await Promise.all([
  pool.query("SELECT u.is_active,u.is_admin,p.timezone,p.ui->'localePreferences' AS locale_preferences FROM users u LEFT JOIN user_preferences p ON p.user_id=u.id WHERE u.id=$1",[owner.id]),
  pool.query('SELECT count(*)::int AS count FROM calendar_provider_accounts WHERE user_id=$1',[owner.id]),
  pool.query('SELECT count(*)::int AS count FROM calendar_oauth_attempts WHERE user_id=$1',[owner.id]),
  pool.query('SELECT id,version,due_date::text AS due_date,end_date::text AS end_date,event_time_zone FROM activities ORDER BY id'),
 ]);
 const preferences=actor.rows[0];
 if(preferences?.is_active!==true||preferences.is_admin!==false||preferences.locale_preferences?.locale!=='fa'||preferences.locale_preferences?.calendar!=='persian'||preferences.locale_preferences?.timeZone!=='Asia/Tehran') throw new Error('Actor/preferences differ from restored fixture state');
 if(accounts.rows[0].count!==0||attempts.rows[0].count!==0) throw new Error('Provider state changed during unconfigured UI acceptance');
 const evidence={observedAt:new Date().toISOString(),actor:{active:true,admin:false},restoredPreferences:preferences.locale_preferences,timeZone:preferences.timezone,providerAccounts:accounts.rows[0].count,oauthAttempts:attempts.rows[0].count,events:events.rows,browserObservations:{locales:['fa','de'],desktop:true,mobileViewport:{width:390,height:844},unconfiguredVisible:true,connectDisabled:true,synchronizationUnavailableVisible:true,existingAuthorizedAppsCardPreserved:true},limits:['HTTP development fixture only; production HTTPS remains separate.','Unconfigured account-card acceptance does not prove provider consent, reconnect, disconnect or synchronization.','Five Google connection-generation race cases separately reproduced two conflicts; its draft patch remains unpromoted.']};
 writeFileSync('.runtime/calendar-connections-browser-proof.json',JSON.stringify(evidence,null,2)+'\n');
 console.log(JSON.stringify(evidence,null,2));
}finally{await pool.end();}
