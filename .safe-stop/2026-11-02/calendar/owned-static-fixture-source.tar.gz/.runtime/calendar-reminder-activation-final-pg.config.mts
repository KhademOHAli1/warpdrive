import { defineConfig } from 'vitest/config';
import base from './calendar-reminder-activation-regression-pg.config.mts';
import focused from './calendar-reminder-defaults-past-pg.config.mts';
export default defineConfig({...base,test:{...base.test,name:'calendar-reminder-activation-final',maxWorkers:1,include:[...new Set([...base.test.include,...focused.test.include])]}});
