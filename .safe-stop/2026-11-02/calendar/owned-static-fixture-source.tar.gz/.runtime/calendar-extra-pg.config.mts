import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({ ...base, test: { ...base.test, include: [...base.test.include, 'src/features/notifications/calendarPrivacy.integration.test.ts', 'src/features/activities/reminders.test.ts'] } });
