import { defineConfig } from "vitest/config";
import base from "../vitest.config";

export default defineConfig({
  ...base,
  envDir: false,
  test: {
    ...base.test,
    maxWorkers: 1,
    fileParallelism: false,
    testTimeout: 10_000,
    hookTimeout: 10_000,
    env: {
      NODE_ENV: "test",
      DATABASE_URL: "postgres://synthetic:synthetic@127.0.0.1:1/calendar_global_unused",
      BASE_URL: "https://calendar-test.example.invalid",
      GOOGLE_CALENDAR_OAUTH_CLIENT_ID: "",
      GOOGLE_CALENDAR_OAUTH_CLIENT_SECRET: "",
      AUTH_MAIL_TRANSPORT: "capture",
      AUTH_SMTP_HOST: "",
    },
    projects: [{
      extends: true,
      test: {
        name: "unit",
        include: [
          "src/features/activities/useCalendarEventEditor.completion.test.tsx",
          "src/features/activities/CalendarEventPolish.test.tsx",
          "src/features/activities/CalendarReminderDefaultsPanel.test.tsx",
        ],
      },
    }],
  },
});
