import { defineConfig } from 'vitest/config';
import base from './calendar-complete-pg.config.mts';
export default defineConfig({ ...base, test: { ...base.test, include: [...new Set([...base.test.include,
'src/features/activities/reminderSettings.integration.test.ts',
'src/features/activities/reminderSettingsDefaults.integration.test.ts',
'src/features/activities/reminderRebuild.integration.test.ts',
'src/features/activities/reminderRebuildConcurrency.integration.test.ts',
'src/features/notifications/reminderChannels.integration.test.ts',
'src/features/activities/providers/google/accountAuthorization.integration.test.ts',
'src/features/activities/providers/google/accountTokens.integration.test.ts',
'src/features/activities/providers/google/authorizationRoutes.integration.test.ts',
'src/features/activities/providers/google/accountOffboarding.integration.test.ts',
'src/features/auth/management/offboarding.integration.test.ts',
'src/features/activities/reminderDefaultsConcurrency.integration.test.ts',
'src/features/activities/calendarReminderCatalog.integration.test.ts',
'src/features/notifications/legacyReminderPolicy.integration.test.ts'
])] } });
