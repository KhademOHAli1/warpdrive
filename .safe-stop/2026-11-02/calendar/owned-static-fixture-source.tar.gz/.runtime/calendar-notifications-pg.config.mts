import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';

export default defineConfig({
  ...base,
  test: {
    ...base.test,
    name: 'calendar-notifications-pg',
    include: [
      'src/features/notifications/calendarPrivacy.integration.test.ts',
      'src/features/notifications/reminderEmailLifecycle.integration.test.ts',
      'src/features/notifications/produce.test.ts',
      'src/features/notifications/produceVisibility.test.ts',
      'src/features/notifications/feed.test.ts',
      'src/features/notifications/feed-prefs.test.ts',
      'src/features/notifications/email/job.test.ts',
      'src/features/notifications/email/jobVisibility.test.ts',
      'src/features/notifications/email/job.german.test.ts',
    ],
  },
});
