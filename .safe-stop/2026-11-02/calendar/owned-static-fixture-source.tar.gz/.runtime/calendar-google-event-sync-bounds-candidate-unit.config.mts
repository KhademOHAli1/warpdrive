import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vitest/config';
import base from './calendar-google-event-sync-bounds-unit.config.mts';
export default defineConfig({
  ...base,
  resolve: {
    ...base.resolve,
    alias: [
      {
        find: '@/features/activities/providers/google/sync',
        replacement: fileURLToPath(new URL('./google-event-sync-bounds-draft/sync.ts', import.meta.url)),
      },
      { find: '@', replacement: fileURLToPath(new URL('../src', import.meta.url)) },
    ],
  },
});
