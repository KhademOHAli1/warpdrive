import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({
  ...base,
  test: {
    ...base.test,
    name: 'calendar-google-browser-flows',
    maxWorkers: 1,
    include: [
      'src/features/activities/providers/google/authorizationBrowserFlows.integration.test.ts',
      'src/features/activities/providers/google/accountAuthorizationLimit.integration.test.ts',
    ],
  },
});
