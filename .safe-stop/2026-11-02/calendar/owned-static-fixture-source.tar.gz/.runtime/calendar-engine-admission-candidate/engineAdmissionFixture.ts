import { eq } from "drizzle-orm";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { REMINDER_LEAD_MINUTES } from "@/constants/jobNames";
import { activities, activityReminderIntents, activityTypes, deals } from "@/db/schema";
import { seedPipelineWithStages, seedUser } from "@/db/testing/factories";
import { createActivity } from "@/features/activities/repo";
import type { PermSetUser } from "@/features/permissions/effective";
import type { TestDb } from "@/test/db";

export async function readAdmissionActivity(ctx: TestDb, id: string, signal: AbortSignal) {
  signal.throwIfAborted();
  const [row] = await ctx.db.select().from(activities).where(eq(activities.id, id));
  signal.throwIfAborted();
  if (row === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "engine admission activity absent");
  return row;
}

export async function engineAdmissionFixture(ctx: TestDb, signal: AbortSignal) {
  signal.throwIfAborted();
  const recipient = await seedUser(ctx.db, {
    name: "Engine admission recipient",
    isAdmin: false,
    isActive: true,
  });
  signal.throwIfAborted();
  const actor: PermSetUser = {
    id: recipient.id,
    type: "regular",
    isActive: true,
    flags: new Set(),
    groupIds: new Set(),
  };
  const { pipeline, stages } = await seedPipelineWithStages(ctx.db, ["Open"]);
  signal.throwIfAborted();
  const stage = stages[0];
  if (stage === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "engine admission stage absent");
  const [deal] = await ctx.db
    .insert(deals)
    .values({
      title: "Engine admission CRM parent",
      pipelineId: pipeline.id,
      stageId: stage.id,
      ownerId: recipient.id,
      visibilityLevel: "owner",
    })
    .returning();
  signal.throwIfAborted();
  const [type] = await ctx.db.select().from(activityTypes).where(eq(activityTypes.key, "meeting"));
  signal.throwIfAborted();
  if (deal === undefined || type === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "engine admission parent or type absent");
  const dueAt = new Date(Date.now() + 6 * 60 * 60_000);
  const fireAt = new Date(dueAt.getTime() - REMINDER_LEAD_MINUTES * 60_000);
  // Supply only canonical old-writer columns. The test-only DB default chooses legacy.
  const inserted = await ctx.pool.query<{ id: string }>(
    `INSERT INTO activities
     (type_id, subject, due_at, all_day, owner_id, assignee_id, deal_id)
     VALUES ($1,$2,$3,false,$4,$4,$5) RETURNING id`,
    [type.id, "Legacy engine with backfill-shaped intent", dueAt, recipient.id, deal.id],
  );
  signal.throwIfAborted();
  const legacyId = inserted.rows[0]?.id;
  if (legacyId === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "engine admission old-writer insert absent");
  const legacy = await readAdmissionActivity(ctx, legacyId, signal);
  // This deliberately invalid ownership combination models the old native blanket seed.
  // It is not an admitted engine transition or an authentic notification receipt.
  const [legacyIntent] = await ctx.db
    .insert(activityReminderIntents)
    .values({
      activityId: legacy.id,
      assigneeId: recipient.id,
      settingsId: null,
      settingsVersion: 0,
      defaultsVersion: 0,
      eventSignature: "",
      dueAt,
      fireAt,
      inApp: true,
      email: true,
      state: "pending",
    })
    .returning();
  signal.throwIfAborted();
  if (legacyIntent === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "engine admission legacy intent absent");
  const created = await createActivity(
    ctx.db,
    actor,
    {
      typeId: type.id,
      subject: "Actual native engine admission control",
      dealId: deal.id,
      dueAt: dueAt.toISOString(),
      personalReminders: {
        expectedRevision: 0,
        selection: {
          useDefault: false,
          timed: [
            { method: "notification", minutesBefore: REMINDER_LEAD_MINUTES },
            { method: "email", minutesBefore: REMINDER_LEAD_MINUTES },
          ],
          allDay: [],
        },
      },
    },
    signal,
  );
  signal.throwIfAborted();
  if (!created.ok) throw created.error;
  const nativeIntents = await ctx.db
    .select()
    .from(activityReminderIntents)
    .where(eq(activityReminderIntents.activityId, created.value.id));
  signal.throwIfAborted();
  const nativeIntent = nativeIntents[0];
  if (nativeIntent === undefined || nativeIntents.length !== 1)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "engine admission native intent count changed");
  return {
    recipient,
    deal,
    dueAt,
    fireAt,
    legacy,
    legacyIntent,
    native: created.value,
    nativeIntent,
  };
}
