# Engine ownership admission diagnostic

Source only, native-unrun. Pinned Biome passed on six files, formatting one.
Compiler, typed lint, tests, database, container and provider execution remain unrun. No production source or canonical SQL is edited.

The case creates a genuine canonical-column old-writer Activity whose test-only engine default
is legacy. A deliberately incompatible persisted native intent has the old blanket-seed shape:
null settings, zero revisions, empty signature, matching active assignee/due and both channels.
The fire time uses the existing 10-minute lead, matching the old 0085 blanket seed; the actual
native positive control uses that same lead and instant for both channels.
Its future timed date removes all-day and schedule-age ambiguity. Direct admission is an
eligibility check, not proof of due-time dispatch or transport submission.

An actual native `createActivity` with explicit notification and email rules supplies an
intent-owned positive control. Both channels must be admitted for that row. The legacy row's
regular active recipient must also pass actual current CRM visibility and the legacy policy
check before the final ownership assertion. No notification or job is produced.

Expected behavioral RED: actual `admitReminderIntent` admits both channels for the legacy-owned
row because it currently never checks the engine field. A missing row/schema, failed native
control, denied CRM/policy check or setup failure is not this RED. The stored Activity, intent
and empty legacy settings must remain unchanged through direct admission.

This negative state fixture is not an authorized takeover. It does not simulate ownership
transfer by raw marker update. It must not be used to deny authentic unlinked legacy in-app
history wholesale; historical receipt policy is a separate compatibility requirement.

The configuration reuses the existing owned cached-PostgreSQL setup, test-only engine column
and exact cleanup seam. It uses one worker, no provider credentials, an unusable global DB
endpoint, captured mail and the existing rejected-fetch setup. No password/DB URL is emitted.

Canonical upgrade, installed acceptance, compatible legacy workers, shared-lock takeover,
receipt transfer, old-consumer draining and canonical final MAIL admission remain open.
Proposed bounded commands and source hashes are in the continuation output handoff.
