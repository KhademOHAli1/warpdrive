import { eq } from "drizzle-orm";
import { expect, it } from "vitest";
import { activityReminderIntents, activityReminderSettings, notifications } from "@/db/schema";
import {
  admitReminderIntent,
  canUseLegacyReminderPolicy,
} from "@/features/activities/reminderAdmission";
import { mayReceivePersonalReminder } from "@/features/activities/reminderPolicies";
import { makeTestDb } from "@/test/db";
import { engineAdmissionFixture, readAdmissionActivity } from "./engineAdmissionFixture";

it("denies native intent admission for a legacy-owned activity in both channels after native and current-access controls", async () => {
  const signal = AbortSignal.timeout(20_000);
  const ctx = await makeTestDb();
  try {
    const fixture = await engineAdmissionFixture(ctx, signal);
    const { recipient, deal, dueAt, fireAt, legacy, legacyIntent, native, nativeIntent } = fixture;
    expect(recipient).toMatchObject({ isActive: true, isAdmin: false });
    expect(legacy).toMatchObject({
      reminderEngine: "legacy",
      reminderAutomationEnabled: true,
      calendarId: null,
      dealId: deal.id,
      assigneeId: recipient.id,
      dueAt,
      allDay: false,
      done: false,
      deletedAt: null,
    });
    expect(legacyIntent).toMatchObject({
      activityId: legacy.id,
      assigneeId: recipient.id,
      settingsId: null,
      settingsVersion: 0,
      defaultsVersion: 0,
      eventSignature: "",
      inApp: true,
      email: true,
      dueAt,
      fireAt,
      state: "pending",
      notificationId: null,
      deliveredAt: null,
    });
    expect(dueAt.getTime()).toBeGreaterThan(Date.now());
    expect(fireAt.getTime()).toBeGreaterThan(Date.now());
    expect(native).toMatchObject({ reminderEngine: "intent", dealId: deal.id, dueAt });
    expect(nativeIntent).toMatchObject({
      inApp: true,
      email: true,
      state: "pending",
      dueAt,
      fireAt,
    });
    expect(nativeIntent.settingsId).not.toBeNull();
    expect(await admitReminderIntent(ctx.db, native, nativeIntent, signal, "inApp")).toBe(true);
    expect(await admitReminderIntent(ctx.db, native, nativeIntent, signal, "email")).toBe(true);
    expect(await mayReceivePersonalReminder(ctx.db, legacy, recipient.id, signal)).toBe(true);
    expect(await canUseLegacyReminderPolicy(ctx.db, legacy, recipient.id, signal)).toBe(true);

    // Direct admission isolates ownership from send preferences, queue timing and transport.
    const admission = {
      inApp: await admitReminderIntent(ctx.db, legacy, legacyIntent, signal, "inApp"),
      email: await admitReminderIntent(ctx.db, legacy, legacyIntent, signal, "email"),
    };
    signal.throwIfAborted();
    expect(await readAdmissionActivity(ctx, legacy.id, signal)).toEqual(legacy);
    expect(
      await ctx.db
        .select()
        .from(activityReminderSettings)
        .where(eq(activityReminderSettings.activityId, legacy.id)),
    ).toEqual([]);
    expect(
      await ctx.db
        .select()
        .from(activityReminderIntents)
        .where(eq(activityReminderIntents.activityId, legacy.id)),
    ).toEqual([legacyIntent]);
    expect(await ctx.db.select().from(notifications)).toEqual([]);
    signal.throwIfAborted();
    // Intended RED: every other real policy/access guard passes, but ownership is not checked.
    expect(admission).toEqual({ inApp: false, email: false });
  } finally {
    await ctx.close();
  }
});
