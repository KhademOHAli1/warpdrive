import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';
import { existsSync } from 'node:fs';
import { Pool } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';

export default async function setup(project) {
  const binary = '/opt/homebrew/opt/postgresql@16/bin/';
  const data = resolve('.runtime/calendar-pg/data');
  if (!existsSync(data + '/PG_VERSION')) execFileSync(binary + 'initdb', ['-D', data, '--username=calendar_test', '--auth=trust', '--no-locale', '--encoding=UTF8'], { stdio: 'ignore' });
  execFileSync(binary + 'pg_ctl', ['-D', data, '-l', resolve('.runtime/calendar-pg/server.log'), '-o', "-h 127.0.0.1 -p 54672 -c unix_socket_directories='' -c fsync=off", '-w', 'start'], { stdio: 'ignore' });
  const stop = () => execFileSync(binary + 'pg_ctl', ['-D', data, '-m', 'fast', '-w', 'stop'], { stdio: 'ignore' });
  const base = { host: '127.0.0.1', port: 54672, user: 'calendar_test', password: '', max: 2 };
  const admin = new Pool({ ...base, database: 'postgres' });
  const template = 'calendar_template';
  try {
    await admin.query('DROP DATABASE IF EXISTS calendar_template');
    await admin.query('CREATE DATABASE calendar_template');
    const pool = new Pool({ ...base, database: template });
    try {
      await pool.query('CREATE EXTENSION IF NOT EXISTS pgcrypto');
      await pool.query('CREATE EXTENSION IF NOT EXISTS citext');
      await migrate(drizzle(pool), { migrationsFolder: resolve('drizzle') });
    } finally { await pool.end(); }
    project.provide('testPg', { ...base, adminDatabase: 'postgres', template });
  } catch (error) { await admin.end(); stop(); throw error; }
  return async () => { await admin.end(); stop(); };
}
