import { checkWorkspace, demand, exclusiveJson, FILES, FIXTURE, newPool, privateJson, type SeedReceipt } from './calendar-browser-catalog-seed.mts';
const phase = process.argv[2];
const versions: Record<string, number> = { added: 1, removed: 2, readded: 3, disconnected: 3 };
demand(phase !== undefined && versions[phase] !== undefined, 'Unknown observation phase');
checkWorkspace();
const receipt = privateJson(FILES.seedReceipt) as SeedReceipt;
demand(receipt.status === 'committed', 'Seed receipt is not committed');
const pool = newPool();
try {
  const result = await pool.query(`SELECT a.status,a.version AS account_version,a.connection_generation,
    a.refresh_token_enc IS NULL AS refresh_cleared,b.id AS binding_id,b.local_calendar_id,
    b.selected,b.version AS binding_version,c.source,c.is_primary,c.time_zone
    FROM calendar_provider_accounts a
    LEFT JOIN calendar_provider_bindings b ON b.provider_calendar_id=$3 AND b.user_id=a.user_id
    LEFT JOIN calendars c ON c.id=b.local_calendar_id
    WHERE a.id=$1 AND a.user_id=$2`, [receipt.ids.accountId, FIXTURE.ownerId, receipt.ids.writerEntryId]);
  demand(result.rows.length === 1, 'Expected one exact synthetic binding observation');
  const row = result.rows[0];
  demand(row.binding_version === versions[phase] && row.selected === (phase !== 'removed'), 'Unexpected selection revision/state');
  demand(row.source === 'provider' && row.is_primary === false && row.time_zone === 'Asia/Tehran', 'Dedicated container source/zone differs');
  demand(row.status === (phase === 'disconnected' ? 'disconnected' : 'connected'), 'Unexpected account status');
  if (phase === 'disconnected') demand(row.account_version === 2 && row.connection_generation === 2 && row.refresh_cleared === true, 'Disconnect fence differs');
  exclusiveJson(`.runtime/calendar-browser-catalog-${phase}.json`, { observedAt: new Date().toISOString(), phase, ...row });
  console.log(JSON.stringify({ phase, ...row }));
} finally { await pool.end(); }
