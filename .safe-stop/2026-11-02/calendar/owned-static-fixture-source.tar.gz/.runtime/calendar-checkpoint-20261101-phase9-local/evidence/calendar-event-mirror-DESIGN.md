# Proposed raw Google event mirror, source planning only

No production, tests, database, migration, app or provider execution is established by this design. Finish the OAuth lock-wait correction and compact panel browser acceptance first. Keep migration 0092 pinned until the preserved-fixture upgrade/seed/cleanup is complete.

The next slice is a server-only raw mirror for explicitly selected provider calendars. It creates no Activities, reminders, notifications, outbound writes or Meet readiness. Existing Activity creation allocates new IDs and enables reminders, so it cannot be reused as an idempotent import adapter.

## Proposed model

- Mirror state: latest run UUID/deadline, captured account generation, binding version, catalog authority and base publication revision; separate published revision, full snapshot epoch, cursor and query-contract version.
- Stable events: local UUID, provider calendar UUID, exact opaque event ID plus generated hash uniqueness and exact collision guard, raw JSON, nullable ETag, tombstone reason and publication/epoch markers. Never apply the insertion-ID regex to provider recurring-instance IDs.
- Run staging: private page data keyed by run UUID and event identity. Superseded/expired staging has no query authority and needs bounded reclamation.

## Authority and publication

Obtain a fresh access grant, then begin under owner-first locks. Require active owner, connected/current generation, selected/current binding, nondeleted provider-source local calendar and current readable catalog authority. Capture and recheck all conditions for staging/publication; routine credential rotation keeps generation, while reconnect, deselection/re-addition, permission changes and newer runs fence older work.

Publish changes, cursor and revision atomically. Sample deadlines after locks and before final publication. Roll back tentative batches on expiry/storage failure. Failure bookkeeping may change only its own current run. Read the starting cursor under state lock and fence against its base publication revision. Changed generation, binding version or query contract forces full sync.

Full publication advances the full-snapshot epoch. Omitted rows become unavailable tombstones while retaining IDs. Incremental publication changes only returned rows; absence means unchanged. HTTP 410 invalidates cursor authority and sets needsFull. Retain prior data as unavailable history until a complete full rebuild publishes.

Preserve raw recurrence masters/rules, exception recurringEventId and exact originalStartTime, including sparse cancellations. Do not reconstruct missing fields or expand occurrences in this package. Owner-only queries recheck current authority and expose bounded safe DTOs, never raw payloads/cursors.

## Transport prerequisite

Reuse getCalendarAccessGrant, eventsList and ownership/binding/catalog seams. First extend sync.ts with page/item/byte bounds and duplicate event-ID rejection. Add event-specific PostgreSQL-safe JSON bounds; do not silently inherit the catalog entry limit.

## Proposed real-PostgreSQL scenarios

1. Multipage full publication, long opaque IDs, recurrence preservation.
2. Incremental update/cancellation with unchanged rows retained.
3. Empty full versus empty incremental results.
4. Later-page failure, abort and witnessed mid-batch storage rollback.
5. Competing successes and newer-failure/older-success ordering.
6. HTTP 410 followed by successful/failed full rebuilds.
7. Refresh, reconnect, deselection/re-addition and permission races.
8. Wrong/inactive owner and deleted local-calendar denial.
9. Stable identity, hash collisions, deadlines and zero Activity/reminder side effects.
