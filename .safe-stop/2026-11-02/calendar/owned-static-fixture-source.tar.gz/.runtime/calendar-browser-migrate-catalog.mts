import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { Pool } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { env } from '../src/config/env';

const fixture = JSON.parse(readFileSync('.runtime/calendar-browser-fixture.json', 'utf8'));
const target = new URL(env.DATABASE_URL);
if (fixture.database !== 'calendar_browser_1793457725214' || target.hostname !== '127.0.0.1' ||
    target.port !== '54673' || target.pathname !== `/${fixture.database}`)
  throw new Error('Only the original preserved Calendar browser fixture is allowed');
const journal = JSON.parse(readFileSync('drizzle/meta/_journal.json', 'utf8'));
const previous = journal.entries.at(-2);
const latest = journal.entries.at(-1);
if (previous?.tag !== '0091_calendar_connection_generation' || latest?.tag !== '0092_calendar_provider_catalog')
  throw new Error('Migration boundary changed; review source first');
const hash = (tag: string) => createHash('sha256').update(readFileSync(`drizzle/${tag}.sql`)).digest('hex');
const pool = new Pool({ connectionString: env.DATABASE_URL, max: 1 });
try {
  const clients = await pool.query('SELECT count(*)::int AS count FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid()');
  if (clients.rows[0].count !== 0) throw new Error('Another fixture client is active; stop the owned preview first');
  const history = (await pool.query('SELECT hash,created_at::text FROM drizzle.__drizzle_migrations ORDER BY created_at DESC LIMIT 1')).rows[0];
  if (history?.hash !== hash(previous.tag) || history.created_at !== String(previous.when))
    throw new Error('Preserved fixture is not exactly at reviewed migration0091; do not rerun');
  const columns = await pool.query("SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='calendars' AND column_name='source'");
  if (columns.rowCount !== 0) throw new Error('Source migration already applied; preserve original before/after evidence');
  const providerCounts = async () => (await pool.query('SELECT (SELECT count(*)::int FROM calendar_provider_accounts) AS accounts,(SELECT count(*)::int FROM calendar_oauth_attempts) AS attempts')).rows[0];
  const counts = await providerCounts();
  if (counts.accounts !== 0 || counts.attempts !== 0) throw new Error('Provider state differs from unconfigured acceptance fixture');
  const snapshot = async (upgraded = false) => (await pool.query(`SELECT
    (SELECT coalesce(jsonb_agg(to_jsonb(a) ORDER BY id),'[]'::jsonb) FROM activities a) AS events,
    (SELECT coalesce(jsonb_agg(${upgraded ? "to_jsonb(c)-'source'" : 'to_jsonb(c)'} ORDER BY id),'[]'::jsonb) FROM calendars c) AS calendars`)).rows[0];
  const before = await snapshot();
  if (before.events.length !== 4) throw new Error('Known four-event fixture changed; review before mutation');
  writeFileSync('.runtime/calendar-browser-catalog-migration-before.json', JSON.stringify({ observedAt: new Date().toISOString(), migration: latest.tag, fixture: fixture.database, before }, null, 2)+'\n');
  await migrate(drizzle(pool), { migrationsFolder: resolve('drizzle') });
  const after = await snapshot(true);
  if (JSON.stringify(before) !== JSON.stringify(after)) throw new Error('Migration changed original event/calendar fields or revisions');
  const afterCounts = await providerCounts();
  if (JSON.stringify(counts) !== JSON.stringify(afterCounts)) throw new Error('Provider account/attempt counts changed');
  const sources = (await pool.query('SELECT id,source FROM calendars ORDER BY id')).rows;
  if (!sources.every((row: { source: string }) => row.source === 'native')) throw new Error('Existing calendars were not retained as native');
  const tables = (await pool.query("SELECT (SELECT count(*)::int FROM calendar_provider_catalog_states) AS states,(SELECT count(*)::int FROM calendar_provider_calendars) AS entries,(SELECT count(*)::int FROM calendar_provider_bindings) AS bindings")).rows[0];
  if (tables.states !== 0 || tables.entries !== 0 || tables.bindings !== 0) throw new Error('Migration synthesized provider catalog or bindings');
  const migrated = (await pool.query('SELECT hash,created_at::text FROM drizzle.__drizzle_migrations ORDER BY created_at DESC LIMIT 1')).rows[0];
  if (migrated?.hash !== hash(latest.tag) || migrated.created_at !== String(latest.when)) throw new Error('Migration source hash/history mismatch');
  const evidence = {
    observedAt: new Date().toISOString(), migration: latest.tag, sourceHash: migrated.hash,
    fixture: fixture.database, eventCount: before.events.length, calendarCount: before.calendars.length,
    originalEventAndCalendarFieldsAndVersionsPreserved: true,
    allExistingCalendarsRemainNative: true, providerAccounts: afterCounts.accounts,
    oauthAttempts: afterCounts.attempts, catalogStates: tables.states, catalogEntries: tables.entries,
    bindings: tables.bindings, databaseRecreated: false, applicationRestarted: false,
    limits: ['Preserved synthetic unconfigured fixture only.', 'Local0092 numbering is unreconciled; no accepted integrated cut or installed-upgrade proof.', 'No old/new binary coexistence, configured browser workflow or real provider acceptance.'],
  };
  writeFileSync('.runtime/calendar-browser-catalog-migration.json', JSON.stringify(evidence, null, 2)+'\n');
  console.log(JSON.stringify(evidence, null, 2));
} finally { await pool.end(); }
