import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({...base,test:{...base.test,name:'calendar-reminder-defaults-implicit-pg',maxWorkers:1,include:['src/features/activities/reminderDefaultsImplicit.integration.test.ts']}});
