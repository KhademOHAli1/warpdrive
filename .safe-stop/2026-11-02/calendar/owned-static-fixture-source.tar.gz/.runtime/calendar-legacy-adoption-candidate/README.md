# Explicit owner reminder adoption diagnostic

Source-only, native-unrun three-case packet. Pinned Biome passed on six files, formatting five.
Compiler, typed lint, tests, database, container and provider execution remain unrun. This folder changes no production code,
canonical SQL, migration metadata or existing fixture.

The fixture inserts an Activity using canonical old-writer columns only. Its engine
must default to legacy, with no modern settings or intent. An actual authorized
`updateActivity` then attaches an owned native calendar without personal rules and
must leave that row legacy with no native policy/intent. This setup gives the same
event an actual calendar-reader grant. The later mutation uses the authoritative
version returned by that setup edit. Both actors are regular users, not admins.

The three future cases are:

1. An authorized owner/assignee edits the future schedule and explicitly chooses
   notification-only personal rules through `updateActivity`. Event/CAS/CRM persistence,
   stored personal revision/rules, no notification side effect and an actual equivalent
   native-create positive control must pass before the final intent-ownership/plan
   assertion. Current source should fail that final assertion: it persists rules but
   the legacy reconcile guard creates no intent.
2. An ordinary authorized legacy schedule edit without personal rules remains legacy,
   with no modern policy, intent or notification.
3. An actual calendar reader can read this event's reminder context, but cannot mutate
   or adopt the shared event through `updateActivity`; the whole event/reminder state
   must remain unchanged after `ACTIVITY_FORBIDDEN`.

Expected selection is two controls PASS and one intended behavioral RED, not observed
results. A missing schema, failed permission/fixture/native-create control or setup
failure is not the desired RED. All database state is real PostgreSQL. Existing cached
test-only template/engine-column setup and owned-container cleanup are reused unchanged;
the case closes its cloned database. No PgBoss worker, HTTP service or provider starts.

This tests explicit owner adoption only. It does not establish compatible legacy
delivery, shared-lock races, durable receipt transfer, old-consumer draining/fencing,
canonical installed upgrade or final durable email admission. In particular, do not
flip global ownership in the personal-settings helper: readers may invoke that helper
under their existing personal-only contract. The adoption fix still needs the accepted
legacy callback/takeover locking and receipt-transfer contract before rollout.

Exact proposed commands, hashes, source review and these limits are in the continuation
output folder `Calendar_Legacy_Adoption_Preparation_2026-11-02`. A fresh Settings slot and
static qualification are required before any future database execution.
