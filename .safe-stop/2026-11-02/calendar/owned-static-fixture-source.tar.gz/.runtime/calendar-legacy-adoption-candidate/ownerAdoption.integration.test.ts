import { afterEach, beforeEach, expect, it } from "vitest";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { updateActivity } from "@/features/activities/activityUpdate";
import { getEventReminderSettings } from "@/features/activities/personalReminderSettings";
import { admitReminderIntent } from "@/features/activities/reminderAdmission";
import { createActivity } from "@/features/activities/repo";
import {
  type AdoptionFixture,
  adoptionFixture,
  adoptionState,
  personalRules,
  personalWrite,
} from "./fixture";

let fixture: AdoptionFixture | undefined;
const signal = () => AbortSignal.timeout(20_000);
beforeEach(async () => {
  fixture = await adoptionFixture(signal());
});
afterEach(async () => {
  await fixture?.ctx.close();
  fixture = undefined;
});
function current(): AdoptionFixture {
  if (fixture === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "adoption fixture absent");
  return fixture;
}
function shifted(f: AdoptionFixture) {
  if (f.initial.row.dueAt === null || f.initial.row.endAt === null)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "adoption fixture requires timed bounds");
  return {
    dueAt: new Date(f.initial.row.dueAt.getTime() + 60 * 60_000),
    endAt: new Date(f.initial.row.endAt.getTime() + 60 * 60_000),
  };
}

it("adopts a legacy event only when its authorized owner explicitly saves personal reminder rules", async () => {
  const f = current();
  const sig = signal();
  const dates = shifted(f);
  const edited = await updateActivity(
    f.ctx.db,
    f.owner,
    {
      id: f.initial.row.id,
      expectedVersion: f.initial.row.version,
      subject: "Explicit owner reminder choice / یادآوری",
      dueAt: dates.dueAt.toISOString(),
      endAt: dates.endAt.toISOString(),
      personalReminders: personalWrite,
    },
    sig,
  );
  sig.throwIfAborted();
  expect(edited.ok).toBe(true);
  if (!edited.ok) throw edited.error;
  const saved = await adoptionState(f.ctx, f.initial.row.id, sig);
  expect(saved.row).toMatchObject({
    id: f.initial.row.id,
    ownerId: f.owner.id,
    assigneeId: f.owner.id,
    subject: "Explicit owner reminder choice / یادآوری",
    ...dates,
    ...f.crm,
    calendarId: f.calendarId,
    version: f.initial.row.version + 1,
    customFields: f.initial.row.customFields,
    note: f.initial.row.note,
    location: f.initial.row.location,
    reminderAutomationEnabled: true,
  });
  expect(edited.value).toMatchObject({
    id: saved.row.id,
    version: saved.row.version,
    ...dates,
    ...f.crm,
  });
  expect(saved.settings).toMatchObject([
    {
      activityId: saved.row.id,
      userId: f.owner.id,
      source: "personal",
      version: 1,
      useDefault: false,
      rules: personalRules,
      timeZone: "Asia/Tehran",
    },
  ]);
  expect(saved.settings).toHaveLength(1);
  expect(saved.rebuilds).toEqual([]);
  expect(saved.notices).toEqual([]);

  // Equivalent rules must work through an actual native create before the adoption oracle.
  const native = await createActivity(
    f.ctx.db,
    f.owner,
    {
      typeId: f.typeId,
      subject: "Native adoption positive control",
      calendarId: f.calendarId,
      eventTimeZone: "Asia/Tehran",
      dueAt: dates.dueAt.toISOString(),
      endAt: dates.endAt.toISOString(),
      ...f.crm,
      personalReminders: personalWrite,
    },
    sig,
  );
  sig.throwIfAborted();
  expect(native.ok).toBe(true);
  if (!native.ok) throw native.error;
  const control = await adoptionState(f.ctx, native.value.id, sig);
  const expectedIntent = {
    assigneeId: f.owner.id,
    state: "pending",
    dueAt: dates.dueAt,
    fireAt: new Date(dates.dueAt.getTime() - 30 * 60_000),
    settingsVersion: 1,
    defaultsVersion: 0,
    inApp: true,
    email: false,
    notificationId: null,
    deliveredAt: null,
  };
  expect(control.row.reminderEngine).toBe("intent");
  expect(control.settings).toHaveLength(1);
  expect(control.settings).toMatchObject([
    {
      activityId: native.value.id,
      userId: f.owner.id,
      source: "personal",
      version: 1,
      useDefault: false,
      rules: personalRules,
    },
  ]);
  expect(control.intents).toHaveLength(1);
  expect(control.intents).toMatchObject([
    {
      ...expectedIntent,
      activityId: native.value.id,
      settingsId: control.settings[0]?.id,
    },
  ]);
  expect(control.notices).toEqual([]);
  const controlIntent = control.intents[0];
  if (controlIntent === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "native adoption control intent absent");
  expect(await admitReminderIntent(f.ctx.db, control.row, controlIntent, sig, "inApp")).toBe(true);

  // Expected behavior RED: the saved legacy rules currently produce no owned native plan.
  expect({ engine: saved.row.reminderEngine, intents: saved.intents }).toMatchObject({
    engine: "intent",
    intents: [{ ...expectedIntent, activityId: saved.row.id, settingsId: saved.settings[0]?.id }],
  });
  expect(saved.intents).toHaveLength(1);
  const adoptedIntent = saved.intents[0];
  if (adoptedIntent === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "adopted reminder intent absent after assertion");
  expect(await admitReminderIntent(f.ctx.db, saved.row, adoptedIntent, sig, "inApp")).toBe(true);
});

it("keeps an ordinary authorized legacy event edit outside native reminder adoption", async () => {
  const f = current();
  const sig = signal();
  const dates = shifted(f);
  const edited = await updateActivity(
    f.ctx.db,
    f.owner,
    {
      id: f.initial.row.id,
      expectedVersion: f.initial.row.version,
      subject: "Ordinary legacy schedule edit",
      dueAt: dates.dueAt.toISOString(),
      endAt: dates.endAt.toISOString(),
    },
    sig,
  );
  sig.throwIfAborted();
  expect(edited.ok).toBe(true);
  if (!edited.ok) throw edited.error;
  const saved = await adoptionState(f.ctx, f.initial.row.id, sig);
  expect(saved.row).toMatchObject({
    id: f.initial.row.id,
    reminderEngine: "legacy",
    calendarId: f.calendarId,
    subject: "Ordinary legacy schedule edit",
    ...dates,
    ...f.crm,
    ownerId: f.owner.id,
    assigneeId: f.owner.id,
    version: f.initial.row.version + 1,
    customFields: f.initial.row.customFields,
    note: f.initial.row.note,
    location: f.initial.row.location,
  });
  expect(saved.row).toEqual(edited.value);
  expect({
    settings: saved.settings,
    intents: saved.intents,
    rebuilds: saved.rebuilds,
    notices: saved.notices,
  }).toEqual({ settings: [], intents: [], rebuilds: [], notices: [] });
});

it("does not let a calendar reader adopt or mutate a legacy event through the owner edit path", async () => {
  const f = current();
  const sig = signal();
  // Actual readable-context admission prevents an invisible-record rejection from masking the guard.
  const readable = await getEventReminderSettings(f.ctx.db, f.reader, f.initial.row.id, sig);
  sig.throwIfAborted();
  expect(readable.ok).toBe(true);
  const before = await adoptionState(f.ctx, f.initial.row.id, sig);
  const rejected = await updateActivity(
    f.ctx.db,
    f.reader,
    {
      id: f.initial.row.id,
      expectedVersion: f.initial.row.version,
      subject: "Reader must not mutate",
      personalReminders: personalWrite,
    },
    sig,
  );
  sig.throwIfAborted();
  expect(rejected).toMatchObject({ ok: false, error: { id: ERROR_IDS.ACTIVITY_FORBIDDEN } });
  expect(await adoptionState(f.ctx, f.initial.row.id, sig)).toEqual(before);
});
