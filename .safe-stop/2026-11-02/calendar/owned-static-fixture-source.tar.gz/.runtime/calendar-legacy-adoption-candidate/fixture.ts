import { eq } from "drizzle-orm";
import { expect } from "vitest";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import {
  activities,
  activityReminderIntents,
  activityReminderSettings,
  activityTypes,
  deals,
  notifications,
  organizations,
  persons,
  reminderRebuilds,
} from "@/db/schema";
import { seedPipelineWithStages, seedUser } from "@/db/testing/factories";
import { updateActivity } from "@/features/activities/activityUpdate";
import { createCalendar, setCalendarMember } from "@/features/activities/calendars";
import type { PermSetUser } from "@/features/permissions/effective";
import { makeTestDb, type TestDb } from "@/test/db";

export const personalRules = {
  timed: [{ method: "notification" as const, minutesBefore: 30 }],
  allDay: [],
};
export const personalWrite = {
  expectedRevision: 0,
  selection: { useDefault: false as const, ...personalRules },
};

async function actor(ctx: TestDb, name: string, signal: AbortSignal): Promise<PermSetUser> {
  const user = await seedUser(ctx.db, { name, isAdmin: false });
  signal.throwIfAborted();
  return { id: user.id, type: "regular", isActive: true, flags: new Set(), groupIds: new Set() };
}

async function crmParents(ctx: TestDb, ownerId: string, signal: AbortSignal) {
  const { pipeline, stages } = await seedPipelineWithStages(ctx.db, ["Open"]);
  signal.throwIfAborted();
  const stage = stages[0];
  if (stage === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "adoption stage absent");
  const [org] = await ctx.db
    .insert(organizations)
    .values({
      name: "Legacy adoption organization",
      ownerId,
      visibilityLevel: "all",
    })
    .returning();
  signal.throwIfAborted();
  if (org === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "adoption organization absent");
  const [person] = await ctx.db
    .insert(persons)
    .values({
      name: "Legacy adoption contact",
      orgId: org.id,
      ownerId,
      visibilityLevel: "all",
    })
    .returning();
  signal.throwIfAborted();
  if (person === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "adoption person absent");
  const [deal] = await ctx.db
    .insert(deals)
    .values({
      title: "Legacy adoption deal",
      pipelineId: pipeline.id,
      stageId: stage.id,
      personId: person.id,
      orgId: org.id,
      ownerId,
      visibilityLevel: "all",
    })
    .returning();
  signal.throwIfAborted();
  if (deal === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "adoption deal absent");
  return { dealId: deal.id, personId: person.id, orgId: org.id };
}

export async function adoptionState(ctx: TestDb, id: string, signal: AbortSignal) {
  signal.throwIfAborted();
  const [rows, settings, intents, rebuilds, notices] = await Promise.all([
    ctx.db.select().from(activities).where(eq(activities.id, id)),
    ctx.db
      .select()
      .from(activityReminderSettings)
      .where(eq(activityReminderSettings.activityId, id))
      .orderBy(activityReminderSettings.id),
    ctx.db
      .select()
      .from(activityReminderIntents)
      .where(eq(activityReminderIntents.activityId, id))
      .orderBy(activityReminderIntents.id),
    ctx.db.select().from(reminderRebuilds).where(eq(reminderRebuilds.activityId, id)),
    ctx.db.select().from(notifications).orderBy(notifications.id),
  ]);
  signal.throwIfAborted();
  const row = rows[0];
  if (row === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "adoption Activity absent");
  return { row, settings, intents, rebuilds, notices };
}

export async function adoptionFixture(signal: AbortSignal) {
  signal.throwIfAborted();
  const ctx = await makeTestDb();
  try {
    const owner = await actor(ctx, "Legacy adoption owner", signal);
    const reader = await actor(ctx, "Legacy adoption reader", signal);
    const crm = await crmParents(ctx, owner.id, signal);
    const [type] = await ctx.db
      .select()
      .from(activityTypes)
      .where(eq(activityTypes.key, "meeting"));
    signal.throwIfAborted();
    if (type === undefined)
      throw new AppError(ERROR_IDS.DB_INVARIANT, "adoption meeting type absent");
    const calendar = await createCalendar(
      ctx.db,
      owner,
      {
        name: "Legacy adoption calendar",
        timeZone: "Asia/Tehran",
      },
      signal,
    );
    signal.throwIfAborted();
    if (!calendar.ok) throw calendar.error;
    const membership = await setCalendarMember(
      ctx.db,
      owner,
      {
        calendarId: calendar.value.id,
        userId: reader.id,
        role: "reader",
      },
      signal,
    );
    signal.throwIfAborted();
    if (!membership.ok) throw membership.error;
    const dueAt = new Date(Date.now() + 24 * 60 * 60_000);
    const endAt = new Date(dueAt.getTime() + 45 * 60_000);
    // The original writer supplies canonical columns only, with no engine or calendar authority.
    const inserted = await ctx.pool.query<{ id: string }>(
      `INSERT INTO activities
       (type_id,subject,due_at,end_at,owner_id,assignee_id,deal_id,person_id,org_id,
        custom_fields,note,location)
       VALUES ($1,$2,$3,$4,$5,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
      [
        type.id,
        "Legacy owner adoption",
        dueAt,
        endAt,
        owner.id,
        crm.dealId,
        crm.personId,
        crm.orgId,
        { legacy: "preserve" },
        "<p>Legacy note</p>",
        "Legacy location",
      ],
    );
    signal.throwIfAborted();
    const id = inserted.rows[0]?.id;
    if (id === undefined)
      throw new AppError(ERROR_IDS.DB_INVARIANT, "adoption old writer insert absent");
    const raw = await adoptionState(ctx, id, signal);
    expect(raw.row).toMatchObject({ reminderEngine: "legacy", calendarId: null, ...crm });
    expect({ settings: raw.settings, intents: raw.intents, notices: raw.notices }).toEqual({
      settings: [],
      intents: [],
      notices: [],
    });

    // Ordinary calendar attachment must not itself authorize reminder adoption.
    // This gives the reader a genuine grant on this same old-writer event.
    const attached = await updateActivity(
      ctx.db,
      owner,
      {
        id,
        expectedVersion: raw.row.version,
        calendarId: calendar.value.id,
      },
      signal,
    );
    signal.throwIfAborted();
    expect(attached.ok).toBe(true);
    if (!attached.ok) throw attached.error;
    const initial = await adoptionState(ctx, id, signal);
    expect(initial.row).toMatchObject({
      reminderEngine: "legacy",
      calendarId: calendar.value.id,
      version: raw.row.version + 1,
      ...crm,
    });
    expect(initial.row).toEqual(attached.value);
    expect({
      settings: initial.settings,
      intents: initial.intents,
      rebuilds: initial.rebuilds,
    }).toEqual({ settings: [], intents: [], rebuilds: [] });
    return { ctx, owner, reader, crm, typeId: type.id, calendarId: calendar.value.id, initial };
  } catch (error) {
    await ctx.close();
    throw error;
  }
}

export type AdoptionFixture = Awaited<ReturnType<typeof adoptionFixture>>;
