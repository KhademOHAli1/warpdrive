import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({...base,test:{...base.test,name:'calendar-reminder-defaults-past-pg',maxWorkers:1,include:['src/features/activities/reminderDefaultsPast.integration.test.ts','src/features/activities/reminderDefaultsActivation.integration.test.ts','src/features/activities/reminderDefaultsImplicit.integration.test.ts','src/features/activities/providers/google/authorizationRoutes.integration.test.ts']}});
