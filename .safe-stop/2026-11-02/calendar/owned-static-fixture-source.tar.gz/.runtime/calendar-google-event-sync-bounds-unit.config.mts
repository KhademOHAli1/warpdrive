import { defineConfig } from 'vitest/config';
import base from '../vitest.config';
export default defineConfig({
  ...base,
  test: {
    ...base.test,
    maxWorkers: 1,
    projects: [{
      extends: true,
      test: {
        name: 'unit',
        include: ['.runtime/google-event-sync-bounds-draft/eventSyncBounds.test.ts'],
        environment: 'node',
      },
    }],
  },
});
