import { fileURLToPath } from "node:url";
import { createTypeScriptImportResolver } from "eslint-import-resolver-typescript";
import base from "../eslint.config.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const project = fileURLToPath(
  new URL("./calendar-event-sync-pages-candidate-tsconfig.json", import.meta.url),
);

// The root deliberately ignores all runtime artifacts. This explicit candidate
// config retains its rules but makes the selected source available to the parser.
export default [
  ...base.map((config) =>
    config.ignores === undefined
      ? config
      : { ...config, ignores: config.ignores.filter((pattern) => pattern !== ".runtime/**") },
  ),
  {
    files: [".runtime/calendar-event-sync-pages-candidate/**/*.ts"],
    languageOptions: {
      parserOptions: {
        projectService: false,
        project,
        tsconfigRootDir: root,
      },
    },
    settings: {
      "import-x/resolver-next": [
        createTypeScriptImportResolver({ project, alwaysTryTypes: true }),
      ],
    },
  },
];
