import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";

export default defineConfig({
  envDir: false,
  resolve: {
    alias: { "@": fileURLToPath(new URL("../src", import.meta.url)) },
  },
  test: {
    globals: false,
    environment: "node",
    testTimeout: 60_000,
    hookTimeout: 120_000,
    maxWorkers: 1,
    projects: [
      {
        extends: true,
        test: {
          name: "unit",
          include: [
            ".runtime/calendar-event-sync-pages-candidate/eventSyncBounds.test.ts",
            ".runtime/calendar-event-sync-pages-candidate/eventSyncPayloadBounds.test.ts",
            ".runtime/calendar-event-sync-pages-candidate/eventSyncCursorBounds.test.ts",
            ".runtime/calendar-event-sync-pages-candidate/client.test.ts",
            ".runtime/calendar-event-sync-pages-candidate/pathSafety.test.ts",
            ".runtime/calendar-event-sync-pages-candidate/transport.test.ts",
            ".runtime/calendar-event-sync-pages-candidate/errorReasons.test.ts",
            ".runtime/calendar-event-sync-pages-candidate/eventSyncPages.test.ts",
            ".runtime/calendar-event-sync-pages-candidate/eventSyncStaging.test.ts",
            ".runtime/calendar-event-sync-pages-candidate/eventSyncPayloadPages.test.ts",
          ],
          environment: "node",
          maxWorkers: 1,
        },
      },
    ],
  },
});
