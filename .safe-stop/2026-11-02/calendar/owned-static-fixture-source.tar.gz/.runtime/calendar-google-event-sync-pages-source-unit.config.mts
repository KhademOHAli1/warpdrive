import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";

export default defineConfig({
  envDir: false,
  resolve: { alias: { "@": fileURLToPath(new URL("../src", import.meta.url)) } },
  test: {
    globals: false,
    environment: "node",
    maxWorkers: 1,
    projects: [{
      extends: true,
      test: {
        name: "unit",
        environment: "node",
        maxWorkers: 1,
        include: [
          "src/features/activities/providers/google/eventSyncBounds.test.ts",
          "src/features/activities/providers/google/eventSyncPayloadBounds.test.ts",
          "src/features/activities/providers/google/eventSyncCursorBounds.test.ts",
          "src/features/activities/providers/google/client.test.ts",
          "src/features/activities/providers/google/pathSafety.test.ts",
          "src/features/activities/providers/google/transport.test.ts",
          "src/features/activities/providers/google/errorReasons.test.ts",
          "src/features/activities/providers/google/eventSyncPages.test.ts",
          "src/features/activities/providers/google/eventSyncStaging.test.ts",
          "src/features/activities/providers/google/eventSyncPayloadPages.test.ts",
        ],
      },
    }],
  },
});
