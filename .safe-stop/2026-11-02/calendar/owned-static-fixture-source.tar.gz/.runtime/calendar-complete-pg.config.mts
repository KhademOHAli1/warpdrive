import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
import notification from './calendar-notifications-pg.config.mts';
export default defineConfig({ ...base, test: { ...base.test, include: ['src/features/activities/personalReminderDelivery.integration.test.ts',...new Set([...base.test.include, ...notification.test.include, 'src/features/activities/reminders.test.ts', 'src/features/activities/calendarLeadBoundary.integration.test.ts'])] } });
