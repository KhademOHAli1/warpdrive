import { defineConfig } from "vitest/config";
import base from "../vitest.config";

export default defineConfig({
  ...base,
  envDir: false,
  test: {
    ...base.test,
    setupFiles: [
      ...base.test.setupFiles,
      ".runtime/calendar-existing-edit-atomicity-draft/existingEditAtomicity.setup.ts",
    ],
    env: {
      NODE_ENV: "test",
      DATABASE_URL: "postgres://calendar_test@127.0.0.1:54672/postgres",
      BASE_URL: "https://calendar-test.example.invalid",
      GOOGLE_CALENDAR_OAUTH_CLIENT_ID: "",
      GOOGLE_CALENDAR_OAUTH_CLIENT_SECRET: "",
      AUTH_MAIL_TRANSPORT: "capture",
      AUTH_SMTP_HOST: "",
    },
    maxWorkers: 1,
    fileParallelism: false,
    projects: [{
      extends: true,
      test: {
        name: "integration",
        include: [
          ".runtime/calendar-existing-edit-atomicity-draft/existingEditAtomicity.integration.test.ts",
        ],
        globalSetup: [".runtime/calendar-pg.setup.mts"],
      },
    }],
  },
});
