import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";
import base from "./calendar-pg.config.mts";
export default defineConfig({
  ...base,
  resolve: {
    ...base.resolve,
    alias: [
      {
        find: "@/features/activities/providers/google/authorizationCleanup",
        replacement: fileURLToPath(new URL("./calendar-oauth-retention-draft/authorizationCleanup.ts", import.meta.url)),
      },
      { find: "@", replacement: fileURLToPath(new URL("../src", import.meta.url)) },
    ],
  },
  test: {
    ...base.test,
    name: "calendar-google-oauth-retention-red",
    maxWorkers: 1,
    include: [
      ".runtime/calendar-oauth-retention-draft/authorizationRetention.integration.test.ts",
      ".runtime/calendar-oauth-retention-draft/authorizationRetentionIndex.integration.test.ts",
    ],
  },
});
