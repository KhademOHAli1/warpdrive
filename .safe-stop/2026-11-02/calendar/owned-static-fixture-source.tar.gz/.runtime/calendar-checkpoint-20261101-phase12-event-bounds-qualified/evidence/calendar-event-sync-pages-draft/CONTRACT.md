# Event-sync page visitor: unexecuted fail-closed RED scaffold

Only ignored preparation files are written. No production API, schema, collector,
migration, database, service, provider request or check was implemented or executed.
The eleven unchanged test bodies are split across three focused files with a shared
sibling fixture. A minimum `eventSyncPages.ts` stub and
`.runtime/calendar-google-event-sync-pages-red-unit.config.mts` remove the missing-module
obstacle without implementing visitor behavior. Loops stay inside the same eleven
`it` cases. The latest explicit Promise.resolve callback style is preserved.

## Proposed boundary

`schemas.ts` preserves optional string `accessRole` on event-list pages. Ordinary
role-less `eventsList` reads remain compatible. Unknown role strings survive transport
parsing so a mirror-specific authority policy can reject them explicitly. No raw page
envelope or provider message is exposed through a client-facing DTO.

The future `eventSyncPages.ts` exports `visitGoogleEventSyncPages` with the signature
declared in `eventSyncPagesFixture.ts`. Its required input includes the exact readable
role captured from current, locked catalog authority: `reader`,
`writerWithoutPrivateAccess`, `writer` or `owner`. The caller does not derive this from
an untrusted request. Missing, unknown, unreadable or nonmatching page authority returns
`{ kind: "catalog_changed" }`, including for empty pages. Upgrades and downgrades both
require catalog refresh. Matching each page to the captured role also enforces consistency
between pages. The query's `singleEvents=false` alone establishes no role authority.

Each fully validated page is passed to a sequential sink as exactly
`{ ordinal, accessRole, items }`, with zero-based ordinal and the original signal.
No page or final cursor is passed to the sink. Validate the whole page's role, payload,
duplicates, cumulative budgets and continuation/final cursor before invoking it. Await
the sink and check abort before requesting a later page or returning completion.
Operational sink Results propagate with the same error object; abort reasons propagate
unchanged. Provider Results, including 410 reset and retry metadata, remain intact.

Success returns only `{ accessRole, syncToken, pages, events, bytes }`. `bytes` is the
sum of UTF8 `JSON.stringify(event)` payloads, without envelope/cursor bytes. Completion
is released only after the valid terminal page's sink succeeds. An empty valid page is
still visited. Failure returns no success value or completion cursor. Earlier sink
writes are private staging, never published events; publication is a later transaction.

The sink closes over the durable run and rechecks current owner/account generation,
binding/catalog authority and deadline before bounded writes. This visitor performs no
database access and creates no Activity, reminder, notification or outbound meeting.
It retains only the current page and bounded identity/token/counter state, not an array
of all earlier event bodies. Current network parsing and peak validation allocations
remain outside the accepted-data budgets.

## Eleven cases

Cases 1 to 5 are in `eventSyncPages.test.ts`, cases 6 to 8 in
`eventSyncStaging.test.ts`, and cases 9 to 11 in `eventSyncPayloadPages.test.ts`.
Only imports and the small per-file global-fetch guard are repeated; extracted case
bodies retain their exact bytes. The fixture and minimum API stub are unchanged.

1. Preserve page role metadata and retain ordinary role-less client compatibility.
2. Visit matching reader/writer-without-private/writer/owner pages, including empties,
   and return only terminal completion metadata.
3. Deny missing/unknown/unreadable/mismatching first-page authority before staging,
   for both empty and nonempty terminal pages.
4. Deny later authority changes before staging that page or releasing its cursor,
   for both empty and nonempty terminal pages.
5. Preserve full/incremental query shape, original sync token, encoded calendar ID,
   compatible filters and the same signal while advancing page token only.
6. Await each stage, stop fetching during its gate, and await terminal staging before
   completion. Gates are bounded by AbortSignal and released in finally.
7. Preserve storage/conflict sink Results and stop before any later request.
8. Preserve later 410/429/503 provider errors and retry metadata without completion.
9. Reject the complete offending page before staging: incomplete/mixed/cyclic cursors,
   within/across-page duplicate IDs, unsafe JSON/depth and unsafe/oversize cursors.
10. Preserve raw recurrence masters, moved exceptions, all-day cancellations, sparse
    deletions and unknown fields without reconstruction.
11. Preserve exact pre-fetch/post-fetch/post-stage/terminal-stage abort reasons.

Synthetic Response transport and a rejected global fetch ensure no provider access.
These cases do not duplicate the large 50,000-entry/32MiB probes in the separate frozen
sixteen-case bounds package. Its limits and assertions remain authoritative for shared
budget behavior; the page visitor case uses small integration examples and a single
64KiB-plus-one cursor. No performance or memory campaign is implied.

## RED classification and later refactor

The first case targets the existing client schema and should fail behaviorally because
the current schema strips role metadata. The other ten cases dynamically import the
future visitor at invocation time. Their earlier absent module/API was structural only,
never ten semantic RED failures.

The exact-three-file unit configuration aliases only the rooted future visitor import
to the ignored stub before the ordinary `@` to `src` alias. It preserves the real
client/schema and uses the node environment with one worker. The stub checks the
required signal and returns `invalid_response`; it does not call the provider or sink,
validate role/budgets, or return success. The module is importable source preparation,
not an executed result. Root must run and record meaningful behavior failures before
visitor implementation. No execution grant is conveyed by this scaffold.

After the staged sixteen-case collector package is GREEN and promoted, extract a small
`eventSyncBudget.ts` from its existing counters/identity/cursor checks as a separate
test-first refactor. Use it from both collector and visitor; retain the collector's public
signature/result and its protected bounds tests. Do not introduce a second divergent
budget policy. No such extraction or future production code exists in this draft.

The dedicated exact-eleven-case, three-file configuration is prepared but unrun. Promotion, RED
execution and all later checks require the root's reviewed source/resource sequence.
This preparation does not alter the existing frozen collector inputs.
