import type { GoogleCalendarClient } from "@/features/activities/providers/google/client";
import type { GoogleCalendarError } from "@/features/activities/providers/google/contracts";
import type { GoogleEvent } from "@/features/activities/providers/google/schemas";
import { err, type Result } from "@/types/result";

export type ReadableCalendarRole = "reader" | "writerWithoutPrivateAccess" | "writer" | "owner";
export interface EventSyncPageInput {
  calendarId: string;
  syncToken?: string;
  expectedAccessRole: ReadableCalendarRole;
  signal: AbortSignal;
}
export interface StagedEventPage {
  ordinal: number;
  accessRole: ReadableCalendarRole;
  items: readonly GoogleEvent[];
}
export interface EventSyncCompletion {
  accessRole: ReadableCalendarRole;
  syncToken: string;
  pages: number;
  events: number;
  bytes: number;
}

// Minimum importable RED boundary only. It has no provider or staging effects,
// authority/budget logic or success path, and is not a production implementation.
export async function visitGoogleEventSyncPages<E>(
  _client: Pick<GoogleCalendarClient, "eventsList">,
  input: EventSyncPageInput,
  _stage: (page: StagedEventPage, signal: AbortSignal) => Promise<Result<void, E>>,
): Promise<Result<EventSyncCompletion, GoogleCalendarError | { kind: "catalog_changed" } | E>> {
  input.signal.throwIfAborted();
  return err({ kind: "invalid_response" });
}
