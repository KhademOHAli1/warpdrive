import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";
import base from "../vitest.config";

export default defineConfig({
  ...base,
  resolve: {
    ...base.resolve,
    alias: [
      {
        find: "@/features/activities/providers/google/eventSyncPages",
        replacement: fileURLToPath(new URL("./calendar-event-sync-pages-draft/eventSyncPages.ts", import.meta.url)),
      },
      { find: "@", replacement: fileURLToPath(new URL("../src", import.meta.url)) },
    ],
  },
  test: {
    ...base.test,
    maxWorkers: 1,
    projects: [{
      extends: true,
      test: {
        name: "unit",
        include: [
          ".runtime/calendar-event-sync-pages-draft/eventSyncPages.test.ts",
          ".runtime/calendar-event-sync-pages-draft/eventSyncStaging.test.ts",
          ".runtime/calendar-event-sync-pages-draft/eventSyncPayloadPages.test.ts",
        ],
        environment: "node",
        maxWorkers: 1,
      },
    }],
  },
});
