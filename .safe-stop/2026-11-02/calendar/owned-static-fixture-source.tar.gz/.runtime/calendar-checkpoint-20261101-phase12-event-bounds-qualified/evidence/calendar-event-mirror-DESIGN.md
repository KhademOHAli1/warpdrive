# Proposed raw Google event mirror, source planning only

This file remains a source design, with no implemented mirror, migration or provider acceptance. Prerequisite clock/cache corrections are locally qualified; migration0092 and actual synthetic catalog browser acceptance/exactcleanup are complete. The bounded event collector is now promoted and locally qualified: actual9policyRED/3controls,4cursorRED/12controls,16candidateGREEN and final53affectedappunitcases/7files in715ms, current6-file scopedstatics and freshfulltypes3.04s. These are puretransport results, without durableeventmirror/import/sync publication. No next migration is generated or reserved.

The next slice is a server-only raw mirror for explicitly selected provider calendars. It creates no Activities, reminders, notifications, outbound writes or Meet readiness. Existing Activity creation allocates new IDs and enables reminders, so it cannot be reused as an idempotent import adapter.

## Proposed model

- Mirror state: latest run UUID/deadline, captured account generation, binding version, catalog authority and base publication revision; separate published revision, full snapshot epoch, cursor and query-contract version.
- Stable events: local UUID, provider calendar UUID, exact opaque event ID plus generated hash uniqueness and exact collision guard, raw JSON, nullable ETag, tombstone reason and publication/epoch markers. Never apply the insertion-ID regex to provider recurring-instance IDs.
- Run staging: private page data keyed by run UUID and event identity. Superseded/expired staging has no query authority and needs bounded reclamation.

## Authority and publication

Obtain a fresh access grant, then begin under owner-first locks. Require active owner, connected/current generation, selected/current binding, nondeleted provider-source local calendar and current readable catalog authority. Capture and recheck all conditions for staging/publication; routine credential rotation keeps generation, while reconnect, deselection/re-addition, permission changes and newer runs fence older work.

Publish changes, cursor and revision atomically. Sample deadlines after locks and before final publication. Roll back tentative batches on expiry/storage failure. Failure bookkeeping may change only its own current run. Read the starting cursor under state lock and fence against its base publication revision. Changed generation, binding version or query contract forces full sync.

Full publication advances the full-snapshot epoch. Omitted rows become unavailable tombstones while retaining IDs. Incremental publication changes only returned rows; absence means unchanged. HTTP 410 invalidates cursor authority and sets needsFull. Retain prior data as unavailable history until a complete full rebuild publishes.

Preserve raw recurrence masters/rules, exception recurringEventId and exact originalStartTime, including sparse cancellations. Do not reconstruct missing fields or expand occurrences in this package. Owner-only queries recheck current authority and expose bounded safe DTOs, never raw payloads/cursors.

## Transport prerequisite

Reuse getCalendarAccessGrant, eventsList and ownership/binding/catalog seams. The promoted sync.ts page/item/byte/depth/Unicode/duplicate and cursor guards are qualified in the stated puretransport scope. Limits are event-specific, and are not Google API or streaming response-body limits. A later mirror-only sequential visitor must preserve page authority and stage each validated page privately before requesting the next one, returning only a complete terminal cursor. No flat collector result alone establishes publication authority.

## Proposed real-PostgreSQL scenarios

1. Multipage full publication, long opaque IDs, recurrence preservation.
2. Incremental update/cancellation with unchanged rows retained.
3. Empty full versus empty incremental results.
4. Later-page failure, abort and witnessed mid-batch storage rollback.
5. Competing successes and newer-failure/older-success ordering.
6. HTTP 410 followed by successful/failed full rebuilds.
7. Refresh, reconnect, deselection/re-addition and permission races.
8. Wrong/inactive owner and deleted local-calendar denial.
9. Stable identity, hash collisions, deadlines and zero Activity/reminder side effects.

## Official-contract research for the next implementation

Public Google documentation confirms that free/busy callers receive expanded instances
as though singleEvents were true. A query flag alone therefore cannot establish the
proposed unexpanded mirror contract. [Recurring-events guide](https://developers.google.com/workspace/calendar/api/guides/recurringevents#access_instances).

Proposed fail-closed policy: preserve each page envelope; require a known readable
accessRole on every page, consistent with the captured catalog role and all other pages.
Reject missing/unknown/free-busy/no-access authority and require metadata refresh after
a mismatch. The reference lists accessRole but does not explicitly define omission,
so rejecting omission is our policy. The existing flattened collector alone cannot
carry this authority. [List response](https://developers.google.com/workspace/calendar/api/v3/reference/events/list#response).

With incremental sync, repeat the original syncToken and compatible query parameters
while advancing pageToken; take the new cursor only from the last page. HTTP 410 may
reflect expiry or ACL change and requires a full reset/rebuild. Atomic staged publication
is our design choice. [Sync guide](https://developers.google.com/workspace/calendar/api/guides/sync).

Keep cancelled recurring exceptions for the parent's lifetime, retaining original
occurrence identity even after a move. Sparse ordinary deletions need only their ID;
never require a normal event body on tombstones. [Event resource](https://developers.google.com/workspace/calendar/api/v3/reference/events#resource).

Creation-ID alphabet/length validation applies to caller-provided insertion IDs. It
must not restrict returned recurring-instance identities. Our read storage preserves
exact opaque IDs with hash collision guards. Raw byte/depth/page/count limits remain
Warpdrive policy. [Insert reference](https://developers.google.com/workspace/calendar/api/v3/reference/events/insert#request-body).


## Next page-staging contract

Preserve optional string `accessRole` in the event-list response schema so ordinary
role-less client reads keep their existing behavior. The mirror-only visitor captures
a known readable role from current locked catalog authority and requires exact equality
on every returned page, including an empty terminal page. Missing, unknown, unreadable
or changed authority returns `catalog_changed` and requires a metadata refresh. This is
our fail-closed mirror policy, not a provider omission guarantee.

The visitor validates the entire page's role, payload identities/bytes/depth/Unicode
and continuation/final cursor before invoking its private staging sink. Await staging
before another provider request. Return completion counts and the final cursor only
after successful terminal staging and the post-await abort check. No cursor is given
to the page sink. Provider and sink Result errors preserve their identity; aborts
propagate their exact reason. Earlier staged pages remain private and unpublished
after a later failure.

Extract the qualified collector budget into one internal reusable module as a later
test-protected refactor. Keep the collector's public API and sixteen regression cases,
while the visitor retains only the current raw page plus bounded exact-ID/cursor sets.
Do not duplicate evolving budget policies or claim a peak parse/validation-memory bound.

The sink closes over a server-owned run identity and must recheck active owner, account
generation, selected binding/version, current provider container/catalog authority and
post-lock deadline. It is not an Activity or reminder adapter. Raw staging still needs
a separate real-PostgreSQL schema/publication package before any available mirror data
or complete synchronization outcome can be asserted.

Eleven ignored page-visitor cases are prepared but unexecuted, with a minimal importable
fail-closed scaffold to distinguish future semantic failures from missing modules.
No functional visitor, budget extraction, role-schema change or staging sink exists yet.
