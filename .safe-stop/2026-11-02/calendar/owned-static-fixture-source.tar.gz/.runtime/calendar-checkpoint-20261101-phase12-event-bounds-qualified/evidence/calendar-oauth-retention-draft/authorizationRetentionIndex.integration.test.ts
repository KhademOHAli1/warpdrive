import { afterEach, beforeEach, expect, it } from "vitest";
import { makeTestDb } from "@/test/db";
import { forbidProviderNetwork } from "@/features/activities/providers/google/calendarCatalog.test-helpers";

let ctx: Awaited<ReturnType<typeof makeTestDb>>;
let network: ReturnType<typeof forbidProviderNetwork>;
beforeEach(async () => {
  ctx = await makeTestDb();
  network = forbidProviderNetwork();
});
afterEach(async () => {
  try {
    expect(network).not.toHaveBeenCalled();
  } finally {
    network.mockRestore();
    await ctx.close();
  }
});

it("migrates a valid global expiry-first index for bounded cleanup across all owners", async () => {
  const result = await ctx.pool.query<{ keys: string[] }>(`
    SELECT array_agg(attribute.attname::text ORDER BY key.ordinality) AS keys
    FROM pg_index AS idx
    JOIN pg_class AS relation ON relation.oid=idx.indrelid
    JOIN pg_namespace AS namespace ON namespace.oid=relation.relnamespace
    JOIN pg_class AS index_relation ON index_relation.oid=idx.indexrelid
    JOIN pg_am AS method ON method.oid=index_relation.relam
    CROSS JOIN LATERAL unnest(idx.indkey) WITH ORDINALITY AS key(attnum,ordinality)
    JOIN pg_attribute AS attribute ON attribute.attrelid=relation.oid AND attribute.attnum=key.attnum
    WHERE namespace.nspname='public' AND relation.relname='calendar_oauth_attempts'
      AND method.amname='btree' AND idx.indisvalid AND idx.indisready
      AND idx.indpred IS NULL AND idx.indexprs IS NULL
      AND key.ordinality <= idx.indnkeyatts
    GROUP BY idx.indexrelid
  `);
  expect(result.rows.some((row) => row.keys[0] === "expires_at" && row.keys[1] === "state_hash")).toBe(true);
});
