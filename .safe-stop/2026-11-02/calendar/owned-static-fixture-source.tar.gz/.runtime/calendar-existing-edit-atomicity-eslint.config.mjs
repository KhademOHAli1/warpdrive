import { fileURLToPath } from "node:url";
import { createTypeScriptImportResolver } from "eslint-import-resolver-typescript";
import base from "../eslint.config.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const project = fileURLToPath(
  new URL("./calendar-existing-edit-atomicity-tsconfig.json", import.meta.url),
);

export default [
  ...base.map((config) => config.ignores === undefined ? config : {
    ...config,
    ignores: config.ignores.filter((pattern) => pattern !== ".runtime/**"),
  }),
  {
    files: [
      ".runtime/calendar-existing-edit-atomicity-draft/**/*.ts",
      ".runtime/calendar-existing-edit-atomicity-testcontainers.config.mts",
      ".runtime/calendar-reminder-insert-failure-testcontainers.config.mts",
    ],
    languageOptions: {
      parserOptions: { projectService: false, project, tsconfigRootDir: root },
    },
    settings: {
      "import-x/resolver-next": [
        createTypeScriptImportResolver({ project, alwaysTryTypes: true }),
      ],
    },
  },
];
