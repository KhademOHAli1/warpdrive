import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {Pool} from 'pg';
import {drizzle} from 'drizzle-orm/node-postgres';
import {migrate} from 'drizzle-orm/node-postgres/migrator';
import {env} from '../src/config/env';
const fixture=JSON.parse(readFileSync('.runtime/calendar-browser-fixture.json','utf8'));
const target=new URL(env.DATABASE_URL);
if(target.hostname!=='127.0.0.1'||target.port!=='54673'||target.pathname!==`/${fixture.database}`) throw new Error('Only the existing isolated calendar browser database is allowed');
const pool=new Pool({connectionString:env.DATABASE_URL});
try {await migrate(drizzle(pool),{migrationsFolder:resolve('drizzle')});console.log('Existing synthetic calendar fixture migrated; no database recreated.');}
finally {await pool.end();}
