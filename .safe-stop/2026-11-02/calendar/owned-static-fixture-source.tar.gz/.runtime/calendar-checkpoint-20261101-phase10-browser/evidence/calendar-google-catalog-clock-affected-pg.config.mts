import { defineConfig } from 'vitest/config';
import base from './calendar-google-catalog-affected-pg.config.mts';
export default defineConfig({
 ...base,
 test: {
  ...base.test,
  name: 'calendar-google-catalog-clock-affected',
  maxWorkers: 1,
  include: [
   ...(base.test.include ?? []),
   'src/features/activities/providers/google/authorizationExpiryLock.integration.test.ts',
  ],
 },
});
