import { defineConfig } from 'vitest/config';
import candidate from './calendar-google-catalog-candidate-pg.config.mts';
import accounts from './calendar-google-browser-flows-all-pg.config.mts';
export default defineConfig({
  ...candidate,
  test: {
    ...candidate.test,
    name: 'calendar-google-catalog-affected',
    maxWorkers: 1,
    include: [
      ...(candidate.test.include ?? []),
      ...(accounts.test.include ?? []),
      'src/features/activities/calendars.integration.test.ts',
      'src/features/activities/calendarConcurrency.integration.test.ts',
      'src/features/activities/calendarLeadBoundary.integration.test.ts',
      'src/features/notifications/calendarPrivacy.integration.test.ts',
      'src/features/activities/calendarEventRoundTrip.integration.test.ts',
    ],
  },
});
