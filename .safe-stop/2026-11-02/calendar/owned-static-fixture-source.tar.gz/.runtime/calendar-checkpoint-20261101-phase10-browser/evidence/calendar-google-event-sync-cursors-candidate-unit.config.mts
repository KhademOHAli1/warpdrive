import { defineConfig } from "vitest/config";
import base from "./calendar-google-event-sync-bounds-candidate-unit.config.mts";
export default defineConfig({
  ...base,
  test: {
    ...base.test,
    projects: [{ extends: true, test: {
      name: "unit",
      include: [".runtime/google-event-sync-bounds-draft/eventSyncBounds.test.ts", ".runtime/google-event-sync-bounds-draft/eventSyncCursorBounds.test.ts"],
      environment: "node",
    } }],
  },
});
