import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({
  ...base,
  test: {
    ...base.test,
    name: 'calendar-google-catalog-red',
    maxWorkers: 1,
    include: [
      'src/features/activities/providers/google/accountGrantGeneration.integration.test.ts',
      'src/features/activities/providers/google/calendarCatalog.integration.test.ts',
      'src/features/activities/providers/google/calendarCatalogConcurrency.integration.test.ts',
      'src/features/activities/providers/google/calendarCatalogDurability.integration.test.ts',
      'src/features/activities/providers/google/calendarBindings.integration.test.ts',
      'src/features/activities/providers/google/calendarBindingLifecycle.integration.test.ts',
      'src/features/activities/providers/google/calendarSourceGuard.integration.test.ts',
    ],
  },
});
