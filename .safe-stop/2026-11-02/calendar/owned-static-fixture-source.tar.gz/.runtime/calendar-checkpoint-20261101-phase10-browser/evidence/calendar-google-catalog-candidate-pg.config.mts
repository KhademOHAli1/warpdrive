import { defineConfig } from 'vitest/config';
import base from './calendar-google-catalog-red-pg.config.mts';
export default defineConfig({
  ...base,
  test: {
    ...base.test,
    name: 'calendar-google-catalog-candidate',
    maxWorkers: 1,
    include: [
      ...(base.test.include ?? []),
      'src/features/activities/providers/google/calendarCatalogExpiry.integration.test.ts',
    ],
  },
});
