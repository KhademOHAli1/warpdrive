import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({
 ...base,
 test: {
  ...base.test,
  name: 'calendar-google-authorization-expiry-lock',
  maxWorkers: 1,
  include: ['src/features/activities/providers/google/authorizationExpiryLock.integration.test.ts'],
 },
});
