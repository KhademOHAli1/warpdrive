import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'node:path';
export default defineConfig({root:resolve('.runtime/calendar-preview'),plugins:[react()],
 resolve:{alias:[
  {find:'@/lib/trpc-client',replacement:resolve('.runtime/calendar-preview/mocks.ts')},
  {find:'@/utils/csrfCookie',replacement:resolve('.runtime/calendar-preview/mocks.ts')},
  {find:/^\.\/actions$/,replacement:resolve('.runtime/calendar-preview/mocks.ts')},
  {find:'@/features/email/composer/RichTextBodyLazy',replacement:resolve('src/features/email/composer/RichTextBody.tsx')},
  {find:'@',replacement:resolve('src')},
 ]},server:{host:'127.0.0.1',port:3168,strictPort:true,fs:{allow:[resolve('.')]}},
});
