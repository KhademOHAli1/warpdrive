import React from 'react';
import { createRoot } from 'react-dom/client';
import { LocaleProvider } from '@/features/i18n/LocaleProvider';
import { CalendarEventDialog } from '@/features/activities/CalendarEventDialog';
import '@/app/globals.css';
import './review.css';
const locale = new URLSearchParams(location.search).get('locale') === 'de' ? 'de' : 'fa';
document.documentElement.lang = locale;
document.documentElement.dir = locale === 'fa' ? 'rtl' : 'ltr';
const editing = new URLSearchParams(location.search).has('details') ? {
 id:'00000000-0000-4000-8000-000000000001', typeId:'00000000-0000-4000-8000-000000000002',
 subject:locale==='fa'?'جلسهٔ برنامه‌ریزی فروش':'Vertriebsplanung', priority:'medium', dueAt:'2027-03-21T07:00:00.000Z', endAt:'2027-03-21T08:00:00.000Z',
 allDay:false, dueDate:null,endDate:null,durationMinutes:60, location:locale==='fa'?'دفتر تهران':'Besprechungsraum Berlin',
 note:locale==='fa'?'<p>بررسی فرصت‌های فروش و هماهنگی برنامهٔ هفتهٔ آینده</p>':'<p>Verkaufschancen besprechen und die nächste Woche planen.</p>',
 videoCallUrl:'https://meet.google.com/abc-defg-hij',assigneeId:'00000000-0000-4000-8000-000000000003',done:false,
 dealId:null,personId:'00000000-0000-4000-8000-000000000004',orgId:'00000000-0000-4000-8000-000000000005',guestPersonIds:[],participantUserIds:[],dealTitle:null,personName:locale==='fa'?'سارا احمدی':'Sara Ahmadi',orgName:locale==='fa'?'تیم فروش':'Vertriebsteam',
}:undefined;
createRoot(document.getElementById('root')!).render(<LocaleProvider locale={locale} timeZone={locale==='fa'?'Asia/Tehran':'Europe/Berlin'}>
 <div className="min-h-screen bg-muted p-12"><h1 className="text-xl font-semibold">{locale==='fa'?'تقویم':'Kalender'}</h1>
 <p className="mt-3 text-sm text-muted-foreground">Local visual fixture · no invitations or real meeting creation</p></div>
 <CalendarEventDialog editing={editing} defaultDate="2027-03-21" defaultTime="09:00" onClose={()=>location.reload()} />
</LocaleProvider>);
