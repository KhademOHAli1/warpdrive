const success = () => Promise.resolve({ok:false,error:{id:'VISUAL_FIXTURE_ONLY'}});
export const createActivityAction=success,editActivityAction=success,deleteActivityAction=success,completeActivityAction=success;
export const readCsrfToken=()=>'';
const invalidate=()=>Promise.resolve();
export const trpc={useUtils:()=>({activities:{dayLoad:{invalidate},listRows:{invalidate}}}),activities:{
 listTypes:{useQuery:()=>({data:[{id:'00000000-0000-4000-8000-000000000002',key:'meeting',name:'Meeting'},{id:'00000000-0000-4000-8000-000000000004',key:'call',name:'Call'}]})},
 dayLoad:{useQuery:()=>({data:undefined})},
}};

export const saveLocalePreferencesAction=success;
