import { fileURLToPath } from "node:url";
import { createTypeScriptImportResolver } from "eslint-import-resolver-typescript";
import base from "../eslint.config.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const project = fileURLToPath(
  new URL("./calendar-live-engine-fixtures-tsconfig.json", import.meta.url),
);

export default [
  ...base.map((config) =>
    config.ignores === undefined
      ? config
      : {
          ...config,
          ignores: config.ignores.filter((pattern) => pattern !== ".runtime/**"),
        },
  ),
  {
    files: [
      ".runtime/calendar-reminder-live-acceptance/**/*.ts",
      ".runtime/calendar-reminder-engine-candidate/**/*.ts",
      ".runtime/calendar-reminder-engine-testcontainers.config.mts",
      ".runtime/calendar-reminder-engine-regression-testcontainers.config.mts",
      ".runtime/calendar-existing-edit-atomicity-draft/existingEditAtomicity.globalSetup.ts",
    ],
    languageOptions: {
      parserOptions: { projectService: false, project, tsconfigRootDir: root },
    },
    settings: {
      "import-x/resolver-next": [createTypeScriptImportResolver({ project, alwaysTryTypes: true })],
    },
  },
];
