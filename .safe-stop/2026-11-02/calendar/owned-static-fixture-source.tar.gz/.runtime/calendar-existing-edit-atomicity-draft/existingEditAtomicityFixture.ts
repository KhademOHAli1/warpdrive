import { eq } from "drizzle-orm";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { activities, activityTypes, deals, persons, reminderRebuilds } from "@/db/schema";
import { seedPipelineWithStages, seedUser } from "@/db/testing/factories";
import { createCalendar } from "@/features/activities/calendars";
import {
  getEventReminderSettings,
  setEventReminderSettings,
} from "@/features/activities/personalReminderSettings";
import type { ReminderSelection } from "@/features/activities/reminderPolicy";
import { createActivity } from "@/features/activities/repo";
import type { PermSetUser } from "@/features/permissions/effective";
import type { TestDb } from "@/test/db";

export const BEFORE_DUE = "2030-03-21T09:00:00.000Z";
export const AFTER_DUE = "2030-03-22T09:00:00.000Z";
export const AFTER_END = "2030-03-22T10:00:00.000Z";
export const AFTER_SUBJECT = "Tentative shared edit";
export const AFTER_LOCATION = "After";
export const REBUILD_BASELINE = new Date("2000-01-01T00:00:00.000Z");

export function reminderSelection(minutesBefore: number): ReminderSelection {
  return {
    useDefault: false,
    timed: [{ method: "notification", minutesBefore }],
    allDay: [],
  };
}

async function seedDeal(ctx: TestDb, ownerId: string, title: string, signal: AbortSignal) {
  signal.throwIfAborted();
  const pipeline = await seedPipelineWithStages(ctx.db, ["Lead"]);
  signal.throwIfAborted();
  const stage = pipeline.stages[0];
  if (stage === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "stage seed absent");
  const [deal] = await ctx.db
    .insert(deals)
    .values({
      title,
      pipelineId: pipeline.pipeline.id,
      stageId: stage.id,
      ownerId,
      visibilityLevel: "all",
    })
    .returning();
  signal.throwIfAborted();
  if (deal === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "deal seed absent");
  return deal.id;
}

async function seedGuest(ctx: TestDb, ownerId: string, name: string, signal: AbortSignal) {
  signal.throwIfAborted();
  const email = `${name.toLowerCase()}@example.invalid`;
  const [guest] = await ctx.db
    .insert(persons)
    .values({
      name,
      primaryEmail: email,
      emails: [{ label: "work", value: email, primary: true }],
      phones: [],
      ownerId,
      visibilityLevel: "all",
    })
    .returning();
  signal.throwIfAborted();
  if (guest === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "guest seed absent");
  return guest.id;
}

export async function existingEditFixture(ctx: TestDb, signal: AbortSignal) {
  signal.throwIfAborted();
  const owner = await seedUser(ctx.db, { name: "Owner", isAdmin: true });
  const originalParticipant = await seedUser(ctx.db, { name: "Original participant" });
  const replacementParticipant = await seedUser(ctx.db, { name: "Replacement participant" });
  signal.throwIfAborted();
  const actor: PermSetUser = {
    id: owner.id,
    type: "admin",
    isActive: true,
    groupIds: new Set(),
    flags: new Set(),
  };
  const dealA = await seedDeal(ctx, owner.id, "Deal A", signal);
  const dealB = await seedDeal(ctx, owner.id, "Deal B", signal);
  const originalGuest = await seedGuest(ctx, owner.id, "Original", signal);
  const replacementGuest = await seedGuest(ctx, owner.id, "Replacement", signal);
  const calendar = await createCalendar(
    ctx.db,
    actor,
    {
      name: "یادآوری / Erinnerungen",
      timeZone: "Asia/Tehran",
    },
    signal,
  );
  if (!calendar.ok) throw calendar.error;
  const [type] = await ctx.db.select().from(activityTypes).where(eq(activityTypes.key, "meeting"));
  signal.throwIfAborted();
  if (type === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "meeting seed absent");
  const created = await createActivity(
    ctx.db,
    actor,
    {
      typeId: type.id,
      subject: "Before",
      location: "Before",
      calendarId: calendar.value.id,
      eventTimeZone: "Asia/Tehran",
      dealId: dealA,
      personId: originalGuest,
      participantUserIds: [originalParticipant.id],
      guestPersonIds: [originalGuest],
      dueAt: BEFORE_DUE,
      endAt: "2030-03-21T10:00:00.000Z",
      durationMinutes: 60,
      personalReminders: { expectedRevision: 0, selection: reminderSelection(30) },
    },
    signal,
  );
  if (!created.ok) throw created.error;
  const ownBefore = await getEventReminderSettings(ctx.db, actor, created.value.id, signal);
  if (!ownBefore.ok) throw ownBefore.error;
  const advanced = await setEventReminderSettings(
    ctx.db,
    actor,
    {
      activityId: created.value.id,
      expectedRevision: ownBefore.value.revision,
      selection: reminderSelection(45),
    },
    signal,
  );
  if (!advanced.ok) throw advanced.error;
  const [activity] = await ctx.db
    .select()
    .from(activities)
    .where(eq(activities.id, created.value.id));
  signal.throwIfAborted();
  if (activity === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "event readback absent");
  // A pre-existing queue row makes tentative trigger touches observable in the snapshot.
  await ctx.db
    .insert(reminderRebuilds)
    .values({
      activityId: activity.id,
      touchedAt: REBUILD_BASELINE,
    })
    .onConflictDoUpdate({
      target: reminderRebuilds.activityId,
      set: { touchedAt: REBUILD_BASELINE },
    });
  signal.throwIfAborted();
  return {
    actor,
    activity,
    createdVersion: created.value.version,
    dealA,
    dealB,
    originalParticipant: originalParticipant.id,
    replacementParticipant: replacementParticipant.id,
    originalGuest,
    replacementGuest,
    staleRevision: ownBefore.value.revision,
    currentReminderRevision: advanced.value.revision,
  };
}

export type ExistingEditFixture = Awaited<ReturnType<typeof existingEditFixture>>;

export function combinedEditInput(fixture: ExistingEditFixture, expectedRevision: number) {
  return {
    id: fixture.activity.id,
    expectedVersion: fixture.activity.version,
    subject: AFTER_SUBJECT,
    location: AFTER_LOCATION,
    dueAt: AFTER_DUE,
    endAt: AFTER_END,
    durationMinutes: 60,
    dealId: fixture.dealB,
    participantUserIds: [fixture.replacementParticipant],
    guestPersonIds: [fixture.replacementGuest],
    personalReminders: { expectedRevision, selection: reminderSelection(5) },
  };
}
