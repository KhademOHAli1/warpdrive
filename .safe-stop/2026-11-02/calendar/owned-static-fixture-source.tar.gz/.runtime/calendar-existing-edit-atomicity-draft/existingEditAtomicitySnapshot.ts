import type { TestDb } from "@/test/db";
import type { ExistingEditFixture } from "./existingEditAtomicityFixture";

type EventTable =
  | "activities"
  | "activity_participants"
  | "activity_guests"
  | "activity_reminder_settings"
  | "activity_reminder_intents"
  | "reminder_rebuilds";

export async function atomicitySnapshot(
  ctx: TestDb,
  fixture: ExistingEditFixture,
  signal: AbortSignal,
) {
  signal.throwIfAborted();
  const eventRows = async (table: EventTable, key: string, order: string) => {
    const result = await ctx.pool.query<Record<string, unknown>>(
      `SELECT * FROM ${table} WHERE ${key} = $1 ORDER BY ${order}`,
      [fixture.activity.id],
    );
    signal.throwIfAborted();
    return result.rows;
  };
  const [activity, participants, guests, settings, intents, rebuilds, linkedDeals, linkedPeople] =
    await Promise.all([
      eventRows("activities", "id", "id"),
      eventRows("activity_participants", "activity_id", "user_id"),
      eventRows("activity_guests", "activity_id", "person_id"),
      eventRows("activity_reminder_settings", "activity_id", "user_id, id"),
      eventRows("activity_reminder_intents", "activity_id", "id"),
      eventRows("reminder_rebuilds", "activity_id", "activity_id"),
      ctx.pool.query<Record<string, unknown>>(
        "SELECT * FROM deals WHERE id = ANY($1::uuid[]) ORDER BY id",
        [[fixture.dealA, fixture.dealB]],
      ),
      ctx.pool.query<Record<string, unknown>>(
        "SELECT * FROM persons WHERE id = ANY($1::uuid[]) ORDER BY id",
        [[fixture.originalGuest, fixture.replacementGuest]],
      ),
    ]);
  signal.throwIfAborted();
  return {
    activity,
    participants,
    guests,
    settings,
    intents,
    rebuilds,
    deals: linkedDeals.rows,
    persons: linkedPeople.rows,
  };
}
