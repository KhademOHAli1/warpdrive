import { AppError, ERROR_IDS } from "@/constants/errorIds";
import type { TestDb } from "@/test/db";
import {
  AFTER_DUE,
  AFTER_END,
  AFTER_LOCATION,
  AFTER_SUBJECT,
  type ExistingEditFixture,
  REBUILD_BASELINE,
} from "./existingEditAtomicityFixture";

export async function installTentativeEditWitness(
  ctx: TestDb,
  fixture: ExistingEditFixture,
  signal: AbortSignal,
) {
  signal.throwIfAborted();
  await ctx.pool.query(`
    CREATE SEQUENCE calendar_edit_atomicity_probe START 1;
    CREATE TABLE calendar_edit_atomicity_expected (
      activity_id uuid PRIMARY KEY, previous_deal_id uuid NOT NULL,
      next_deal_id uuid NOT NULL, participant_id uuid NOT NULL,
      guest_id uuid NOT NULL, person_id uuid NOT NULL, shared_version integer NOT NULL,
      subject text NOT NULL, location text NOT NULL,
      due_at timestamptz NOT NULL, end_at timestamptz NOT NULL,
      rebuild_before timestamptz NOT NULL
    );
    CREATE FUNCTION witness_calendar_edit_atomicity() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      IF EXISTS (
        SELECT 1 FROM calendar_edit_atomicity_expected e
        JOIN activities a ON a.id = e.activity_id
        JOIN deals old_deal ON old_deal.id = e.previous_deal_id
        JOIN deals next_deal ON next_deal.id = e.next_deal_id
        JOIN reminder_rebuilds rebuild ON rebuild.activity_id = a.id
        WHERE NEW.id IN (e.previous_deal_id, e.next_deal_id)
          AND a.subject = e.subject AND a.location = e.location
          AND a.deal_id = e.next_deal_id AND a.person_id = e.person_id
          AND a.version = e.shared_version + 1
          AND a.due_at = e.due_at AND a.end_at = e.end_at
          AND old_deal.next_activity_at IS NULL AND next_deal.next_activity_at = e.due_at
          AND rebuild.touched_at > e.rebuild_before
          AND (SELECT count(*) FROM activity_participants p WHERE p.activity_id = a.id) = 1
          AND EXISTS (SELECT 1 FROM activity_participants p
                      WHERE p.activity_id = a.id AND p.user_id = e.participant_id)
          AND (SELECT count(*) FROM activity_guests g WHERE g.activity_id = a.id) = 1
          AND EXISTS (SELECT 1 FROM activity_guests g
                      WHERE g.activity_id = a.id AND g.person_id = e.guest_id)
      ) THEN
        PERFORM nextval('calendar_edit_atomicity_probe');
      END IF;
      RETURN NEW;
    END $$;
    CREATE TRIGGER witness_calendar_edit_atomicity AFTER UPDATE ON deals
      FOR EACH ROW EXECUTE FUNCTION witness_calendar_edit_atomicity();
  `);
  signal.throwIfAborted();
  await ctx.pool.query(
    `
    INSERT INTO calendar_edit_atomicity_expected
      (activity_id, previous_deal_id, next_deal_id, participant_id, guest_id, person_id,
       shared_version, subject, location, due_at, end_at, rebuild_before)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
  `,
    [
      fixture.activity.id,
      fixture.dealA,
      fixture.dealB,
      fixture.replacementParticipant,
      fixture.replacementGuest,
      fixture.originalGuest,
      fixture.activity.version,
      AFTER_SUBJECT,
      AFTER_LOCATION,
      AFTER_DUE,
      AFTER_END,
      REBUILD_BASELINE,
    ],
  );
  signal.throwIfAborted();
}

export async function tentativeEditWitness(ctx: TestDb, signal: AbortSignal) {
  signal.throwIfAborted();
  const result = await ctx.pool.query<{ last_value: string; is_called: boolean }>(
    "SELECT last_value, is_called FROM calendar_edit_atomicity_probe",
  );
  signal.throwIfAborted();
  const row = result.rows[0];
  if (row === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "witness sequence absent");
  return { lastValue: Number(row.last_value), isCalled: row.is_called };
}
