# Native event/reminder and completion replay packet

## Current post-fix native GREEN, 1 November 2026

CAL-REPLAY-GREEN-20261101-1 ran the same7cases/3files once on the compiler-qualified
post-fix cut:7/7passed in4.29seconds, exit0. All previously unreached replay/no-DML/
stale-real-change assertions in this selection now passed. Its owned container/run
labels and PGID72616 are independently absent; all three fresh foreign baselines were
retained. The slot is consumed and returned. Aggregate peak RSS was not measured.
See outputs/Calendar_Replay_Green_2026-11-01/result.json under the task output root.
The separate INSERT-failure case and engine/live preparations were excluded and unrun.
Historical migration, direct-handler and provider/installed acceptance limits remain.

## Earlier native RED outcome

The sole allocated run executed all7cases:4passed and3intended completion replay
failures, runner6.21seconds. The three edit/reminder cases and authorization-before-
no-op case passed. Replay failures showed redundant UPDATE, different concurrent
completion timestamps/versions, and rejection of an original stale same-state token.
Later assertions not reached remain explicit in native-red-result.json.

The exact owned PG container and process group are gone. All four baseline containers,
including README preview PG, remain. The slot was returned after20:20:34Z verification.
Launch preflight was level1/50%; post-terminal sample was level2/36%. Early Mac RSS was
144048KiB before PG creation; aggregate peak was not measured and conformance is not
claimed. No setup/timeout failure or automatic retry occurred.

Only after actual RED, repo.ts received the minimum authorization-preserving same-
state return. Actual state changes retain revision checks. One-file Biome passed in
the bounded warning lane. Post-fix configured types/typed lint passed in the later
CAL-COMPILER-20261101-2 allocation; native GREEN still awaits a separate allocation.
No GREEN rerun has occurred.

Current receipts: outputs/Calendar_Event_Reminder_Native_2026-11-01/native-red-result.json,
native-cleanup.json, native-source-cut.json and replay-fix-pending-green.json under
the task output root. The preparation snapshots below describe earlier states.

## Seven-case preparation profile, before native RED

The active Testcontainers config now directly extends root Vitest config and selects
seven cases in three files: the original three edit/reminder cases; three unchanged
canonical `completeActivityReplay.integration.test.ts` cases; and one
`calendarCompletionRevisionReplay.integration.test.ts` stale-token case. The last
case rejects Activity and reminder settings/intent/rebuild DML, even zero-row DML,
on same-state replay, while a stale token still rejects an actual state change.
The completion replay implementation remains deliberately unchanged until native RED.

Actual completion52/52 and UI26/26 focused cases passed. Configured Next type
generation/root typecheck, scoped fixture typecheck and typed ESLint12 source plus8
fixture/config files passed. A formatter-only config indentation failure was
corrected and the relevant8-file Biome check passed. Source12 Biome also passed.
The receipts preserve earlier corrected tuple typing and the brief pressure2-start
exception. No database, Docker, native server, browser or provider job has run.

The proposed Settings slot is at most300seconds total for bounded native RED,
the minimum replay correction, relevant GREEN and exact owned cleanup. Normal
resource preflight and a recorded queue allocation are prerequisites. The job uses
`DOCKER_HOST=unix:///Users/ali/.colima/warpdrive/docker.sock`, neverPull and exact
fresh module/run labels. No generic controller is introduced. The historical54672
profile remains inactive; browser54673, peer55432 and previews3104/3116 are untouched.

Current private E_ACTIVITY_008 is COMPLETE_INPUT_INVALID; conflicts use E_ACTIVITY_009.
Static evidence and source hashes are in outputs/Calendar_Completion_Contract_2026-11-01/
qualification.json under the task output root. The historical three-case preparation
record below is superseded for current selection, config imports, error IDs and check
state. Its logical-transaction and direct-handler acceptance ceilings still apply.
The local migration lineage does not validate a canonical0098 upgrade or legacy-job
transition, and live worker/email/browser/Google/Meet acceptance remains separate.

## Historical three-case preparation snapshot

Prepared source only. Exactly three native integration cases are present and unrun.
No application, schema, migration, dependency, environment, checkout or ref changes
are made by this packet. No runtime/check/database/service/provider was invoked.

The first case uses a fresh shared activity version and a deliberately stale own
reminder revision. A real sequence-backed PostgreSQL trigger observes the tentative
activity date/subject/location/version and deal relink, replaced participant/guest
sets, preserved non-null person link, both recomputed deal dates and a touched
rebuild row. Its sequence survives rollback; both `is_called=true` and positive
`last_value` are required, so the uncalled initial value cannot satisfy it.
The failure must be precisely the own
reminder conflict, not the earlier shared-activity conflict or permission rejection.
The complete target activity, participants, guests, both linked deal rows, both
contact rows, every target reminder setting and intent including cancellations, and
the pre-existing rebuild row are compared after the error.

The second case applies identical shared changes with the current own revision. It
requires the same witness and durable successful values, preserved contact rows,
new personal reminder revision/rules and current notification intent, with the
rebuild row reconciled away. It controls fixture writability and witness reachability.

The third case is controlled-Date, direct-handler acceptance of scheduling/editing
and receiving one owner-visible in-app reminder. It invokes the actual
`handleReminderJob(db, { data: { intentId } }, signal, null)` against the real database
and notification writer. Only Date is faked at the persisted current intent's fire
time: before-due delivery stays silent, cancelled old intents stay silent, the due
current intent writes one receipt, and repeat calls leave both receipt and intent
rows unchanged. The real owner feed and unread count must expose exactly that one
receipt after the CRM/calendar/reminder visibility gates. Both a case `finally` and
the shared cleanup restore real Date before closing the test database.

This is an explicit controlled clock and direct handler invocation, not observation
of a live queue worker, elapsed wall-clock scheduling, a browser or an external
provider. The explicit null boss disables email handoff; email/live PgBoss delivery
is not claimed. PostgreSQL and abort-deadline timers remain real.

The exact configuration replaces inherited project selection with one integration
project and one test file, one worker, no file parallelism. It retains the existing
`.runtime/calendar-pg.setup.mts` native PostgreSQL16 setup on54672 and the ordinary
root alias/setup, with a global-fetch rejection installed before application imports.
`envDir:false` disables Vite env-file loading; its test env supplies only a synthetic
54672 URL, invalid test base URL, empty Calendar OAuth app and capture-only auth mail.
It must receive a fresh finite serialized allocation before any
command. The setup starts/stops its owned server and migrates the frozen local
Drizzle lineage; it must not be applied to a running or foreign cluster. The retained
browser fixture54673 and peer PostgreSQL55432 are separate, untouched resources.

The packet imports real existing `createActivity`, `updateActivity`, personal reminder
settings and real test database/factories. No database is mocked. Global fetch is
rejected and asserted unused. This is logical transaction/readback evidence only if
executed successfully, not crash recovery, bounded in-flight query cancellation,
browser/HTTP acceptance, live-worker/email/provider delivery or a main/installed
migration qualification. The third case's controlled-clock native handler and owner
feed readback are the limited in-app acceptance claim.

This packet targets the preserved WIP at2803183. Current canonical main has a different
meaning for E_ACTIVITY_008. Tests refer to the frozen symbolic ACTIVITY_CONFLICT cause;
the error registry is neither copied nor changed. A future admission must reconcile
that collision and the full schema/source closure against the then-admitted main.

Direct application dependencies are `activityUpdate`, `repo`, `calendars`,
`personalReminderSettings`, `reminderPolicy`, `permissions/effective`, the shared error
registry, database schema and factories, and `src/test/db.ts`. Their transitive
database/schema/migration dependencies remain the frozen application's existing ones.
The third case additionally imports the real reminder handler, notification feed and
notification/reminder-intent tables. External packages are Vitest, Drizzle and
node-postgres through those existing seams.
No new migration or test-only application implementation is supplied.

## Historical native invocation boundary

The original native proposal used the pinned Bun1.4.4 binary with
`--no-env-file --bun vitest run --project integration --config
.runtime/calendar-existing-edit-atomicity-pg.config.mts --maxWorkers=1`.
Its environment must be a reviewed clean OS whitelist, not inherited application
configuration: PATH, HOME, TMPDIR, LANG/LC_ALL, TERM and TZ as needed, plus fixed
NODE_ENV=test and CI=1. All provider/application credentials and every `*_FILE`
variable must be absent. The config's synthetic values and root test defaults do
not make inheriting secrets safe. No private env file is opened by this packet.
No command or runtime-version check has been executed during this preparation.
The active Testcontainers profile is described below; this native profile remains
available only if explicitly selected for a future heavy job.

The existing global setup unconditionally starts54672 before migration and owns its
teardown. Fresh admission must verify its exact PG16 executable/data/port identity
and stopped state before launch; an already running or foreign instance is a refusal,
not a restart. The finite outer supervisor must also account for setup failures and
owned PostgreSQL cleanup. Neither this config nor its inherited60/120second Vitest
timeouts supplies that outer resource authority or cleanup guarantee.

## Operating-agreement private fixture

The Testcontainers alternate now selects the private
`existingEditAtomicity.globalSetup.ts`, not the root or native global setup.
The native54672 config/setup is preserved as historical source. The alternate still
uses the same three cases and injected TestPgConnection/makeTestDb contract.

`existingEditAtomicityContainer.ts` inspects cached postgres16, freezes its local
image ID, uses the installed never-pull policy and disables Testcontainers automatic
cleanup registration so no Ryuk helper is started/shared. A supported protected
containerCreated hook records the full CID before startup/readiness and verifies
module/run labels and image identity. Cleanup inspects that exact owned CID before
stop/removal. If Docker create acknowledgement is lost, recovery lists only the exact
fresh module/run label pair, verifies each full CID and never prunes other resources.
Own event records contain no connection credentials.

Readiness has45second startup timeout. Own container inspection/removal requests
use10second AbortSignals; graceful stop allows5seconds. Dockerode5's installed
DELETE implementation forwards abortSignal although its remove-options declaration
omits that field. Pools have connection/query/server timeouts and error listeners;
admin/template pools close on every setup path before container disposal. The template
exists only in the disposable owned container/volume. Its removal is the template's
final cleanup. Global setup failure and normal teardown both dispose it.

These are ordinary private fixture controls, not a new process-controller project or
a guarantee that Docker discovery/create can never stall. The normal finite heavy
job still owns outer termination and cleanup verification if engine I/O fails or the
test process is killed. Before running, confirm cached image availability and record
protected resources. No image pull, dependency change, fixture or check has run.
Fsync/full-page writes remain off: only logical transaction/readback is in scope.

The scoped tsconfig overrides both include and exclude and disables incremental
output. ESLint removes only the root runtime ignore and binds the scoped TS project;
Biome is standalone with VCS ignores disabled. All seven active test/fixture TS files
and the alternate config are selected. The historical native config remains type
reachable through the alternate's import but is excluded from the active lint/format
selection to preserve its bytes. Parent must observe a nonzero intended-file count;
an ignored-file exit is not static evidence. No checks have been executed here.
