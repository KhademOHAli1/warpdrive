import { randomUUID } from "node:crypto";
import { PostgreSqlContainer, type StartedPostgreSqlContainer } from "@testcontainers/postgresql";
import {
  type ContainerRuntimeClient,
  getContainerRuntimeClient,
  ImageName,
  PullPolicy,
} from "testcontainers";
import { AppError, ERROR_IDS } from "@/constants/errorIds";

const IMAGE_TAG = "postgres:16-alpine";
const MODULE = "calendar-existing-edit-atomicity";
const MODULE_LABEL = "dev.warpdrive.fixture-module";
const RUN_LABEL = "dev.warpdrive.fixture-run";
const DOCKER_IO_MS = 10_000;
type RawContainer = ReturnType<ContainerRuntimeClient["container"]["getById"]>;

function statusIs(error: unknown, expected: number): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "statusCode" in error &&
    error.statusCode === expected
  );
}

function emit(event: string, runId: string, imageId: string, containerId: string | null) {
  console.warn(JSON.stringify({ event, module: MODULE, runId, imageId, containerId }));
}

async function inspectOwned(raw: RawContainer, runId: string) {
  const inspected = await raw.inspect({ abortSignal: AbortSignal.timeout(DOCKER_IO_MS) });
  if (
    inspected.Config.Labels[MODULE_LABEL] !== MODULE ||
    inspected.Config.Labels[RUN_LABEL] !== runId
  ) {
    throw new AppError(ERROR_IDS.DB_INVARIANT, "private fixture ownership changed");
  }
  return inspected;
}

async function removeOwned(raw: RawContainer, runId: string) {
  try {
    await inspectOwned(raw, runId);
  } catch (error) {
    if (statusIs(error, 404)) return;
    throw error;
  }
  try {
    await raw.stop({ t: 5, abortSignal: AbortSignal.timeout(DOCKER_IO_MS) });
  } catch (error) {
    if (!statusIs(error, 304) && !statusIs(error, 404)) {
      console.warn(JSON.stringify({ event: "private_fixture_graceful_stop_failed", runId }));
    }
  }
  // Installed dockerode5 forwards abortSignal for DELETE; its remove options type omits it.
  const options = { force: true, v: true, abortSignal: AbortSignal.timeout(DOCKER_IO_MS) };
  try {
    await raw.remove(options);
  } catch (error) {
    if (!statusIs(error, 404)) throw error;
  }
  try {
    await raw.inspect({ abortSignal: AbortSignal.timeout(DOCKER_IO_MS) });
  } catch (error) {
    if (statusIs(error, 404)) return;
    throw error;
  }
  throw new AppError(ERROR_IDS.DB_INVARIANT, "private fixture removal not confirmed");
}

async function recoverCreatedIds(client: ContainerRuntimeClient, runId: string): Promise<string[]> {
  const rows = await client.container.dockerode.listContainers({
    all: true,
    filters: { label: [`${MODULE_LABEL}=${MODULE}`, `${RUN_LABEL}=${runId}`] },
    abortSignal: AbortSignal.timeout(DOCKER_IO_MS),
  });
  return rows.map((row) => {
    if (
      !/^[a-f0-9]{64}$/.test(row.Id) ||
      row.Labels[MODULE_LABEL] !== MODULE ||
      row.Labels[RUN_LABEL] !== runId
    ) {
      throw new AppError(ERROR_IDS.DB_INVARIANT, "private fixture recovery ownership invalid");
    }
    return row.Id;
  });
}

export interface OwnedPostgresFixture {
  container: StartedPostgreSqlContainer;
  runId: string;
  dispose: () => Promise<void>;
}

export async function startOwnedPostgresFixture(): Promise<OwnedPostgresFixture> {
  const runId = randomUUID();
  const reference = ImageName.fromString(IMAGE_TAG);
  if (reference.string !== IMAGE_TAG)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "private fixture image reference overridden");
  const client = await getContainerRuntimeClient();
  const image = await client.image.inspect(reference);
  if (!/^sha256:[a-f0-9]{64}$/.test(image.Id))
    throw new AppError(ERROR_IDS.DB_INVARIANT, "cached fixture image ID invalid");
  // The installed ImageName API accepts a bare64hex local ID without adding :latest.
  const frozenReference = image.Id.slice("sha256:".length);
  if (ImageName.fromString(frozenReference).string !== frozenReference)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "frozen fixture image reference overridden");
  let containerId: string | null = null;
  let closing: Promise<void> | undefined;
  const dispose = (): Promise<void> => {
    closing ??= (async () => {
      const ids = containerId === null ? await recoverCreatedIds(client, runId) : [containerId];
      for (const id of ids) {
        emit("private_fixture_cleanup_owned", runId, image.Id, id);
        await removeOwned(client.container.getById(id), runId);
        emit("private_fixture_removed", runId, image.Id, id);
      }
    })();
    return closing;
  };
  class OwnedContainer extends PostgreSqlContainer {
    protected override async containerCreated(id: string): Promise<void> {
      if (!/^[a-f0-9]{64}$/.test(id))
        throw new AppError(ERROR_IDS.DB_INVARIANT, "created fixture CID invalid");
      containerId = id;
      emit("private_fixture_created", runId, image.Id, id);
      const inspected = await inspectOwned(client.container.getById(id), runId);
      if (inspected.Image !== image.Id)
        throw new AppError(ERROR_IDS.DB_INVARIANT, "created fixture image changed");
    }
  }
  emit("private_fixture_starting", runId, image.Id, null);
  try {
    const container = await new OwnedContainer(frozenReference)
      .withPullPolicy(PullPolicy.neverPull())
      .withAutoCleanup(false)
      .withAutoRemove(false)
      .withLabels({ [MODULE_LABEL]: MODULE, [RUN_LABEL]: runId })
      .withDatabase("calendar_atomicity")
      .withUsername("calendar_test")
      .withPassword(randomUUID())
      .withStartupTimeout(45_000)
      .withCommand([
        "postgres",
        "-c",
        "max_connections=30",
        "-c",
        "fsync=off",
        "-c",
        "full_page_writes=off",
        "-c",
        "statement_timeout=20s",
        "-c",
        "lock_timeout=5s",
        "-c",
        "idle_in_transaction_session_timeout=10s",
      ])
      .start();
    emit("private_fixture_ready", runId, image.Id, container.getId());
    return { container, runId, dispose };
  } catch (error) {
    try {
      await dispose();
    } catch {
      emit("private_fixture_cleanup_failed", runId, image.Id, containerId);
      throw new AppError(ERROR_IDS.DB_INVARIANT, "private fixture start and cleanup failed", {
        runId,
        containerId,
      });
    }
    throw error;
  }
}
