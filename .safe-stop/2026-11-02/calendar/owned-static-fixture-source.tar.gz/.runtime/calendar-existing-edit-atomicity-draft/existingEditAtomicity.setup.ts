import { vi } from "vitest";
import { AppError, ERROR_IDS } from "@/constants/errorIds";

// Setup executes before application imports; the cases replace this with an observed spy.
vi.stubGlobal("fetch", () =>
  Promise.reject(
    new AppError(ERROR_IDS.DB_INVARIANT, "external request before atomicity fixture setup"),
  ),
);
