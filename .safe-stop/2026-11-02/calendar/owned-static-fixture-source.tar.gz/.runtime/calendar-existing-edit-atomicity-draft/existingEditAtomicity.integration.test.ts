import { eq } from "drizzle-orm";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { activityReminderIntents, notifications } from "@/db/schema";
import { updateActivity } from "@/features/activities/activityUpdate";
import { getEventReminderSettings } from "@/features/activities/personalReminderSettings";
import { handleReminderJob } from "@/features/activities/reminders";
import { getFeed, getUnreadCount } from "@/features/notifications/feed";
import { makeTestDb, type TestDb } from "@/test/db";
import {
  AFTER_DUE,
  AFTER_END,
  AFTER_LOCATION,
  AFTER_SUBJECT,
  BEFORE_DUE,
  combinedEditInput,
  existingEditFixture,
  reminderSelection,
} from "./existingEditAtomicityFixture";
import { atomicitySnapshot } from "./existingEditAtomicitySnapshot";
import { installTentativeEditWitness, tentativeEditWitness } from "./existingEditAtomicityWitness";

let ctx: TestDb | undefined;
const network = vi.fn<typeof fetch>();
beforeEach(async () => {
  ctx = await makeTestDb();
  network.mockClear();
  network.mockRejectedValue(new AppError(ERROR_IDS.DB_INVARIANT, "unexpected external request"));
  vi.stubGlobal("fetch", network);
});
afterEach(async () => {
  try {
    expect(network).not.toHaveBeenCalled();
  } finally {
    vi.useRealTimers();
    vi.unstubAllGlobals();
    await ctx?.close();
    ctx = undefined;
  }
});
function database(): TestDb {
  if (ctx === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "test database absent");
  return ctx;
}

it("rolls back a witnessed existing-event shared edit when the own-reminder revision is stale", async () => {
  const db = database();
  const signal = AbortSignal.timeout(10_000);
  const fixture = await existingEditFixture(db, signal);
  expect(fixture.activity.version).toBe(fixture.createdVersion);
  expect(fixture.currentReminderRevision).toBe(fixture.staleRevision + 1);
  const before = await atomicitySnapshot(db, fixture, signal);
  expect(before.activity).toMatchObject([
    { deal_id: fixture.dealA, person_id: fixture.originalGuest },
  ]);
  expect(before.deals.find((row) => row.id === fixture.dealA)).toMatchObject({
    next_activity_at: new Date(BEFORE_DUE),
  });
  expect(before.deals.find((row) => row.id === fixture.dealB)).toMatchObject({
    next_activity_at: null,
  });
  expect(before.intents.some((row) => row.state === "cancelled")).toBe(true);
  expect(before.rebuilds).toHaveLength(1);
  await installTentativeEditWitness(db, fixture, signal);

  const result = await updateActivity(
    db.db,
    fixture.actor,
    combinedEditInput(fixture, fixture.staleRevision),
    signal,
  );
  expect(result).toMatchObject({
    ok: false,
    error: { id: ERROR_IDS.ACTIVITY_CONFLICT, message: "personal reminder revision changed" },
  });
  // Sequences survive rollback, so an early validation failure cannot satisfy this witness.
  const witness = await tentativeEditWitness(db, signal);
  expect(witness.isCalled).toBe(true);
  expect(witness.lastValue).toBeGreaterThan(0);
  expect(await atomicitySnapshot(db, fixture, signal)).toEqual(before);
});

it("commits the same existing-event edit and own-reminder selection with a fresh revision", async () => {
  const db = database();
  const signal = AbortSignal.timeout(10_000);
  const fixture = await existingEditFixture(db, signal);
  const before = await atomicitySnapshot(db, fixture, signal);
  await installTentativeEditWitness(db, fixture, signal);
  const result = await updateActivity(
    db.db,
    fixture.actor,
    combinedEditInput(fixture, fixture.currentReminderRevision),
    signal,
  );
  expect(result.ok).toBe(true);
  if (!result.ok) throw result.error;
  const witness = await tentativeEditWitness(db, signal);
  expect(witness.isCalled).toBe(true);
  expect(witness.lastValue).toBeGreaterThan(0);
  const after = await atomicitySnapshot(db, fixture, signal);
  expect(after.activity).toMatchObject([
    {
      id: fixture.activity.id,
      subject: AFTER_SUBJECT,
      location: AFTER_LOCATION,
      deal_id: fixture.dealB,
      person_id: fixture.originalGuest,
      due_at: new Date(AFTER_DUE),
      end_at: new Date(AFTER_END),
      version: fixture.activity.version + 1,
    },
  ]);
  expect(after.participants.map((row) => row.user_id)).toEqual([fixture.replacementParticipant]);
  expect(after.guests.map((row) => row.person_id)).toEqual([fixture.replacementGuest]);
  expect(after.deals.find((row) => row.id === fixture.dealA)).toMatchObject({
    next_activity_at: null,
  });
  expect(after.deals.find((row) => row.id === fixture.dealB)).toMatchObject({
    next_activity_at: new Date(AFTER_DUE),
  });
  expect(after.persons).toEqual(before.persons);
  expect(after.settings.filter((row) => row.user_id === fixture.actor.id)).toMatchObject([
    {
      version: fixture.currentReminderRevision + 1,
      use_default: false,
      rules: { timed: [{ method: "notification", minutesBefore: 5 }], allDay: [] },
    },
  ]);
  expect(
    after.intents.filter(
      (row) => row.assignee_id === fixture.actor.id && row.state !== "cancelled",
    ),
  ).toMatchObject([
    {
      due_at: new Date(AFTER_DUE),
      in_app: true,
      email: false,
      fire_at: new Date(new Date(AFTER_DUE).getTime() - 5 * 60_000),
    },
  ]);
  expect(after.rebuilds).toEqual([]);
  const own = await getEventReminderSettings(db.db, fixture.actor, fixture.activity.id, signal);
  expect(own).toMatchObject({
    ok: true,
    value: { revision: fixture.currentReminderRevision + 1, selection: reminderSelection(5) },
  });
});

it("controlled-Date direct handler persists one owner-visible reminder after edit and ignores cancelled/repeated intents", async () => {
  const db = database();
  const signal = AbortSignal.timeout(10_000);
  const fixture = await existingEditFixture(db, signal);
  const result = await updateActivity(
    db.db,
    fixture.actor,
    combinedEditInput(fixture, fixture.currentReminderRevision),
    signal,
  );
  expect(result.ok).toBe(true);
  if (!result.ok) throw result.error;
  const readIntents = () =>
    db.db
      .select()
      .from(activityReminderIntents)
      .where(eq(activityReminderIntents.activityId, fixture.activity.id))
      .orderBy(activityReminderIntents.id);
  const readNotes = () =>
    db.db.select().from(notifications).where(eq(notifications.userId, fixture.actor.id));
  const intents = await readIntents();
  const active = intents.filter(
    (row) => row.assigneeId === fixture.actor.id && row.state !== "cancelled",
  );
  const cancelled = intents.filter(
    (row) => row.assigneeId === fixture.actor.id && row.state === "cancelled",
  );
  expect(active).toHaveLength(1);
  expect(cancelled.length).toBeGreaterThan(0);
  const intent = active[0];
  if (intent === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "edited intent absent");
  expect(intent).toMatchObject({
    state: "pending",
    dueAt: new Date(AFTER_DUE),
    fireAt: new Date(new Date(AFTER_DUE).getTime() - 5 * 60_000),
    inApp: true,
    email: false,
  });
  expect(await readNotes()).toEqual([]);
  // Only Date is controlled; PostgreSQL, abort deadlines and the actual writer stay real.
  vi.useFakeTimers({ toFake: ["Date"] });
  try {
    vi.setSystemTime(new Date(intent.fireAt.getTime() - 1));
    await handleReminderJob(db.db, { data: { intentId: intent.id } }, signal, null);
    expect(await readNotes()).toEqual([]);
    vi.setSystemTime(new Date(intent.fireAt.getTime() + 1));
    for (const old of cancelled) {
      await handleReminderJob(db.db, { data: { intentId: old.id } }, signal, null);
    }
    expect(await readNotes()).toEqual([]);
    await handleReminderJob(db.db, { data: { intentId: intent.id } }, signal, null);
    const notes = await readNotes();
    expect(notes).toHaveLength(1);
    const receipt = notes[0];
    if (receipt === undefined)
      throw new AppError(ERROR_IDS.DB_INVARIANT, "reminder receipt absent");
    expect(receipt).toMatchObject({
      userId: fixture.actor.id,
      type: "activity_reminder",
      actorId: null,
      entityType: "deal",
      entityId: fixture.dealB,
      readAt: null,
      emailSentAt: null,
      payload: {
        activityId: fixture.activity.id,
        reminderIntentId: intent.id,
        subject: AFTER_SUBJECT,
        dueAt: AFTER_DUE,
      },
    });
    const delivered = await readIntents();
    expect(
      delivered.filter((row) => row.assigneeId === fixture.actor.id && row.state === "cancelled"),
    ).toEqual(cancelled);
    expect(delivered.find((row) => row.id === intent.id)).toMatchObject({
      state: "delivered",
      notificationId: receipt.id,
      deliveredAt: new Date(intent.fireAt.getTime() + 1),
      emailEnqueuedAt: null,
    });
    expect((await getFeed(db.db, fixture.actor, 20, signal)).map((row) => row.id)).toEqual([
      receipt.id,
    ]);
    expect(await getUnreadCount(db.db, fixture.actor, signal)).toBe(1);
    await handleReminderJob(db.db, { data: { intentId: intent.id } }, signal, null);
    for (const old of cancelled) {
      await handleReminderJob(db.db, { data: { intentId: old.id } }, signal, null);
    }
    expect(await readNotes()).toEqual(notes);
    expect(await readIntents()).toEqual(delivered);
    expect((await getFeed(db.db, fixture.actor, 20, signal)).map((row) => row.id)).toEqual([
      receipt.id,
    ]);
    expect(await getUnreadCount(db.db, fixture.actor, signal)).toBe(1);
  } finally {
    vi.useRealTimers();
  }
});
