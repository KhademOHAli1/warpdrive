import { fileURLToPath } from "node:url";
import { sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import { Pool } from "pg";
import type { TestProject } from "vitest/node";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import type { TestPgConnection } from "../../vitest.globalSetup";
import {
  type OwnedPostgresFixture,
  startOwnedPostgresFixture,
} from "./existingEditAtomicityContainer";

const TEMPLATE = "wd_calendar_atomicity_template";
const MIGRATIONS = fileURLToPath(new URL("../../drizzle", import.meta.url));

export default async function setup(project: TestProject): Promise<() => Promise<void>> {
  let fixture: OwnedPostgresFixture | undefined;
  const pools = new Set<Pool>();
  const closing = new Map<Pool, Promise<void>>();
  let cleanup: Promise<void> | undefined;
  const closePool = (pool: Pool): Promise<void> => {
    let result = closing.get(pool);
    if (result === undefined) {
      result = pool.end();
      closing.set(pool, result);
    }
    return result;
  };
  const dispose = (): Promise<void> => {
    cleanup ??= (async () => {
      const ended = await Promise.allSettled([...pools].map(closePool));
      let containerFailed = false;
      try {
        await fixture?.dispose();
      } catch {
        containerFailed = true;
      }
      if (containerFailed || ended.some((result) => result.status === "rejected")) {
        throw new AppError(ERROR_IDS.DB_INVARIANT, "private fixture cleanup incomplete", {
          runId: fixture?.runId,
          containerId: fixture?.container.getId(),
          containerFailed,
        });
      }
    })();
    return cleanup;
  };
  try {
    fixture = await startOwnedPostgresFixture();
    const connection: TestPgConnection = {
      host: fixture.container.getHost(),
      port: fixture.container.getPort(),
      user: fixture.container.getUsername(),
      password: fixture.container.getPassword(),
      adminDatabase: fixture.container.getDatabase(),
      template: TEMPLATE,
    };
    const openPool = (database: string): Pool => {
      const pool = new Pool({
        host: connection.host,
        port: connection.port,
        user: connection.user,
        password: connection.password,
        database,
        max: 2,
        connectionTimeoutMillis: 5_000,
        query_timeout: 25_000,
        statement_timeout: 20_000,
        idle_in_transaction_session_timeout: 10_000,
        allowExitOnIdle: true,
      });
      pool.on("error", () => {
        console.warn(
          JSON.stringify({ event: "private_fixture_pool_error", runId: fixture?.runId }),
        );
      });
      pools.add(pool);
      return pool;
    };
    const admin = openPool(connection.adminDatabase);
    try {
      await admin.query(`CREATE DATABASE ${TEMPLATE}`);
    } finally {
      await closePool(admin);
    }
    const template = openPool(TEMPLATE);
    try {
      const db = drizzle(template);
      await db.execute(sql`CREATE EXTENSION IF NOT EXISTS pgcrypto`);
      await db.execute(sql`CREATE EXTENSION IF NOT EXISTS citext`);
      await migrate(db, { migrationsFolder: MIGRATIONS });
      // Keep every cloned fixture on the same test-only engine contract.
      await template.query(`ALTER TABLE activities ADD COLUMN reminder_engine text
      NOT NULL DEFAULT 'legacy' CHECK (reminder_engine IN ('legacy','intent'))`);
    } finally {
      await closePool(template);
    }
    project.provide("testPg", connection);
    return dispose;
  } catch (error) {
    try {
      await dispose();
    } catch {
      throw new AppError(ERROR_IDS.DB_INVARIANT, "private fixture setup and cleanup failed", {
        runId: fixture?.runId,
        containerId: fixture?.container.getId(),
      });
    }
    throw error;
  }
}
