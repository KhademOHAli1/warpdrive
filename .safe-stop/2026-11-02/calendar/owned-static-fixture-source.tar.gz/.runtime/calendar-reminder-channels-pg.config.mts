import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({...base,test:{...base.test,name:'calendar-reminder-channels-pg',include:['src/features/notifications/reminderChannels.integration.test.ts','src/features/notifications/reminderEmailLifecycle.integration.test.ts','src/features/notifications/calendarPrivacy.integration.test.ts']}});
