// PREPARED ONLY. Stop the owned preview/worker before a separately authorized run.
import { existsSync, readFileSync } from 'node:fs';
import {
  FILES, FIXTURE, checkWorkspace, demand, digest, equal, exclusiveJson, lockFixture,
  migrationHead, newPool, originalEvents, privateJson, providerRows, replacePrivateJson,
  sharedSnapshot, type JsonRow, type SeedReceipt, type SharedSnapshot,
} from './calendar-browser-catalog-seed.mts';

function without(row: JsonRow, keys: string[]): JsonRow {
  return Object.fromEntries(Object.entries(row).filter(([key]) => !keys.includes(key)));
}
function expectedAccount(actual: JsonRow, original: JsonRow, seededAt: string): string {
  if (equal(actual, original)) return 'unchanged-connected';
  const mutable = ['status','version','connection_generation','refresh_token_enc','disconnected_at','updated_at'];
  demand(equal(without(actual, mutable), without(original, mutable)), 'Seed account identity or immutable metadata changed');
  demand(actual.status === 'disconnected' && actual.version === Number(original.version) + 1 &&
    actual.connection_generation === Number(original.connection_generation) + 1 && actual.refresh_token_enc === null,
    'Only one normal local Disconnect is allowed');
  for (const value of [actual.disconnected_at, actual.updated_at]) {
    demand(typeof value === 'string' && Number.isFinite(Date.parse(value)) &&
      Date.parse(value) >= Date.parse(seededAt) && Date.parse(value) <= Date.now() + 1_000,
      'Disconnect timestamp is outside the owned fixture window');
  }
  return 'one-local-disconnect';
}
function originalSnapshot(current: SharedSnapshot, receipt: SeedReceipt, localIds: string[]): void {
  const original = { ...current, calendars: current.calendars.filter((row) => !localIds.includes(String(row.id))) };
  demand(equal(original, receipt.before), 'Original event/calendar/shared state differs; do not delete or restore arbitrary rows');
  originalEvents(original);
}

async function main(): Promise<void> {
  demand(equal(process.argv.slice(2), ['--cleanup-local-browser-catalog']), 'Explicit local cleanup flag required');
  checkWorkspace();
  demand(!existsSync(FILES.cleanupReceipt) && !existsSync(FILES.cleanupProof), 'Cleanup receipt exists; do not rerun');
  const receipt = privateJson(FILES.seedReceipt) as SeedReceipt;
  demand(receipt.format === 1 && receipt.status === 'committed' && equal(receipt.fixture, FIXTURE) &&
    typeof receipt.seedId === 'string' && receipt.seedRows !== undefined && receipt.seedRows.accounts.length === 1,
    'A complete committed seed receipt is required; uncertain states need manual review');
  demand(digest(readFileSync(FILES.originalEnv)) === receipt.originalEnvHash, 'Original browser environment changed');
  demand(digest(readFileSync(FILES.catalogEnv)) === receipt.catalogEnvHash, 'Owned synthetic environment copy changed');
  const pool = newPool();
  const client = await pool.connect();
  let committed = false;
  try {
    await lockFixture(client);
    demand(equal(await migrationHead(client), receipt.migration), 'Migration boundary differs from the seed receipt');
    const current = await providerRows(client);
    demand(current.accounts.length === 1 && current.accounts[0]?.id === receipt.ids.accountId &&
      current.accounts[0]?.user_id === FIXTURE.ownerId && current.attempts.length === 0,
      'Unknown provider account/attempt state; cleanup refuses it');
    const shape = expectedAccount(current.accounts[0]!, receipt.seedRows.accounts[0]!, receipt.createdAt);
    demand(equal(current.states, receipt.seedRows.states) && equal(current.entries, receipt.seedRows.entries),
      'Catalog was refreshed, changed or replaced; only the exact seeded rows may be removed');
    demand(current.bindings.length <= 1, 'Unexpected number of provider bindings');
    const localIds: string[] = [];
    for (const binding of current.bindings) {
      demand(binding.user_id === FIXTURE.ownerId && binding.provider_calendar_id === receipt.ids.writerEntryId &&
        binding.calendar_source === 'provider' && typeof binding.id === 'string' && typeof binding.local_calendar_id === 'string',
        'Binding is not the owned synthetic writable catalog selection');
      demand([1,2,3].includes(Number(binding.version)) && binding.selected === (Number(binding.version) % 2 === 1),
        'Binding history exceeds the reviewed Add/Remove/re-Add flow');
      localIds.push(binding.local_calendar_id);
    }
    const shared = await sharedSnapshot(client);
    const providerCalendars = shared.calendars.filter((row) => row.source === 'provider');
    demand(providerCalendars.length === localIds.length, 'Unknown or orphan provider calendar exists');
    const writer = receipt.seedRows.entries.find((row) => row.id === receipt.ids.writerEntryId);
    const raw = writer?.raw as { summaryOverride?: string; summary?: string; id?: string; timeZone?: string } | undefined;
    demand(raw !== undefined, 'Seeded writable resource is missing');
    for (const calendar of providerCalendars) {
      demand(localIds.includes(String(calendar.id)) && calendar.owner_id === FIXTURE.ownerId &&
        calendar.is_primary === false && calendar.deleted_at === null && calendar.time_zone === raw.timeZone &&
        calendar.name === (raw.summaryOverride ?? raw.summary ?? raw.id),
        'Dedicated container has unknown identity, ownership or shared metadata');
      demand(typeof calendar.created_at === 'string' && Date.parse(calendar.created_at) >= Date.parse(receipt.createdAt),
        'Dedicated container predates this seed');
    }
    originalSnapshot(shared, receipt, localIds);
    const references = await client.query<{ events: number; members: number; defaults: number }>(`SELECT
      (SELECT count(*)::int FROM activities WHERE calendar_id=ANY($1::uuid[])) AS events,
      (SELECT count(*)::int FROM calendar_members WHERE calendar_id=ANY($1::uuid[])) AS members,
      (SELECT count(*)::int FROM calendar_reminder_defaults WHERE calendar_id=ANY($1::uuid[])) AS defaults`, [localIds]);
    demand(references.rows[0]?.events === 0 && references.rows[0]?.members === 0 && references.rows[0]?.defaults === 0,
      'Provider containers have event/ACL/reminder references; cleanup will not cascade them');
    const cleanup = { format: 1, status: 'prepared', seedId: receipt.seedId, fixture: FIXTURE.database,
      observedAt: new Date().toISOString(), accountShape: shape, removedCandidates: {
        accountId: receipt.ids.accountId, entryIds: [receipt.ids.writerEntryId, receipt.ids.freeBusyEntryId],
        bindingIds: current.bindings.map((row) => row.id), localCalendarIds: localIds,
        bindings: current.bindings, localCalendars: providerCalendars,
      }, originalBeforeCleanup: shared };
    exclusiveJson(FILES.cleanupReceipt, cleanup);
    const bindingIds = current.bindings.map((row) => row.id);
    const removedBindings = await client.query(`DELETE FROM calendar_provider_bindings
      WHERE id=ANY($1::uuid[]) AND user_id=$2 AND provider_calendar_id=$3 RETURNING id`,
      [bindingIds, FIXTURE.ownerId, receipt.ids.writerEntryId]);
    demand(removedBindings.rowCount === bindingIds.length, 'Binding deletion count changed');
    const removedEntries = await client.query(`DELETE FROM calendar_provider_calendars
      WHERE id=ANY($1::uuid[]) AND account_id=$2 AND user_id=$3 RETURNING id`,
      [[receipt.ids.writerEntryId, receipt.ids.freeBusyEntryId], receipt.ids.accountId, FIXTURE.ownerId]);
    demand(removedEntries.rowCount === 2, 'Catalog deletion count changed');
    const removedState = await client.query('DELETE FROM calendar_provider_catalog_states WHERE account_id=$1 RETURNING account_id', [receipt.ids.accountId]);
    demand(removedState.rowCount === 1, 'Catalog-state deletion count changed');
    const removedAccount = await client.query(`DELETE FROM calendar_provider_accounts
      WHERE id=$1 AND user_id=$2 AND provider_subject=$3 RETURNING id`,
      [receipt.ids.accountId, FIXTURE.ownerId, `local-catalog-synthetic:${receipt.seedId}`]);
    demand(removedAccount.rowCount === 1, 'Account deletion count changed');
    const removedCalendars = await client.query(`DELETE FROM calendars
      WHERE id=ANY($1::uuid[]) AND owner_id=$2 AND source='provider' AND is_primary=false RETURNING id`,
      [localIds, FIXTURE.ownerId]);
    demand(removedCalendars.rowCount === localIds.length, 'Dedicated-container deletion count changed');
    const after = await sharedSnapshot(client);
    demand(equal(after, receipt.before), 'Cleanup did not preserve every original shared field/state');
    originalEvents(after);
    const empty = await providerRows(client);
    demand(Object.values(empty).every((rows) => rows.length === 0), 'Unknown provider state remains');
    await client.query('COMMIT'); committed = true;
    cleanup.status = 'committed';
    replacePrivateJson(FILES.cleanupReceipt, { ...cleanup, after });
    const proof = { fixture: FIXTURE.database, seedId: receipt.seedId, accountShape: shape,
      removedAccountId: receipt.ids.accountId, removedEntryIds: [receipt.ids.writerEntryId, receipt.ids.freeBusyEntryId],
      removedBindingIds: bindingIds, removedDedicatedCalendarIds: localIds,
      originalEvents: 4, originalVersions: [2,3,3,1], completeOriginalSharedStatePreserved: true,
      providerAccounts: 0, oauthAttempts: 0, catalogStates: 0, catalogEntries: 0, bindings: 0,
      providerCalls: 0, acceptedRealGrant: false, databaseRecreated: false,
      originalEnvironmentUnchanged: true, privateReceipt: FILES.cleanupReceipt };
    exclusiveJson(FILES.cleanupProof, proof);
    console.log(JSON.stringify(proof, null, 2));
  } finally {
    if (!committed) await client.query('ROLLBACK').catch(() => undefined);
    client.release(); await pool.end();
  }
}

if (import.meta.main) await main().catch(() => {
  console.error('Local catalog cleanup stopped. Preserve receipts and do not remove or restore any other rows.');
  process.exitCode = 1;
});
