# Prepared local catalog browser fixture, UNRUN

These two scripts are source-only preparation. Neither has run or been checked. A fresh finite PostgreSQL/browser allowance is required after the coordinated native run. No real Google app, account, grant, token exchange, meeting or provider request is involved.

Only the original `calendar_browser_1793457725214` database at `127.0.0.1:54673`, role `calendar_browser`, active owner `d1a628e9-91fd-470d-b539-a0115d2f968d` is accepted. The scripts require the actual current `0092_calendar_provider_catalog` SQL hash and journal timestamp already present in Drizzle history. They never migrate, recreate a database, start PostgreSQL, or launch an app.

Stop the owned preview/worker and all fixture clients first. Seed checks zero provider accounts/attempts/catalogs/bindings, all existing calendars native, and the four original event IDs/versions against the preserved 0090 receipt (versions 2/3/3/1). It privately captures every event/calendar field plus memberships, guest/participant sets, personal defaults/settings, reminder receipts/rebuilds and notifications before adding one clearly synthetic account and two catalog rows. The account contains inert noncredential bytes, and its catalog is inserted locally as READY; this is not an accepted OAuth grant.

Future commands, only when separately authorized, from `/Users/ali/Developer/warpdrive-calendar`:

```sh
.runtime/bin/bun --env-file .runtime/calendar-browser.env .runtime/calendar-browser-catalog-seed.mts --seed-local-browser-catalog
```

Seed creates `.runtime/calendar-browser-catalog.env` exclusively with mode 0600, copying the private browser environment and adding dummy dedicated Calendar configuration. It refuses an original environment with nonempty Calendar credential settings. It does not change the original env. Use only this separate copy for the later owned preview, with inherited `GOOGLE_CALENDAR_OAUTH_CLIENT_ID`, `GOOGLE_CALENDAR_OAUTH_CLIENT_SECRET`, `GOOGLE_CALENDAR_ACCESS` and corresponding `_FILE` overrides unset. Do not print either env or a full private receipt.

Browser scope: open the saved catalog in FA/DE; inspect the valid-zone writer entry and disabled availability-only entry. Perform **at most one Add → Remove → re-Add sequence** on the writer entry (binding versions 1/2/3), distributed across the locales. Restore the original FA language preference after DE inspection. The dedicated calendar remains hidden from native calendar/event lists. One normal local Disconnect is allowed. **Never click Connect, Reconnect, Fetch calendars, or any Meet/join control.** Do not create/edit events, memberships, reminders or other records. Do not start a background worker.

Stop the preview and all fixture clients again, then, only within the granted cleanup window:

```sh
.runtime/bin/bun --env-file .runtime/calendar-browser.env .runtime/calendar-browser-catalog-cleanup.mts --cleanup-local-browser-catalog
```

Cleanup accepts exactly the unchanged connected seed account or one normal local Disconnect (version/generation +1, cleared inert bytes, populated disconnect timestamp). It requires the original catalog rows unchanged, at most the writer binding with the reviewed version/state sequence, no unknown/orphan provider calendars, and no event/ACL/reminder references to the new container. It records all binding/container UUIDs before deleting only those exact rows and the seed account/catalog. Every original shared snapshot must match both before and after cleanup. Any mismatch rolls back and requires review; no restoration or arbitrary deletion is attempted.

Private receipts and copied env remain private in `.runtime`; filtered `*-proof.json` files omit original event/calendar text and all environment values. Existing artifacts prevent reruns, including uncertain post-commit/file-write states. Preserve them for review. The original database, env and all original event/calendar fields and versions remain intact.
