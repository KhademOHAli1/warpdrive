import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({...base,test:{...base.test,name:'calendar-google-accounts-pg',include:['src/features/activities/providers/google/accountAuthorization.integration.test.ts','src/features/activities/providers/google/accountTokens.integration.test.ts']}});
