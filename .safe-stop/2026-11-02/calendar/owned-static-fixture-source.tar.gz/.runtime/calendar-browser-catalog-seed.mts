// PREPARED ONLY. Run solely after a fresh, finite local-fixture allowance.
import { createHash, randomUUID } from 'node:crypto';
import { closeSync, existsSync, fsyncSync, lstatSync, openSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { Pool, type PoolClient } from 'pg';

export const FIXTURE = {
  root: '/Users/ali/Developer/warpdrive-calendar',
  database: 'calendar_browser_1793457725214',
  host: '127.0.0.1', port: 54673, user: 'calendar_browser',
  ownerId: 'd1a628e9-91fd-470d-b539-a0115d2f968d',
  migration: '0092_calendar_provider_catalog',
};
export const FILES = {
  seedReceipt: '.runtime/calendar-browser-catalog-seed-receipt.json',
  seedProof: '.runtime/calendar-browser-catalog-seed-proof.json',
  cleanupReceipt: '.runtime/calendar-browser-catalog-cleanup-receipt.json',
  cleanupProof: '.runtime/calendar-browser-catalog-cleanup-proof.json',
  originalEnv: '.runtime/calendar-browser.env',
  catalogEnv: '.runtime/calendar-browser-catalog.env',
};
export type JsonRow = Record<string, unknown>;
export interface SharedSnapshot {
  events: JsonRow[]; calendars: JsonRow[]; members: JsonRow[]; defaults: JsonRow[];
  guests: JsonRow[]; participants: JsonRow[]; reminderSettings: JsonRow[];
  reminderIntents: JsonRow[]; rebuilds: JsonRow[]; notifications: JsonRow[];
}
export function demand(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}
export const digest = (value: string | Buffer) => createHash('sha256').update(value).digest('hex');
export const equal = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

export function checkWorkspace(): void {
  demand(process.cwd() === FIXTURE.root, 'Wrong workspace; this fixture is not portable');
  const runtime = lstatSync('.runtime');
  demand(runtime.isDirectory() && !runtime.isSymbolicLink(), 'Unexpected runtime directory');
  const url = new URL(process.env.DATABASE_URL ?? '');
  demand(['postgres:', 'postgresql:'].includes(url.protocol) && url.hostname === FIXTURE.host &&
    url.port === String(FIXTURE.port) && url.pathname === `/${FIXTURE.database}` &&
    decodeURIComponent(url.username) === FIXTURE.user && url.search === '',
  'Only the exact original loopback browser fixture is allowed');
}
export function privateJson(path: string): unknown {
  const info = lstatSync(path);
  demand(info.isFile() && !info.isSymbolicLink(), 'Receipt must be a regular private file');
  demand((info.mode & 0o077) === 0 && info.uid === process.getuid?.(), 'Receipt permissions/owner differ');
  return JSON.parse(readFileSync(path, 'utf8'));
}
export function exclusiveJson(path: string, value: unknown): void {
  const descriptor = openSync(path, 'wx', 0o600);
  try { writeFileSync(descriptor, JSON.stringify(value, null, 2) + '\n'); fsyncSync(descriptor); }
  finally { closeSync(descriptor); }
}
export function replacePrivateJson(path: string, value: unknown): void {
  privateJson(path);
  const temporary = `${path}.tmp-${randomUUID()}`;
  exclusiveJson(temporary, value);
  renameSync(temporary, path);
}
export function newPool(): Pool {
  // Explicit connection parts prevent a URL query parameter from redirecting this script.
  return new Pool({ host: FIXTURE.host, port: FIXTURE.port, user: FIXTURE.user,
    database: FIXTURE.database, max: 1, connectionTimeoutMillis: 3_000 });
}
export async function lockFixture(client: PoolClient): Promise<void> {
  const peers = await client.query<{ count: number }>(
    'SELECT count(*)::int AS count FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid()');
  demand(peers.rows[0]?.count === 0, 'Stop every owned preview/worker/client before fixture mutation');
  await client.query('BEGIN');
  await client.query("SET LOCAL lock_timeout = '2s'");
  await client.query("SET LOCAL statement_timeout = '5s'");
  const lock = await client.query<{ locked: boolean }>(
    "SELECT pg_try_advisory_xact_lock(hashtext('calendar-browser-catalog-fixture-v1')) AS locked");
  demand(lock.rows[0]?.locked === true, 'Another fixture mutation owns this boundary');
  const owner = await client.query<{ id: string; is_active: boolean }>(
    'SELECT id,is_active FROM users WHERE id=$1 FOR UPDATE', [FIXTURE.ownerId]);
  demand(owner.rows.length === 1 && owner.rows[0]?.is_active === true, 'Known owner is absent or inactive');
  await client.query(`LOCK TABLE activities, calendars, calendar_members, calendar_reminder_defaults,
    activity_guests, activity_participants, activity_reminder_settings, activity_reminder_intents,
    reminder_rebuilds, notifications, calendar_provider_accounts, calendar_oauth_attempts,
    calendar_provider_catalog_states, calendar_provider_calendars, calendar_provider_bindings
    IN ACCESS EXCLUSIVE MODE`);
}
export async function migrationHead(client: PoolClient) {
  const journal = JSON.parse(readFileSync('drizzle/meta/_journal.json', 'utf8')) as {
    entries: Array<{ idx: number; tag: string; when: number }>;
  };
  const latest = journal.entries.at(-1);
  demand(latest?.idx === 92 && latest.tag === FIXTURE.migration, 'Migration source head changed; review first');
  const sourceHash = digest(readFileSync(`drizzle/${latest.tag}.sql`));
  const history = await client.query<{ hash: string; created_at: string }>(
    'SELECT hash,created_at::text FROM drizzle.__drizzle_migrations ORDER BY created_at DESC,id DESC LIMIT 1');
  demand(history.rows[0]?.hash === sourceHash && history.rows[0]?.created_at === String(latest.when),
    'Fixture must already match the actual reviewed 0092 hash and journal; this script never migrates');
  return { tag: latest.tag, when: latest.when, sourceHash };
}
export async function sharedSnapshot(client: PoolClient): Promise<SharedSnapshot> {
  const rows = await client.query<SharedSnapshot>(`SELECT
    (SELECT coalesce(jsonb_agg(to_jsonb(a) ORDER BY id),'[]'::jsonb) FROM activities a) AS events,
    (SELECT coalesce(jsonb_agg(to_jsonb(c) ORDER BY id),'[]'::jsonb) FROM calendars c) AS calendars,
    (SELECT coalesce(jsonb_agg(to_jsonb(m) ORDER BY calendar_id,user_id),'[]'::jsonb) FROM calendar_members m) AS members,
    (SELECT coalesce(jsonb_agg(to_jsonb(d) ORDER BY calendar_id,user_id),'[]'::jsonb) FROM calendar_reminder_defaults d) AS defaults,
    (SELECT coalesce(jsonb_agg(to_jsonb(g) ORDER BY activity_id,person_id),'[]'::jsonb) FROM activity_guests g) AS guests,
    (SELECT coalesce(jsonb_agg(to_jsonb(p) ORDER BY activity_id,user_id),'[]'::jsonb) FROM activity_participants p) AS participants,
    (SELECT coalesce(jsonb_agg(to_jsonb(s) ORDER BY id),'[]'::jsonb) FROM activity_reminder_settings s) AS "reminderSettings",
    (SELECT coalesce(jsonb_agg(to_jsonb(i) ORDER BY id),'[]'::jsonb) FROM activity_reminder_intents i) AS "reminderIntents",
    (SELECT coalesce(jsonb_agg(to_jsonb(r) ORDER BY activity_id),'[]'::jsonb) FROM reminder_rebuilds r) AS rebuilds,
    (SELECT coalesce(jsonb_agg(to_jsonb(n) ORDER BY id),'[]'::jsonb) FROM notifications n) AS notifications`);
  demand(rows.rows.length === 1, 'Unable to capture complete fixture snapshot');
  return rows.rows[0]!;
}
export async function providerRows(client: PoolClient) {
  const rows = await client.query<{ accounts: JsonRow[]; attempts: JsonRow[]; states: JsonRow[]; entries: JsonRow[]; bindings: JsonRow[] }>(`SELECT
    (SELECT coalesce(jsonb_agg(to_jsonb(a) ORDER BY id),'[]'::jsonb) FROM calendar_provider_accounts a) AS accounts,
    (SELECT coalesce(jsonb_agg(to_jsonb(o) ORDER BY state_hash),'[]'::jsonb) FROM calendar_oauth_attempts o) AS attempts,
    (SELECT coalesce(jsonb_agg(to_jsonb(s) ORDER BY account_id),'[]'::jsonb) FROM calendar_provider_catalog_states s) AS states,
    (SELECT coalesce(jsonb_agg(to_jsonb(c) ORDER BY id),'[]'::jsonb) FROM calendar_provider_calendars c) AS entries,
    (SELECT coalesce(jsonb_agg(to_jsonb(b) ORDER BY id),'[]'::jsonb) FROM calendar_provider_bindings b) AS bindings`);
  return rows.rows[0]!;
}
export function originalEvents(snapshot: SharedSnapshot): void {
  const prior = JSON.parse(readFileSync('.runtime/calendar-browser-activation-migration.json', 'utf8')) as {
    fixture: string; authored: Array<{ id: string; version: number }>;
  };
  demand(prior.fixture === FIXTURE.database && prior.authored.length === 4, 'Known four-event reference missing');
  const expected = prior.authored.map(({ id, version }) => ({ id, version })).sort((a,b) => a.id.localeCompare(b.id));
  const actual = snapshot.events.map(({ id, version }) => ({ id, version })).sort((a,b) => String(a.id).localeCompare(String(b.id)));
  demand(equal(actual, expected) && equal(actual.map((r) => r.version).sort(), [1,2,3,3]),
    'Known event identities or versions 2/3/3/1 changed');
}

export interface SeedReceipt {
  format: 1; status: 'reserved' | 'prepared' | 'committed'; seedId: string; fixture: typeof FIXTURE;
  browserBaseUrl: string;
  createdAt: string; committedAt?: string; migration: { tag: string; when: number; sourceHash: string };
  originalEnvHash: string; catalogEnvHash?: string; before: SharedSnapshot;
  ids: { accountId: string; writerEntryId: string; freeBusyEntryId: string; runId: string };
  seedRows?: Awaited<ReturnType<typeof providerRows>>;
}

function copiedEnvironment(clientId: string, browserBaseUrl: string): { original: string; copy: string } {
  const original = readFileSync(FILES.originalEnv, 'utf8');
  const keys = ['BASE_URL', 'GOOGLE_CALENDAR_OAUTH_CLIENT_ID', 'GOOGLE_CALENDAR_OAUTH_CLIENT_SECRET', 'GOOGLE_CALENDAR_ACCESS'];
  for (const line of original.split(/\r?\n/)) {
    const match = line.match(/^(?:export\s+)?(GOOGLE_CALENDAR_OAUTH_CLIENT_(?:ID|SECRET)(?:_FILE)?)=(.*)$/);
    demand(!match || ['', '""', "''"].includes(match[2]!.trim()), 'Original browser env already contains Calendar credentials; review first');
  }
  const retained = original.split(/\r?\n/).filter((line) =>
    !keys.some((key) => new RegExp(`^(?:export\\s+)?${key}(?:_FILE)?=`).test(line)));
  return { original, copy: retained.join('\n') +
    `\n# SYNTHETIC LOCAL CATALOG ONLY: never Connect or Fetch.\nBASE_URL=${browserBaseUrl}\nGOOGLE_CALENDAR_OAUTH_CLIENT_ID=${clientId}\n` +
    'GOOGLE_CALENDAR_OAUTH_CLIENT_SECRET=local-catalog-inert-not-a-google-secret\nGOOGLE_CALENDAR_ACCESS=readOnly\n' };
}

async function main(): Promise<void> {
  demand(equal(process.argv.slice(2), ['--seed-local-browser-catalog']), 'Explicit local seed flag required');
  checkWorkspace();
  for (const path of [FILES.seedReceipt, FILES.seedProof, FILES.cleanupReceipt, FILES.cleanupProof, FILES.catalogEnv])
    demand(!existsSync(path), 'Fixture artifacts already exist; do not rerun or overwrite');
  const seedId = randomUUID();
  const ids = { accountId: randomUUID(), writerEntryId: randomUUID(), freeBusyEntryId: randomUUID(), runId: randomUUID() };
  const clientId = `local-browser-catalog-only-${seedId}`;
  // Unique loopback host isolates cookies from protected previews on other ports.
  const browserBaseUrl = `http://calendar-catalog-${seedId.slice(0, 8)}.localhost:3169`;
  const environment = copiedEnvironment(clientId, browserBaseUrl);
  const pool = newPool();
  const client = await pool.connect();
  let committed = false;
  try {
    await lockFixture(client);
    const migration = await migrationHead(client);
    const before = await sharedSnapshot(client);
    originalEvents(before);
    demand(before.calendars.every((row) => row.source === 'native'), 'Unexpected provider container already exists');
    const empty = await providerRows(client);
    demand(Object.values(empty).every((rows) => rows.length === 0), 'Expected zero accounts, attempts, catalogs and bindings');
    const createdAt = new Date().toISOString();
    const receipt: SeedReceipt = { format: 1, status: 'reserved', seedId, fixture: FIXTURE, browserBaseUrl,
      createdAt, migration, originalEnvHash: digest(environment.original), before, ids };
    exclusiveJson(FILES.seedReceipt, receipt);
    const marker = Buffer.from(`INERT LOCAL CATALOG ${seedId}; NOT AN OAUTH CREDENTIAL`, 'utf8');
    const scopes = ['https://www.googleapis.com/auth/calendar.calendarlist.readonly', 'https://www.googleapis.com/auth/calendar.events.readonly'];
    await client.query(`INSERT INTO calendar_provider_accounts
      (id,user_id,provider,provider_subject,client_id,email_address,refresh_token_enc,scopes,status,version,connection_generation,connected_at,updated_at)
      VALUES ($1,$2,'google',$3,$4,$5,$6,$7::jsonb,'connected',1,1,$8,$8)`,
      [ids.accountId, FIXTURE.ownerId, `local-catalog-synthetic:${seedId}`, clientId,
        `catalog-${seedId}@calendar-review.invalid`, marker, JSON.stringify(scopes), createdAt]);
    await client.query(`INSERT INTO calendar_provider_catalog_states
      (account_id,latest_run_id,requested_generation,request_expires_at,status,published_run_id,published_generation,revision,sync_token,discovered_at)
      VALUES ($1,$2,1,$3,'ready',$2,1,1,$4,$5)`,
      [ids.accountId, ids.runId, new Date(Date.parse(createdAt) + 60_000).toISOString(), `local-inert-cursor:${seedId}`, createdAt]);
    const resources = [
      { id: ids.writerEntryId, raw: { id: `local-only/${seedId}/team?catalog=synthetic`, summary: 'تقویم آزمایشی / Testkalender',
        summaryOverride: 'نمایش محلی / Lokale Anzeige', accessRole: 'writer', timeZone: 'Asia/Tehran', hidden: false,
        conferenceProperties: { allowedConferenceSolutionTypes: ['hangoutsMeet'] } } },
      { id: ids.freeBusyEntryId, raw: { id: `local-only/${seedId}/availability`, summary: 'فقط آزاد/مشغول / Nur Verfügbarkeit',
        accessRole: 'freeBusyReader', timeZone: 'Europe/Berlin', hidden: false } },
    ];
    for (const resource of resources) await client.query(`INSERT INTO calendar_provider_calendars
      (id,account_id,user_id,calendar_id,raw,connection_generation,last_seen_revision) VALUES ($1,$2,$3,$4,$5::jsonb,1,1)`,
      [resource.id, ids.accountId, FIXTURE.ownerId, resource.raw.id, JSON.stringify(resource.raw)]);
    demand(equal(await sharedSnapshot(client), before), 'Seeding changed original shared fixture state');
    receipt.seedRows = await providerRows(client);
    demand(receipt.seedRows.accounts.length === 1 && receipt.seedRows.states.length === 1 &&
      receipt.seedRows.entries.length === 2 && receipt.seedRows.attempts.length === 0 && receipt.seedRows.bindings.length === 0,
      'Unexpected seed row counts');
    receipt.status = 'prepared'; receipt.catalogEnvHash = digest(environment.copy);
    replacePrivateJson(FILES.seedReceipt, receipt);
    const descriptor = openSync(FILES.catalogEnv, 'wx', 0o600);
    try { writeFileSync(descriptor, environment.copy); fsyncSync(descriptor); } finally { closeSync(descriptor); }
    await client.query('COMMIT'); committed = true;
    receipt.status = 'committed'; receipt.committedAt = new Date().toISOString();
    replacePrivateJson(FILES.seedReceipt, receipt);
    const proof = { fixture: FIXTURE.database, ownerId: FIXTURE.ownerId, seedId, migration, browserBaseUrl,
      seededAccountId: ids.accountId, catalogEntryIds: [ids.writerEntryId, ids.freeBusyEntryId],
      originalEvents: 4, versionsPreserved: [2,3,3,1], originalSharedStatePreserved: true,
      oauthAttempts: 0, providerCalls: 0, syntheticRowsOnly: true, acceptedRealGrant: false,
      databaseRecreated: false, applicationStarted: false, privateReceipt: FILES.seedReceipt };
    exclusiveJson(FILES.seedProof, proof);
    console.log(JSON.stringify(proof, null, 2));
  } finally {
    if (!committed) await client.query('ROLLBACK').catch(() => undefined);
    client.release(); await pool.end();
  }
}

if (import.meta.main) await main().catch(() => {
  console.error('Local catalog seed stopped. Preserve artifacts, inspect the private receipt, and do not rerun automatically.');
  process.exitCode = 1;
});
