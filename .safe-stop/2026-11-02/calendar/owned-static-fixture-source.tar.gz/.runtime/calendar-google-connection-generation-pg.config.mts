import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({...base,test:{...base.test,name:'calendar-google-connection-generation',maxWorkers:1,include:['src/features/activities/providers/google/accountConnectionGeneration.integration.test.ts']}});
