import {defineConfig} from 'vitest/config';
import base from './calendar-personal-all-pg.config.mts';
export default defineConfig({...base,test:{...base.test,include:['src/features/activities/calendarReminderCatalog.integration.test.ts']}});
