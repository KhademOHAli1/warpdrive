import { defineConfig } from 'vitest/config';
import base from './calendar-pg.config.mts';
export default defineConfig({...base,test:{...base.test,name:'calendar-google-routes-pg',include:['src/features/activities/providers/google/authorizationRoutes.integration.test.ts','src/features/activities/providers/google/accountOffboarding.integration.test.ts','src/features/auth/management/offboarding.integration.test.ts']}});
