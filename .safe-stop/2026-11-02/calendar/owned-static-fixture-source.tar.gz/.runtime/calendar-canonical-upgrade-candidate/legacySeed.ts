import type { Pool } from "pg";
import { AppError, ERROR_IDS } from "@/constants/errorIds";

async function insertId(pool: Pool, text: string, values: unknown[], signal: AbortSignal) {
  signal.throwIfAborted();
  const result = await pool.query<{ id: string }>(text, values);
  signal.throwIfAborted();
  const id = result.rows[0]?.id;
  if (id === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "canonical legacy seed absent");
  return id;
}

export async function seedCanonicalLegacy(pool: Pool, signal: AbortSignal) {
  signal.throwIfAborted();
  // Use only pre-upgrade columns. The private ORM Activity schema is deliberately unsuitable here.
  const ownerId = await insertId(
    pool,
    "INSERT INTO users (email,name,is_admin) VALUES ($1,$2,true) RETURNING id",
    ["canonical-upgrade@example.invalid", "Canonical upgrade owner"],
    signal,
  );
  const pipelineId = await insertId(
    pool,
    "INSERT INTO pipelines (name) VALUES ($1) RETURNING id",
    ["Legacy pipeline"],
    signal,
  );
  const stageId = await insertId(
    pool,
    "INSERT INTO stages (pipeline_id,name) VALUES ($1,$2) RETURNING id",
    [pipelineId, "Legacy stage"],
    signal,
  );
  const orgId = await insertId(
    pool,
    "INSERT INTO organizations (name,owner_id,visibility_level) VALUES ($1,$2,'owner') RETURNING id",
    ["Legacy organization", ownerId],
    signal,
  );
  const personId = await insertId(
    pool,
    "INSERT INTO persons (name,org_id,owner_id,visibility_level) VALUES ($1,$2,$3,'owner') RETURNING id",
    ["Legacy contact", orgId, ownerId],
    signal,
  );
  const dealId = await insertId(
    pool,
    "INSERT INTO deals (title,pipeline_id,stage_id,owner_id,person_id,org_id,visibility_level) VALUES ($1,$2,$3,$4,$5,$6,'owner') RETURNING id",
    ["Legacy deal", pipelineId, stageId, ownerId, personId, orgId],
    signal,
  );
  const type = await pool.query<{ id: string }>(
    "SELECT id FROM activity_types WHERE key='meeting'",
  );
  signal.throwIfAborted();
  const typeId = type.rows[0]?.id;
  if (typeId === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "canonical meeting type absent");
  const activityIds: string[] = [];
  const rows = [
    {
      subject: "Legacy future witness",
      due: "2030-06-15T09:00:00.000Z",
      end: "2030-06-15T09:45:00.000Z",
    },
    {
      subject: "Legacy past receipt",
      due: "2025-03-21T09:00:00.000Z",
      end: "2025-03-21T09:45:00.000Z",
    },
  ] as const;
  for (const row of rows) {
    activityIds.push(
      await insertId(
        pool,
        `INSERT INTO activities
      (type_id,subject,owner_id,assignee_id,deal_id,person_id,org_id,due_at,end_at,
       all_day,due_date,end_date,duration_minutes,priority,note,location,video_call_url,
       custom_fields,created_at,updated_at)
      VALUES ($1,$2,$3,$3,$4,$5,$6,$7,$8,false,null,null,45,'high',$9,$10,$11,$12::jsonb,$13,$14)
      RETURNING id`,
        [
          typeId,
          row.subject,
          ownerId,
          dealId,
          personId,
          orgId,
          row.due,
          row.end,
          "<p>Preserve this legacy note</p>",
          "Legacy location",
          "https://example.invalid/legacy-call",
          JSON.stringify({ migrationWitness: row.subject }),
          "2024-02-03T04:05:06.000Z",
          "2024-02-04T05:06:07.000Z",
        ],
        signal,
      ),
    );
  }
  const pastId = activityIds[1];
  if (pastId === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "past legacy activity absent");
  const notificationId = await insertId(
    pool,
    `INSERT INTO notifications
    (user_id,type,entity_type,entity_id,actor_id,payload,created_at)
    VALUES ($1,'activity_reminder','deal',$2,null,$3::jsonb,$4) RETURNING id`,
    [
      ownerId,
      dealId,
      JSON.stringify({ activityId: pastId, subject: rows[1].subject, dueAt: rows[1].due }),
      "2025-03-21T08:50:00.000Z",
    ],
    signal,
  );
  return {
    ownerId,
    pipelineId,
    stageId,
    orgId,
    personId,
    dealId,
    typeId,
    activityIds,
    notificationId,
  };
}
