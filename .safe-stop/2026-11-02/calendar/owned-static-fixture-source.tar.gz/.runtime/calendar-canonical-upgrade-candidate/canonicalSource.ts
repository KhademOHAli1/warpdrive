import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { z } from "zod";
import { AppError, ERROR_IDS } from "@/constants/errorIds";

export const CANONICAL_MAIN = "fc5fae837b4b8e532a8bfd89ff303e941bcf1439";
const REPOSITORY = fileURLToPath(new URL("../../", import.meta.url));
const pinSchema = z.object({
  idx: z.number().int().nonnegative(),
  tag: z.string().regex(/^\d{4}_[a-z0-9_]+$/),
  when: z.number().int().positive().max(Number.MAX_SAFE_INTEGER),
  sha256: z.string().regex(/^[a-f0-9]{64}$/),
});
const manifestSchema = z.object({
  main: z.literal(CANONICAL_MAIN),
  journalSha256: z.string().regex(/^[a-f0-9]{64}$/),
  migrations: z.array(pinSchema).length(98),
});
const journalSchema = z.object({
  version: z.literal("7"),
  dialect: z.literal("postgresql"),
  entries: z
    .array(
      pinSchema.omit({ sha256: true }).extend({
        version: z.literal("7"),
        breakpoints: z.boolean(),
      }),
    )
    .length(98),
});
export type CanonicalPin = z.infer<typeof pinSchema>;

export function sha256(bytes: string | Buffer): string {
  return createHash("sha256").update(bytes).digest("hex");
}

const execFileAsync = promisify(execFile);

async function gitBytes(path: string, signal: AbortSignal): Promise<Buffer> {
  try {
    const { stdout } = await execFileAsync("git", ["show", `${CANONICAL_MAIN}:${path}`], {
      cwd: REPOSITORY,
      encoding: "buffer",
      signal,
      timeout: 10_000,
      maxBuffer: 8 * 1024 * 1024,
    });
    signal.throwIfAborted();
    return stdout;
  } catch (error) {
    signal.throwIfAborted();
    throw error;
  }
}

export async function readCanonicalSource(signal: AbortSignal) {
  signal.throwIfAborted();
  const manifestBytes = await readFile(
    new URL("./canonical-source-manifest.json", import.meta.url),
    { signal },
  );
  signal.throwIfAborted();
  const manifest = manifestSchema.parse(JSON.parse(manifestBytes.toString("utf8")));
  const journalBytes = await gitBytes("drizzle/meta/_journal.json", signal);
  signal.throwIfAborted();
  if (sha256(journalBytes) !== manifest.journalSha256)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "canonical journal pin changed");
  const journal = journalSchema.parse(JSON.parse(journalBytes.toString("utf8")));
  const migrations: Array<CanonicalPin & { bytes: Buffer }> = [];
  let previousWhen = 0;
  for (const [position, entry] of journal.entries.entries()) {
    const expected = manifest.migrations[position];
    if (
      expected === undefined ||
      entry.idx !== position ||
      Number(entry.tag.slice(0, 4)) !== position ||
      entry.when <= previousWhen ||
      entry.tag !== expected.tag ||
      entry.when !== expected.when ||
      entry.idx !== expected.idx
    )
      throw new AppError(ERROR_IDS.DB_INVARIANT, "canonical migration identity/order changed");
    const bytes = await gitBytes(`drizzle/${entry.tag}.sql`, signal);
    signal.throwIfAborted();
    if (sha256(bytes) !== expected.sha256)
      throw new AppError(ERROR_IDS.DB_INVARIANT, "canonical SQL pin changed", { tag: entry.tag });
    migrations.push({ ...expected, bytes });
    previousWhen = entry.when;
  }
  return { journalBytes, journal, migrations };
}
