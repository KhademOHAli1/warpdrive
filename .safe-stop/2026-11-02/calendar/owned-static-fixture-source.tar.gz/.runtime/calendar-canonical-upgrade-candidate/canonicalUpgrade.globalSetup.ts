import { sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import { Pool } from "pg";
import type { TestProject } from "vitest/node";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import type { TestPgConnection } from "../../vitest.globalSetup";
import {
  type OwnedPostgresFixture,
  startOwnedPostgresFixture,
} from "../calendar-existing-edit-atomicity-draft/existingEditAtomicityContainer";
import { prepareMigrationFolders } from "./migrationFolders";
import { verifyMigrationLedger } from "./migrationLedger";

const TEMPLATE = "wd_calendar_canonical_upgrade_template";

export default async function setup(project: TestProject): Promise<() => Promise<void>> {
  const signal = AbortSignal.timeout(60_000);
  let fixture: OwnedPostgresFixture | undefined;
  let folders: Awaited<ReturnType<typeof prepareMigrationFolders>> | undefined;
  const pools = new Set<Pool>();
  const closing = new Map<Pool, Promise<void>>();
  let cleanup: Promise<void> | undefined;
  const closePool = (pool: Pool): Promise<void> => {
    let result = closing.get(pool);
    if (result === undefined) {
      result = pool.end();
      closing.set(pool, result);
    }
    return result;
  };
  const dispose = (): Promise<void> => {
    cleanup ??= (async () => {
      const ended = await Promise.allSettled([...pools].map(closePool));
      const remaining = await Promise.allSettled([fixture?.dispose(), folders?.dispose()]);
      if (
        ended.some((result) => result.status === "rejected") ||
        remaining.some((result) => result.status === "rejected")
      )
        throw new AppError(ERROR_IDS.DB_INVARIANT, "canonical upgrade fixture cleanup incomplete", {
          runId: fixture?.runId,
          containerId: fixture?.container.getId(),
        });
    })();
    return cleanup;
  };
  try {
    folders = await prepareMigrationFolders(signal);
    signal.throwIfAborted();
    fixture = await startOwnedPostgresFixture();
    signal.throwIfAborted();
    const connection: TestPgConnection = {
      host: fixture.container.getHost(),
      port: fixture.container.getPort(),
      user: fixture.container.getUsername(),
      password: fixture.container.getPassword(),
      adminDatabase: fixture.container.getDatabase(),
      template: TEMPLATE,
    };
    const openPool = (database: string): Pool => {
      const pool = new Pool({
        host: connection.host,
        port: connection.port,
        user: connection.user,
        password: connection.password,
        database,
        max: 2,
        connectionTimeoutMillis: 5_000,
        query_timeout: 25_000,
        statement_timeout: 20_000,
        idle_in_transaction_session_timeout: 10_000,
        allowExitOnIdle: true,
      });
      pool.on("error", () => {
        console.warn(
          JSON.stringify({ event: "canonical_upgrade_pool_error", runId: fixture?.runId }),
        );
      });
      pools.add(pool);
      return pool;
    };
    const admin = openPool(connection.adminDatabase);
    try {
      await admin.query(`CREATE DATABASE ${TEMPLATE}`);
      signal.throwIfAborted();
    } finally {
      await closePool(admin);
    }
    const template = openPool(TEMPLATE);
    try {
      const db = drizzle(template);
      await db.execute(sql`CREATE EXTENSION IF NOT EXISTS pgcrypto`);
      signal.throwIfAborted();
      await db.execute(sql`CREATE EXTENSION IF NOT EXISTS citext`);
      signal.throwIfAborted();
      await migrate(db, { migrationsFolder: folders.canonical });
      signal.throwIfAborted();
      await verifyMigrationLedger(template, folders.upgrade.canonicalMigrations, signal);
    } finally {
      await closePool(template);
    }
    project.provide("testPg", connection);
    project.provide("calendarCanonicalUpgrade", folders.upgrade);
    console.warn(
      JSON.stringify({
        event: "canonical_upgrade_fixture_ready",
        canonicalCount: folders.upgrade.canonicalMigrations.length,
        baselineHash: folders.upgrade.baselineHash,
        baselineWhen: folders.upgrade.baselineWhen,
        runId: fixture.runId,
      }),
    );
    return dispose;
  } catch (error) {
    await dispose();
    throw error;
  }
}
