import { and, eq } from "drizzle-orm";
import { expect } from "vitest";
import { activityReminderIntents } from "@/db/schema";
import { createCalendar } from "@/features/activities/calendars";
import { createActivity } from "@/features/activities/repo";
import type { PermSetUser } from "@/features/permissions/effective";
import type { TestDb } from "@/test/db";
import type { seedCanonicalLegacy } from "./legacySeed";

export async function nativeCreateControl(
  ctx: TestDb,
  seed: Awaited<ReturnType<typeof seedCanonicalLegacy>>,
  signal: AbortSignal,
): Promise<void> {
  const actor: PermSetUser = {
    id: seed.ownerId,
    type: "admin",
    isActive: true,
    flags: new Set(),
    groupIds: new Set(),
  };
  const calendar = await createCalendar(
    ctx.db,
    actor,
    { name: "Upgraded native calendar", timeZone: "Asia/Tehran" },
    signal,
  );
  signal.throwIfAborted();
  expect(calendar.ok).toBe(true);
  if (!calendar.ok) throw calendar.error;
  const created = await createActivity(
    ctx.db,
    actor,
    {
      typeId: seed.typeId,
      subject: "Native create after canonical upgrade",
      dueAt: "2031-06-15T09:00:00.000Z",
      calendarId: calendar.value.id,
      eventTimeZone: "Asia/Tehran",
      dealId: seed.dealId,
      personId: seed.personId,
      orgId: seed.orgId,
      personalReminders: {
        expectedRevision: 0,
        selection: {
          useDefault: false,
          timed: [{ method: "notification", minutesBefore: 0 }],
          allDay: [],
        },
      },
    },
    signal,
  );
  signal.throwIfAborted();
  expect(created.ok).toBe(true);
  if (!created.ok) throw created.error;
  expect(created.value).toMatchObject({
    reminderEngine: "intent",
    reminderAutomationEnabled: true,
    version: 1,
    calendarId: calendar.value.id,
    dealId: seed.dealId,
    personId: seed.personId,
    orgId: seed.orgId,
  });
  const intents = await ctx.db
    .select()
    .from(activityReminderIntents)
    .where(
      and(
        eq(activityReminderIntents.activityId, created.value.id),
        eq(activityReminderIntents.state, "pending"),
      ),
    );
  signal.throwIfAborted();
  expect(intents).toMatchObject([
    {
      activityId: created.value.id,
      assigneeId: seed.ownerId,
      state: "pending",
      inApp: true,
      email: false,
    },
  ]);
  expect(intents).toHaveLength(1);
}
