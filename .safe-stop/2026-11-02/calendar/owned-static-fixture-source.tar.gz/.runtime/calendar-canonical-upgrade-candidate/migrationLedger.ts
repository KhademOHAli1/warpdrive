import type { Pool } from "pg";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import type { CanonicalPin } from "./canonicalSource";

export async function verifyMigrationLedger(
  pool: Pool,
  expected: ReadonlyArray<Pick<CanonicalPin, "sha256" | "when">>,
  signal: AbortSignal,
): Promise<void> {
  signal.throwIfAborted();
  const rows = await pool.query<{ hash: string; created_at: string | number }>(
    "SELECT hash, created_at FROM drizzle.__drizzle_migrations ORDER BY created_at, id",
  );
  signal.throwIfAborted();
  if (
    rows.rows.length !== expected.length ||
    rows.rows.some((row, index) => {
      const pin = expected[index];
      return (
        pin === undefined || row.hash !== pin.sha256 || String(row.created_at) !== String(pin.when)
      );
    })
  )
    throw new AppError(ERROR_IDS.DB_INVARIANT, "canonical migration ledger/hash mismatch");
}
