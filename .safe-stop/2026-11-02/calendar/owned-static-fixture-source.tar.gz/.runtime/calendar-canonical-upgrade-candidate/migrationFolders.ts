import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { z } from "zod";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { type CanonicalPin, readCanonicalSource, sha256 } from "./canonicalSource";

const BASELINE_TAG = "0098_calendar_native_no_activation_test_candidate";
const baselineSchema = z.object({
  fragments: z
    .array(
      z.object({
        file: z.string().regex(/^[a-z0-9_]+\.sql$/),
        sha256: z.string().regex(/^[a-f0-9]{64}$/),
      }),
    )
    .min(1),
});

export interface UpgradeSource {
  folder: string;
  canonicalMigrations: CanonicalPin[];
  baselineHash: string;
  baselineWhen: number;
}

declare module "vitest" {
  interface ProvidedContext {
    calendarCanonicalUpgrade: UpgradeSource;
  }
}

async function baselineSql(signal: AbortSignal): Promise<Buffer> {
  const manifestBytes = await readFile(
    new URL("./native-corrected-baseline-manifest.json", import.meta.url),
    { signal },
  );
  signal.throwIfAborted();
  const manifest = baselineSchema.parse(JSON.parse(manifestBytes.toString("utf8")));
  const fragments: Buffer[] = [];
  for (const part of manifest.fragments) {
    const bytes = await readFile(new URL(`./baseline/${part.file}`, import.meta.url), { signal });
    signal.throwIfAborted();
    if (sha256(bytes) !== part.sha256)
      throw new AppError(ERROR_IDS.DB_INVARIANT, "historical native test SQL changed", {
        file: part.file,
      });
    fragments.push(bytes);
  }
  // A breakpoint between fragments preserves complete functions without semicolon splitting.
  return Buffer.concat(
    fragments.flatMap((bytes, index) => {
      if (index === 0) return [bytes];
      const previous = fragments[index - 1];
      if (previous === undefined)
        throw new AppError(ERROR_IDS.DB_INVARIANT, "SQL fragment order absent");
      const separator = previous.toString("utf8").trimEnd().endsWith("--> statement-breakpoint")
        ? "\n"
        : "\n--> statement-breakpoint\n";
      return [Buffer.from(separator), bytes];
    }),
  );
}

export async function prepareMigrationFolders(signal: AbortSignal) {
  signal.throwIfAborted();
  const source = await readCanonicalSource(signal);
  const baseline = await baselineSql(signal);
  signal.throwIfAborted();
  const root = await mkdtemp(join(tmpdir(), "calendar_canonical_upgrade_"));
  try {
    signal.throwIfAborted();
    const canonical = join(root, "canonical");
    const upgraded = join(root, "upgraded");
    for (const folder of [canonical, upgraded]) {
      await mkdir(join(folder, "meta"), { recursive: true });
      signal.throwIfAborted();
      for (const migration of source.migrations) {
        const destination = join(folder, `${migration.tag}.sql`);
        await writeFile(destination, migration.bytes, { signal });
        const copied = await readFile(destination, { signal });
        signal.throwIfAborted();
        if (sha256(copied) !== migration.sha256)
          throw new AppError(ERROR_IDS.DB_INVARIANT, "copied canonical SQL changed");
      }
    }
    await writeFile(join(canonical, "meta/_journal.json"), source.journalBytes, { signal });
    signal.throwIfAborted();
    const copiedJournal = await readFile(join(canonical, "meta/_journal.json"), { signal });
    signal.throwIfAborted();
    if (sha256(copiedJournal) !== sha256(source.journalBytes))
      throw new AppError(ERROR_IDS.DB_INVARIANT, "copied canonical journal changed");
    const last = source.journal.entries.at(-1);
    if (last === undefined)
      throw new AppError(ERROR_IDS.DB_INVARIANT, "canonical last migration absent");
    const baselineWhen = last.when + 1;
    await writeFile(join(upgraded, `${BASELINE_TAG}.sql`), baseline, { signal });
    signal.throwIfAborted();
    await writeFile(
      join(upgraded, "meta/_journal.json"),
      JSON.stringify({
        ...source.journal,
        entries: [
          ...source.journal.entries,
          {
            idx: 98,
            version: "7",
            when: baselineWhen,
            tag: BASELINE_TAG,
            breakpoints: true,
          },
        ],
      }),
      { signal },
    );
    signal.throwIfAborted();
    const upgrade: UpgradeSource = {
      folder: upgraded,
      canonicalMigrations: source.migrations.map(({ idx, tag, when, sha256: hash }) => ({
        idx,
        tag,
        when,
        sha256: hash,
      })),
      baselineHash: sha256(baseline),
      baselineWhen,
    };
    return { root, canonical, upgrade, dispose: () => rm(root, { recursive: true, force: true }) };
  } catch (error) {
    await rm(root, { recursive: true, force: true });
    throw error;
  }
}
