import type { Pool } from "pg";
import { AppError, ERROR_IDS } from "@/constants/errorIds";

export type SnapshotTable = "activities" | "notifications" | "deals" | "persons" | "organizations";
export interface RowSnapshot {
  columns: string[];
  rows: Record<string, unknown>[];
}

export async function snapshotRows(
  pool: Pool,
  table: SnapshotTable,
  ids: string[],
  signal: AbortSignal,
  columns?: string[],
): Promise<RowSnapshot> {
  signal.throwIfAborted();
  if (columns?.some((name) => !/^[a-z][a-z0-9_]*$/.test(name)) === true)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "unexpected canonical column identifier");
  const projection = columns === undefined ? "*" : columns.map((name) => `"${name}"`).join(",");
  const result = await pool.query<Record<string, unknown>>(
    `SELECT ${projection} FROM "${table}" WHERE id=ANY($1::uuid[]) ORDER BY id`,
    [ids],
  );
  signal.throwIfAborted();
  const first = result.rows[0];
  if (first === undefined || result.rows.length !== ids.length)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "canonical snapshot row count changed");
  return { columns: columns ?? Object.keys(first), rows: result.rows };
}
