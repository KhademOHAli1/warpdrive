ALTER TABLE "calendars" ADD CONSTRAINT "calendar_source" CHECK ("calendars"."source" in ('native','provider'));--> statement-breakpoint
