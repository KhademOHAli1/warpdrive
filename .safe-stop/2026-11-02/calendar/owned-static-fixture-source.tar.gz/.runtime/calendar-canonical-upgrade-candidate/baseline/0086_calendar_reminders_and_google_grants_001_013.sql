CREATE TABLE "activity_reminder_settings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"activity_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"source" text DEFAULT 'assignment' NOT NULL,
	"use_default" boolean DEFAULT true NOT NULL,
	"rules" jsonb DEFAULT '{"timed":[{"method":"notification","minutesBefore":10},{"method":"email","minutesBefore":10}],"allDay":[{"method":"notification","daysBefore":0,"time":"09:00"},{"method":"email","daysBefore":0,"time":"09:00"}]}'::jsonb NOT NULL,
	"version" integer DEFAULT 1 NOT NULL,
	"time_zone" text NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "activity_reminder_source" CHECK ("activity_reminder_settings"."source" in ('assignment','personal'))
);
--> statement-breakpoint
