ALTER TABLE "calendars" ADD COLUMN "source" text DEFAULT 'native' NOT NULL;--> statement-breakpoint
