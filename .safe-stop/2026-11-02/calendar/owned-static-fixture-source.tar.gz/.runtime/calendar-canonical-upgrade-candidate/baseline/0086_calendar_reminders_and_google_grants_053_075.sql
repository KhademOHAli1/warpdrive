CREATE TABLE "calendar_reminder_defaults" (
	"calendar_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"rules" jsonb DEFAULT '{"timed":[{"method":"notification","minutesBefore":10},{"method":"email","minutesBefore":10}],"allDay":[{"method":"notification","daysBefore":0,"time":"09:00"},{"method":"email","daysBefore":0,"time":"09:00"}]}'::jsonb NOT NULL,
	"version" integer DEFAULT 1 NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "calendar_reminder_defaults_calendar_id_user_id_pk" PRIMARY KEY("calendar_id","user_id")
);
--> statement-breakpoint
CREATE TABLE "reminder_rebuilds" (
	"activity_id" uuid PRIMARY KEY NOT NULL,
	"touched_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "activities" ADD COLUMN "reminder_automation_enabled" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "activity_reminder_intents" ADD COLUMN "settings_id" uuid;--> statement-breakpoint
ALTER TABLE "activity_reminder_intents" ADD COLUMN "settings_version" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "activity_reminder_intents" ADD COLUMN "defaults_version" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "activity_reminder_intents" ADD COLUMN "event_signature" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "activity_reminder_intents" ADD COLUMN "in_app" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "activity_reminder_intents" ADD COLUMN "email" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "activity_reminder_settings" ADD CONSTRAINT "activity_reminder_settings_activity_id_activities_id_fk" FOREIGN KEY ("activity_id") REFERENCES "public"."activities"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "activity_reminder_settings" ADD CONSTRAINT "activity_reminder_settings_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
