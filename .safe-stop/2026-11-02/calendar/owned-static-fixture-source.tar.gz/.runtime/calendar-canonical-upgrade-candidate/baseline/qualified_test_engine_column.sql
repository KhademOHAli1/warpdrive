ALTER TABLE activities ADD COLUMN reminder_engine text
NOT NULL DEFAULT 'legacy' CHECK (reminder_engine IN ('legacy','intent'));
