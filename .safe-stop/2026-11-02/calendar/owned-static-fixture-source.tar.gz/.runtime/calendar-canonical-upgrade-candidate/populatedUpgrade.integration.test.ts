import { migrate } from "drizzle-orm/node-postgres/migrator";
import { expect, inject, it } from "vitest";
import { makeTestDb } from "@/test/db";
import { seedCanonicalLegacy } from "./legacySeed";
import { verifyMigrationLedger } from "./migrationLedger";
import { nativeCreateControl } from "./nativeCreateControl";
import { snapshotRows } from "./rowSnapshots";

it("preserves canonical legacy data without activating native reminders during the historical native upgrade", async () => {
  const signal = AbortSignal.timeout(30_000);
  const source = inject("calendarCanonicalUpgrade");
  const ctx = await makeTestDb();
  try {
    signal.throwIfAborted();
    await verifyMigrationLedger(ctx.pool, source.canonicalMigrations, signal);
    const seed = await seedCanonicalLegacy(ctx.pool, signal);
    const before = {
      activities: await snapshotRows(ctx.pool, "activities", seed.activityIds, signal),
      notifications: await snapshotRows(ctx.pool, "notifications", [seed.notificationId], signal),
      deals: await snapshotRows(ctx.pool, "deals", [seed.dealId], signal),
      persons: await snapshotRows(ctx.pool, "persons", [seed.personId], signal),
      organizations: await snapshotRows(ctx.pool, "organizations", [seed.orgId], signal),
    };
    // This must complete before any assertion can be classified as the activation RED.
    await migrate(ctx.db, { migrationsFolder: source.folder });
    signal.throwIfAborted();
    await verifyMigrationLedger(
      ctx.pool,
      [...source.canonicalMigrations, { sha256: source.baselineHash, when: source.baselineWhen }],
      signal,
    );
    expect(
      await snapshotRows(
        ctx.pool,
        "activities",
        seed.activityIds,
        signal,
        before.activities.columns,
      ),
    ).toEqual(before.activities);
    expect(
      await snapshotRows(
        ctx.pool,
        "notifications",
        [seed.notificationId],
        signal,
        before.notifications.columns,
      ),
    ).toEqual(before.notifications);
    expect(
      await snapshotRows(ctx.pool, "deals", [seed.dealId], signal, before.deals.columns),
    ).toEqual(before.deals);
    expect(
      await snapshotRows(ctx.pool, "persons", [seed.personId], signal, before.persons.columns),
    ).toEqual(before.persons);
    expect(
      await snapshotRows(
        ctx.pool,
        "organizations",
        [seed.orgId],
        signal,
        before.organizations.columns,
      ),
    ).toEqual(before.organizations);
    const additions = await ctx.pool.query<{
      id: string;
      reminder_engine: string;
      reminder_automation_enabled: boolean;
      calendar_id: string | null;
      version: number;
      reminder_authored_at: Date;
      created_at: Date;
    }>(
      `SELECT id,reminder_engine,reminder_automation_enabled,calendar_id,version,reminder_authored_at,created_at
        FROM activities WHERE id=ANY($1::uuid[]) ORDER BY id`,
      [seed.activityIds],
    );
    signal.throwIfAborted();
    expect(additions.rows).toHaveLength(2);
    for (const row of additions.rows) {
      expect(row).toMatchObject({
        reminder_engine: "legacy",
        reminder_automation_enabled: true,
        calendar_id: null,
        version: 1,
      });
      expect(row.reminder_authored_at).toEqual(row.created_at);
    }
    const settings = await ctx.pool.query<Record<string, unknown>>(
      "SELECT * FROM activity_reminder_settings WHERE activity_id=ANY($1::uuid[])",
      [seed.activityIds],
    );
    signal.throwIfAborted();
    const intents = await ctx.pool.query<Record<string, unknown>>(
      "SELECT * FROM activity_reminder_intents WHERE activity_id=ANY($1::uuid[])",
      [seed.activityIds],
    );
    signal.throwIfAborted();
    const dirty = await ctx.pool.query<Record<string, unknown>>(
      "SELECT * FROM reminder_rebuilds WHERE activity_id=ANY($1::uuid[])",
      [seed.activityIds],
    );
    signal.throwIfAborted();
    // 0085 creates a pending legacy intent. 0087 adds unwanted dirty work, not activation alone.
    expect({ settings: settings.rows, intents: intents.rows, rebuilds: dirty.rows }).toEqual({
      settings: [],
      intents: [],
      rebuilds: [],
    });
    await nativeCreateControl(ctx, seed, signal);
    signal.throwIfAborted();
    expect(
      await snapshotRows(
        ctx.pool,
        "activities",
        seed.activityIds,
        signal,
        before.activities.columns,
      ),
    ).toEqual(before.activities);
  } finally {
    await ctx.close();
  }
});
