import { defineConfig } from 'vitest/config';
import base from '../vitest.config';
const { projects, ...test } = base.test;
export default defineConfig({ ...base, test: { ...test,
 name: 'calendar-reminder-defaults-concurrency-pg', maxWorkers: 1,
 include: ['src/features/activities/reminderDefaultsConcurrency.integration.test.ts'],
 globalSetup: ['.runtime/calendar-pg.setup.mts'],
} });
