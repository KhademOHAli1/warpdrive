import { defineConfig } from 'vitest/config';
import base from '../vitest.config';
const { projects, ...test }=base.test;
export default defineConfig({...base,test:{...test,name:'calendar-google-account-import',include:['src/features/activities/providers/google/accountAuthorization.integration.test.ts','src/features/activities/providers/google/accountTokens.integration.test.ts']}});
