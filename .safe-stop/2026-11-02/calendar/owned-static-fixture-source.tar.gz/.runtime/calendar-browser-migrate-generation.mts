import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { Pool } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { env } from '../src/config/env';

const fixture = JSON.parse(readFileSync('.runtime/calendar-browser-fixture.json', 'utf8'));
const target = new URL(env.DATABASE_URL);
if (target.hostname !== '127.0.0.1' || target.port !== '54673' || target.pathname !== `/${fixture.database}`)
  throw new Error('Only the preserved isolated Calendar browser fixture is allowed');
const journal = JSON.parse(readFileSync('drizzle/meta/_journal.json', 'utf8'));
const previous = journal.entries.at(-2);
const latest = journal.entries.at(-1);
if (previous?.tag !== '0090_calendar_reminder_activation' || latest?.tag !== '0091_calendar_connection_generation')
  throw new Error('Migration history changed; review the new boundary first');
const pool = new Pool({ connectionString: env.DATABASE_URL, max: 1 });
try {
  const clients = await pool.query('SELECT count(*)::int AS count FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid()');
  if (clients.rows[0].count !== 0) throw new Error('Preserved fixture has another client; stop the application before migration');
  const history = (await pool.query('SELECT hash,created_at::text FROM drizzle.__drizzle_migrations ORDER BY created_at DESC LIMIT 1')).rows[0];
  const hash = (tag: string) => createHash('sha256').update(readFileSync(`drizzle/${tag}.sql`)).digest('hex');
  if (history?.hash !== hash(previous.tag) || history.created_at !== String(previous.when))
    throw new Error('Preserved fixture is not exactly at the reviewed 0090 boundary');
  const columns = await pool.query("SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='calendar_provider_accounts' AND column_name='connection_generation'");
  if (columns.rowCount !== 0) throw new Error('Migration already applied; preserve the original receipt');
  const providerCounts = async () => (await pool.query('SELECT (SELECT count(*)::int FROM calendar_provider_accounts) AS accounts,(SELECT count(*)::int FROM calendar_oauth_attempts) AS attempts')).rows[0];
  const beforeCounts = await providerCounts();
  if (beforeCounts.accounts !== 0 || beforeCounts.attempts !== 0)
    throw new Error('Provider data differs from the known unconfigured acceptance fixture');
  const snapshot = async () => (await pool.query("SELECT coalesce(jsonb_agg(to_jsonb(a) ORDER BY id),'[]'::jsonb) AS events FROM activities a")).rows[0].events;
  const before = await snapshot();
  await migrate(drizzle(pool), { migrationsFolder: resolve('drizzle') });
  const after = await snapshot();
  if (JSON.stringify(before) !== JSON.stringify(after)) throw new Error('Migration changed shared event fields or revisions');
  const afterCounts = await providerCounts();
  if (JSON.stringify(beforeCounts) !== JSON.stringify(afterCounts)) throw new Error('Provider counts changed');
  const migrated = (await pool.query('SELECT hash,created_at::text FROM drizzle.__drizzle_migrations ORDER BY created_at DESC LIMIT 1')).rows[0];
  if (migrated?.hash !== hash(latest.tag) || migrated.created_at !== String(latest.when))
    throw new Error('Migration receipt differs from reviewed source');
  const fields = (await pool.query("SELECT table_name,column_name,column_default,is_nullable FROM information_schema.columns WHERE table_schema='public' AND ((table_name='calendar_provider_accounts' AND column_name='connection_generation') OR (table_name='calendar_oauth_attempts' AND column_name IN ('account_connection_generation','account_connection_generations'))) ORDER BY table_name,column_name")).rows;
  if (fields.length !== 3) throw new Error('Expected generation fields missing');
  const evidence = {
    observedAt: new Date().toISOString(), migration: latest.tag, sourceHash: migrated.hash,
    fixture: fixture.database, eventCount: before.length, allSharedEventFieldsAndVersionsPreserved: true,
    providerAccounts: afterCounts.accounts, oauthAttempts: afterCounts.attempts,
    schemaFields: fields, databaseRecreated: false, applicationRunning: false,
    limits: ['Synthetic unconfigured fixture only; legacy provider rows are covered by four separate actual-history migration tests.', 'Local migration number 0091 remains an unreconciled candidate, not an accepted shared release cut.', 'No old/new binary coexistence or real provider acceptance.'],
  };
  writeFileSync('.runtime/calendar-browser-generation-migration.json', JSON.stringify(evidence, null, 2)+'\n');
  console.log(JSON.stringify(evidence, null, 2));
} finally { await pool.end(); }
