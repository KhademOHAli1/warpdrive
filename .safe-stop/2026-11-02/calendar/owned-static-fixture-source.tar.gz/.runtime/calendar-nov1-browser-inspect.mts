import {Pool} from 'pg';
import {readFileSync,writeFileSync} from 'node:fs';
const f=JSON.parse(readFileSync('.runtime/calendar-browser-fixture.json','utf8'));
const p=new Pool({host:'127.0.0.1',port:54673,user:'calendar_browser',database:f.database});
const [events,intents,notes,owners,settings]=await Promise.all([
 p.query('select id,version,subject,all_day,due_date::text AS due_date,end_date::text AS end_date,due_at,event_time_zone,done,location from activities order by created_at'),
 p.query('select id,activity_id,state,fire_at,settings_id,settings_version,defaults_version,in_app,email,notification_id,email_enqueued_at from activity_reminder_intents order by created_at'),
 p.query("select id,user_id,type,payload,created_at from notifications where type='activity_reminder' order by created_at"),
 p.query('select id,email,is_admin,is_active from users order by email'),
 p.query('select activity_id,user_id,source,use_default,rules,version,time_zone from activity_reminder_settings order by activity_id'),
]);
const result={observedAt:new Date().toISOString(),events:events.rows,intents:intents.rows,notifications:notes.rows,owners:owners.rows,settings:settings.rows};
writeFileSync('.runtime/calendar-nov1-browser-evidence.json',JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));await p.end();
