import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { PgBoss } from "pg-boss";
import { expect, it } from "vitest";
import { activityReminderIntents, notifications } from "@/db/schema";
import { dispatchReminderIntents } from "@/features/activities/reminderOutbox";
import { makeTestDb } from "@/test/db";
import { queueActivities } from "./queueFixture";

// This is the public fc5fae8 old-consumer protocol, not the eventual new queue name.
const LEGACY_ACTIVITY_QUEUE = "activity.reminder";

interface QueueJob {
  id: string;
  name: string;
  data: Record<string, unknown>;
  state: string;
  startafter: Date;
}

it("dispatches intent jobs outside the legacy activity-only queue while preserving old work", async () => {
  const signal = AbortSignal.timeout(20_000);
  const ctx = await makeTestDb();
  const boss = new PgBoss(ctx.url);
  try {
    await boss.start();
    signal.throwIfAborted();
    const fixture = await queueActivities(ctx, signal);
    expect(fixture.legacy.reminder_engine).toBe("legacy");
    expect(fixture.activity.reminderEngine).toBe("intent");
    expect(fixture.intent.state).toBe("pending");
    expect(fixture.intent.fireAt.getTime()).toBeGreaterThan(Date.now());
    await boss.createQueue(LEGACY_ACTIVITY_QUEUE);
    signal.throwIfAborted();
    const legacyJobId = randomUUID();
    await boss.send(
      LEGACY_ACTIVITY_QUEUE,
      { activityId: fixture.legacy.id },
      { id: legacyJobId, startAfter: fixture.intent.fireAt },
    );
    signal.throwIfAborted();
    const oldJobs = () =>
      ctx.pool.query<QueueJob>(
        "SELECT id, name, data, state, start_after AS startafter FROM pgboss.job WHERE id=$1",
        [legacyJobId],
      );
    const before = await oldJobs();
    expect(before.rows).toHaveLength(1);
    expect(before.rows[0]).toMatchObject({
      id: legacyJobId,
      name: LEGACY_ACTIVITY_QUEUE,
      data: { activityId: fixture.legacy.id },
    });

    expect(await dispatchReminderIntents(ctx.db, boss, signal)).toBe(1);
    signal.throwIfAborted();
    const dispatched = await ctx.pool.query<QueueJob>(
      "SELECT id, name, data, state, start_after AS startafter FROM pgboss.job WHERE id=$1",
      [fixture.intent.id],
    );
    expect(dispatched.rows).toHaveLength(1);
    expect(dispatched.rows[0]).toMatchObject({
      id: fixture.intent.id,
      data: { intentId: fixture.intent.id },
    });
    const [intent] = await ctx.db
      .select()
      .from(activityReminderIntents)
      .where(eq(activityReminderIntents.id, fixture.intent.id));
    expect(intent?.state).toBe("dispatched");
    expect((await oldJobs()).rows).toEqual(before.rows);
    expect(await ctx.db.select().from(notifications)).toHaveLength(0);
    signal.throwIfAborted();

    // Intended RED: the current outbox puts {intentId} in the old consumer's queue.
    // The eventual separate name is deliberately unconstrained by this diagnostic.
    const incompatible = await ctx.pool.query<QueueJob>(
      `SELECT id, name, data, state, start_after AS startafter FROM pgboss.job
       WHERE name=$1 AND data ? 'intentId'`,
      [LEGACY_ACTIVITY_QUEUE],
    );
    signal.throwIfAborted();
    expect(incompatible.rows).toEqual([]);
  } finally {
    try {
      await boss.stop();
    } finally {
      await ctx.close();
    }
  }
});
