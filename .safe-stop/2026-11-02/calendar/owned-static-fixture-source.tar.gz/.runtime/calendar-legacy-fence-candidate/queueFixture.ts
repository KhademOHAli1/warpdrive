import { eq } from "drizzle-orm";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { activityReminderIntents, activityTypes } from "@/db/schema";
import { seedUser } from "@/db/testing/factories";
import { createActivity } from "@/features/activities/repo";
import type { PermSetUser } from "@/features/permissions/effective";
import type { TestDb } from "@/test/db";

export async function queueActivities(ctx: TestDb, signal: AbortSignal) {
  signal.throwIfAborted();
  const user = await seedUser(ctx.db, { name: "Legacy queue boundary", isAdmin: true });
  signal.throwIfAborted();
  const actor: PermSetUser = {
    id: user.id,
    type: "admin",
    isActive: true,
    flags: new Set(),
    groupIds: new Set(),
  };
  const [type] = await ctx.db.select().from(activityTypes).where(eq(activityTypes.key, "meeting"));
  signal.throwIfAborted();
  if (type === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "queue fixture meeting type absent");
  const dueAt = new Date(Date.now() + 6 * 60 * 60_000);
  // The old writer supplies only canonical legacy columns and no engine authority.
  const legacyRows = await ctx.pool.query<{ id: string; reminder_engine: string }>(
    `INSERT INTO activities (type_id, owner_id, assignee_id, subject, due_at)
     VALUES ($1, $2, $2, $3, $4) RETURNING id, reminder_engine`,
    [type.id, user.id, "Preserved old queue job", dueAt],
  );
  signal.throwIfAborted();
  const legacy = legacyRows.rows[0];
  if (legacy === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "queue fixture legacy activity absent");
  const created = await createActivity(
    ctx.db,
    actor,
    {
      typeId: type.id,
      subject: "Native intent queue / صف یادآوری",
      dueAt: dueAt.toISOString(),
    },
    signal,
  );
  signal.throwIfAborted();
  if (!created.ok) throw created.error;
  const intents = await ctx.db
    .select()
    .from(activityReminderIntents)
    .where(eq(activityReminderIntents.activityId, created.value.id));
  signal.throwIfAborted();
  const intent = intents[0];
  if (intent === undefined || intents.length !== 1)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "queue fixture requires one real native intent");
  return { legacy, activity: created.value, intent };
}
