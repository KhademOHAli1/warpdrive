# Legacy reminder queue protocol diagnostic

Source only, 2 November 2026. One case is defined; no formatter, compiler, lint, test,
database, container, provider or worker execution has run for this packet. Existing source,
canonical migrations and other candidate packets are unchanged.

The accepted native contract requires separate legacy and intent queues while incompatible
old binaries can consume jobs. The public `fc5fae837b4b8e532a8bfd89ff303e941bcf1439`
activity-only worker registers on `activity.reminder`. The current private dispatcher sends
`{intentId}` to that same queue, and the new worker registers there while refusing
activity-only payloads. Sharing this queue exposes each payload to the wrong protocol.

The one diagnostic calls the actual native create and dispatcher APIs with real PostgreSQL
and PgBoss. It preserves a real old-style queued job with its raw legacy Activity, proves a
future native intent and one persisted dispatched job with the same intent UUID, verifies
the original old job is unchanged and no notification was fabricated, then requires zero
intent payloads in the literal old queue. The expected RED is only that final assertion.
The eventual new queue name is deliberately unconstrained. No consumer is registered or
run, and no email or external provider is used.

This case does not establish compatible legacy delivery, takeover locking, retry, timing,
historical receipt visibility, canonical migration or installed/runtime acceptance. Those
contracts remain open. In particular, there is no current compatible legacy callback or
authorized takeover API to test. A raw engine-marker update cannot substitute for them.

See the handoff's `missing-contract.md` for the minimal follow-up design and its evidence
boundary. The inherited disposable global setup uses the historical private migration
lineage plus the already qualified test-only engine column; it is not canonical 0098 SQL.

Proposed scoped commands are in the handoff. They require fresh resource checks and an
explicit one-use heavy allocation before type-aware checks or native execution. Earlier
engine11 and history22 selections are not included or repeated here.
