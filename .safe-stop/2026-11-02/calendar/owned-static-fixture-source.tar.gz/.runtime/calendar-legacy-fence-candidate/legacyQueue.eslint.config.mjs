import { fileURLToPath } from "node:url";
import { createTypeScriptImportResolver } from "eslint-import-resolver-typescript";
import base from "../../eslint.config.mjs";

const root = fileURLToPath(new URL("../../", import.meta.url));
const project = fileURLToPath(new URL("./legacyQueue.tsconfig.json", import.meta.url));

export default [
  ...base.map((config) =>
    config.ignores === undefined
      ? config
      : {
          ...config,
          ignores: config.ignores.filter((pattern) => pattern !== ".runtime/**"),
        },
  ),
  {
    files: [
      ".runtime/calendar-legacy-fence-candidate/*.ts",
      ".runtime/calendar-legacy-fence-candidate/*.mts",
    ],
    languageOptions: {
      parserOptions: { projectService: false, project, tsconfigRootDir: root },
    },
    settings: {
      "import-x/resolver-next": [createTypeScriptImportResolver({ project, alwaysTryTypes: true })],
    },
  },
];
