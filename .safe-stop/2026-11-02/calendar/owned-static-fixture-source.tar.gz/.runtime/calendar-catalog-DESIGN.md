# Local catalog and selection candidate

This is an implementation contract, not qualified source or a release cut. The full
calendar roadmap remains active. No Google app, provider account or real API call.

## Storage

- `calendars.source`: native/provider, default native. Provider calendars cannot be
  primary. Add a unique `(id, owner_id, source)` key for checked binding ownership
  and a provider-only binding source foreign key.
- `calendar_provider_catalog_states`: account_id PK/FK; latest_run_id UUID,
  requested_generation, request_expires_at, status (refreshing/ready/error),
  published_run_id/generation nullable, revision >=0 default0, sync_token nullable,
  discovered_at nullable, last_error_code nullable. Published fields become present
  together. Revision increments only on successful publication and never resets.
- `calendar_provider_calendars`: stable id UUID, account_id, user_id, exact opaque
  calendar_id, raw JSONB, connection_generation, last_seen_revision. Store generated
  calendar_id_hash as SHA256 hex using pgcrypto, unique `(account_id,calendar_id_hash)`
  and `(id,user_id)`. Do not index potentially large raw IDs. Composite FK `(account_id,user_id)`
  to checked account ownership; no unchecked owner duplication.
- `calendar_provider_bindings`: stable id UUID, user_id, provider_calendar_id (local
  catalog UUID), local_calendar_id, selected boolean, version positive default1,
  created_at/updated_at, calendar_source fixed to provider. Unique provider_calendar_id
  and local_calendar_id. Composite FKs to catalog(id,user_id) and
  calendars(id,owner_id,source), with a check fixing calendar_source to provider.

Omitted entries retain their UUID/raw history but last_seen_revision no longer matches
the published revision. Sparse deleted entries replace raw metadata completely.
Never persist access tokens or expose raw payloads/cursors through DTOs.

Hash conflicts may update only when the stored and excluded raw IDs match exactly
under deterministic C collation. Require one returned row per input entry; otherwise
raise a typed storage invariant and roll back the whole publication. This avoids both
PostgreSQL B-tree key-size failures and accidental identity replacement on a hash match.
Google does not document a Calendar-ID maximum in its resource/discovery schemas;
the event-ID 1024 limit must not be applied to calendar IDs.

## Discovery

`getCalendarAccessGrant` returns accountId and connectionGeneration from the accepted
post-refresh transaction. Begin discovery then locks owner, rechecks connected/current
generation, and installs a fresh run UUID/deadline. Provider paging is outside locks.
Publish locks owner then state, checks active/connected/generation/latestRun/deadline,
  upserts entries in 200-row chunks, and increments the published revision with cursor
and timestamp in one transaction. Late failure bookkeeping also uses the run fence.
Ordinary credential rotation does not supersede a discovery. Request deadlines are
persisted at begin with a 60-second operational lifetime, and checked before publication.

Keep last published rows/revision on failure, marked error. Those are display history,
not current permission proof. Disconnected or changed-generation reads expose no old
catalog. Inactive/foreign owners are denied before provider HTTP. A stale/failed latest
run cannot authorize a new selection. Per-entry DTO metadata remains last-known on a
failed refresh; overall status and current run/generation gate every Add. Omitted rows
are unavailable even if their retained payload once carried writer/Meet capabilities.

## Selection and native source guard

`setGoogleCalendarSelection(db,userId,{accountId,calendarId,selected,
expectedCatalogRevision,expectedBindingVersion},signal)` returns
`{bindingId,localCalendarId,version,selected}`. Strict input accepts no owner, capability
or existing local-calendar target. Add requires latest ready/current generation,
readable calendar role and valid provider zone. Free/busy-only/none/missing/deleted
sources require their later adapters. Remove requires local ownership/CAS but no
provider/config/fresh catalog. Re-Add keeps both stable IDs. Matching repeated intent
does not bump version. A stale binding CAS conflicts.

First Add creates a NEW non-primary provider-source local calendar and binding in one
transaction. Never bind or move existing personal/CRM calendars. Remove preserves the
source marker and binding tombstone. A missing active binding must not restore native
ownership privileges. Until projection/outbound adapters exist, provider calendars are
hidden from native lists and generic activity/calendar/ACL read/write paths fail closed.
Existing native and calendarId=null behavior stays unchanged.

## Next phases

Compact inline Connections discovery and immediate Add/Remove use protected DB-only
queries plus CSRF/live-session server actions. A saved selection still explicitly says
event synchronization is unavailable. Then implement idempotent event mirror/projection,
provider-aware read rights, durable outbound writes and Meet lifecycle. Recurrence,
invitations, other providers and every remaining roadmap requirement remain required.
