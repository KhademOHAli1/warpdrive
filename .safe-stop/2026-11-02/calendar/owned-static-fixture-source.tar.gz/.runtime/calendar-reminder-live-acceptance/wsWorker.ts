import { once } from "node:events";
import { drizzle } from "drizzle-orm/node-postgres";
import { Client, Pool } from "pg";
import type { WebSocketServer } from "ws";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import * as schema from "@/db/schema";
import type { Relay } from "@/server/ws/relay";
import {
  assertLiveAcceptanceConfig,
  assertLiveDatabase,
  assertMatchingLiveEnvironment,
  type LiveAcceptanceOptions,
} from "./seed";

export async function startLiveWsWorker(
  options: LiveAcceptanceOptions & { port: number },
  signal: AbortSignal,
) {
  const { database, wsPort } = assertLiveAcceptanceConfig(options);
  if (!Number.isInteger(options.port) || options.port !== wsPort)
    throw new AppError(
      ERROR_IDS.DB_INVARIANT,
      "live WS adapter requires the allocated public WS port",
    );
  await assertMatchingLiveEnvironment(options, signal);
  const connection = {
    connectionString: options.config.DATABASE_URL,
    application_name: `cal_live_ws_${options.runId}`,
    connectionTimeoutMillis: 5_000,
    query_timeout: 5_000,
    statement_timeout: 5_000,
  };
  const pool = new Pool({ ...connection, max: 2 });
  const client = new Client(connection);
  pool.on("error", () => console.warn("live WS pool error", { runId: options.runId }));
  client.on("error", () => console.warn("live WS relay error", { runId: options.runId }));
  const db = drizzle(pool, { schema });
  let server: WebSocketServer | undefined;
  let relay: Relay | undefined;
  let closing: Promise<void> | undefined;
  const close = () => {
    closing ??= (async () => {
      try {
        if (server !== undefined) {
          const ownedServer = server;
          // Only this returned server's sockets are terminated, never another listener.
          for (const socket of ownedServer.clients) socket.terminate();
          await new Promise<void>((resolve, reject) => {
            ownedServer.close((error) => (error !== undefined ? reject(error) : resolve()));
          });
        }
      } finally {
        try {
          if (relay !== undefined) await relay.close();
          else await client.end();
        } finally {
          await pool.end();
        }
      }
    })();
    return closing;
  };
  try {
    await assertLiveDatabase(db, options.runId, signal);
    await client.connect();
    signal.throwIfAborted();
    const [{ createRelay }, { startWsServer }] = await Promise.all([
      import("@/server/ws/relay"),
      import("@/server/ws/server"),
    ]);
    signal.throwIfAborted();
    relay = createRelay(client);
    server = startWsServer(options.port, { db, relay }, "127.0.0.1");
    await once(server, "listening", { signal });
    signal.throwIfAborted();
    const address = server.address();
    if (
      typeof address !== "object" ||
      address === null ||
      address.address !== "127.0.0.1" ||
      address.port !== options.port
    )
      throw new AppError(ERROR_IDS.DB_INVARIANT, "live WS listener identity mismatch");
    return { runId: options.runId, database, port: options.port, close };
  } catch {
    await close();
    signal.throwIfAborted();
    throw new AppError(ERROR_IDS.DB_INVARIANT, "live WS adapter startup failed");
  }
}
