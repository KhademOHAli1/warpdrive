import { randomUUID } from "node:crypto";
import { sql } from "drizzle-orm";
import type { Env } from "@/config/env";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { REGULAR_DEFAULT_FLAGS } from "@/constants/permissionFlags";
import type { Db } from "@/db/client";
import {
  authAccounts,
  authUsers,
  notificationPreferences,
  permissionSets,
  userPreferences,
  users,
} from "@/db/schema";
import type { DbOrTx } from "@/server/realtime/channelVersions";

export interface LiveAcceptanceOptions {
  runId: string;
  config: Env;
}

function refuse(message: string): never {
  throw new AppError(ERROR_IDS.DB_INVARIANT, message);
}

export function assertLiveAcceptanceConfig({ runId, config }: LiveAcceptanceOptions) {
  if (!/^[a-f0-9]{32}$/.test(runId))
    refuse("live acceptance run ID must be 32 lowercase hex digits");
  const database = `cal_live_${runId}`;
  if (
    ![config.DATABASE_URL, config.BASE_URL, config.WS_PUBLIC_URL].every((value) =>
      URL.canParse(value),
    )
  )
    refuse("live acceptance URLs must be explicit");
  const db = new URL(config.DATABASE_URL);
  const app = new URL(config.BASE_URL);
  const ws = new URL(config.WS_PUBLIC_URL);
  const ports = [db, app, ws].map((url) => Number(url.port));
  if (
    [db, app, ws].some(
      (url) => url.hostname !== "127.0.0.1" || url.search !== "" || url.hash !== "",
    ) ||
    ports.some((port) => !Number.isInteger(port) || port < 1024 || port > 65535) ||
    new Set(ports).size !== 3 ||
    ports.some((port) => [54672, 54673, 55432, 3104, 3116].includes(port)) ||
    !["postgres:", "postgresql:"].includes(db.protocol) ||
    db.pathname !== `/${database}` ||
    db.username === "" ||
    db.password === "" ||
    app.protocol !== "http:" ||
    app.pathname !== "/" ||
    ws.protocol !== "ws:" ||
    ws.pathname !== "/" ||
    app.username !== "" ||
    app.password !== "" ||
    ws.username !== "" ||
    ws.password !== "" ||
    config.WS_HOST !== "127.0.0.1"
  )
    refuse("live acceptance requires distinct allocated loopback resources and its exact database");
  if (
    config.NODE_ENV === "production" ||
    !config.AUTH_ALLOW_PASSWORD ||
    config.AUTH_ALLOW_PASSKEY ||
    config.AUTH_GOOGLE_ENABLED ||
    config.AUTH_MAIL_TRANSPORT !== "capture" ||
    config.AUTH_SMTP_HOST !== "" ||
    config.AUTH_SMTP_USER !== "" ||
    config.AUTH_SMTP_PASSWORD !== "" ||
    config.GOOGLE_OAUTH_CLIENT_ID !== "" ||
    config.GOOGLE_OAUTH_CLIENT_SECRET !== "" ||
    config.GOOGLE_CALENDAR_OAUTH_CLIENT_ID !== "" ||
    config.GOOGLE_CALENDAR_OAUTH_CLIENT_SECRET !== "" ||
    config.AUTH_MICROSOFT_CLIENT_ID !== "" ||
    config.AUTH_MICROSOFT_CLIENT_SECRET !== "" ||
    config.AUTH_OIDC_PROVIDERS.length !== 0 ||
    config.MCP_ENABLED ||
    config.OAUTH_REGISTRATION !== "disabled" ||
    config.ALLOW_FIRST_LOGIN_ADMIN ||
    config.SEED_ADMIN_EMAIL !== "" ||
    config.AUTH_SECRET.length < 32 ||
    config.WS_TICKET_SECRET.length < 32 ||
    !config.DISABLE_TELEMETRY ||
    !config.DISABLE_UPDATE_CHECK ||
    config.POSTHOG_KEY !== ""
  )
    refuse(
      "live acceptance requires generated local secrets and disabled external identity/services",
    );
  return { database, appPort: ports[1], wsPort: ports[2] };
}

// Runtime callers supply a clean environment before any application import, including *_FILE absence.
export async function assertMatchingLiveEnvironment(
  options: LiveAcceptanceOptions,
  signal: AbortSignal,
) {
  assertLiveAcceptanceConfig(options);
  signal.throwIfAborted();
  const { env } = await import("@/config/env");
  signal.throwIfAborted();
  assertLiveAcceptanceConfig({ runId: options.runId, config: env });
  const keys = [
    "DATABASE_URL",
    "BASE_URL",
    "WS_PUBLIC_URL",
    "WS_TICKET_SECRET",
    "AUTH_SECRET",
    "TOKEN_ENCRYPTION_KEY",
    "NODE_ENV",
  ] as const;
  if (keys.some((key) => env[key] !== options.config[key]))
    refuse("live acceptance explicit configuration differs from application configuration");
}

export async function assertLiveDatabase(db: DbOrTx, runId: string, signal: AbortSignal) {
  signal.throwIfAborted();
  const result = await db.execute<{ database: string }>(sql`SELECT current_database() AS database`);
  signal.throwIfAborted();
  if (!/^[a-f0-9]{32}$/.test(runId) || result.rows[0]?.database !== `cal_live_${runId}`)
    refuse("live acceptance database identity mismatch");
}

export async function seedLiveAcceptance(
  db: Db,
  options: LiveAcceptanceOptions & { password: string },
  signal: AbortSignal,
) {
  const { database } = assertLiveAcceptanceConfig(options);
  if (options.password.length < 24 || options.password.length > 128)
    refuse("live acceptance requires a caller-generated password of 24 to 128 characters");
  await assertLiveDatabase(db, options.runId, signal);
  await assertMatchingLiveEnvironment(options, signal);
  const { createBetterAuth } = await import("@/features/auth/better/auth");
  signal.throwIfAborted();
  try {
    const auth = createBetterAuth(db, options.config);
    const context = await auth.$context;
    signal.throwIfAborted();
    const passwordHash = await context.password.hash(options.password);
    signal.throwIfAborted();
    return await db.transaction(async (tx) => {
      await assertLiveDatabase(tx, options.runId, signal);
      await tx.execute(sql`LOCK TABLE users, auth_users, auth_accounts IN EXCLUSIVE MODE`);
      signal.throwIfAborted();
      const existing = await tx.select({ id: users.id }).from(users).limit(1);
      signal.throwIfAborted();
      if (existing.length !== 0) refuse("live acceptance seed requires no existing CRM users");
      const [permissions] = await tx
        .insert(permissionSets)
        .values({
          name: `Calendar live ${options.runId}`,
          flags: { ...REGULAR_DEFAULT_FLAGS },
          isDefault: false,
        })
        .returning({ id: permissionSets.id });
      signal.throwIfAborted();
      if (permissions === undefined) refuse("live acceptance permission seed absent");
      const userId = randomUUID();
      const email = `${options.runId}@calendar-live.invalid`;
      const name = "کاربر آزمون تقویم";
      await tx.insert(users).values({
        id: userId,
        email,
        name,
        isAdmin: false,
        isActive: true,
        permissionSetId: permissions.id,
        invitedAt: null,
      });
      signal.throwIfAborted();
      await tx.insert(authUsers).values({ id: userId, email, name, emailVerified: true });
      signal.throwIfAborted();
      await tx.insert(authAccounts).values({
        userId,
        accountId: userId,
        providerId: "credential",
        password: passwordHash,
      });
      signal.throwIfAborted();
      await tx.insert(userPreferences).values({
        userId,
        timezone: "Asia/Tehran",
        ui: {
          localePreferences: {
            locale: "fa",
            calendar: "persian",
            timeZone: "Asia/Tehran",
            numberingSystem: "arabext",
          },
        },
      });
      signal.throwIfAborted();
      await tx.insert(notificationPreferences).values({
        userId,
        type: "activity_reminder",
        inApp: true,
        email: false,
      });
      signal.throwIfAborted();
      return { runId: options.runId, database, userId, email };
    });
  } catch {
    signal.throwIfAborted();
    // Driver query errors may contain password hashes in their parameter list.
    throw new AppError(ERROR_IDS.DB_WRITE_FAILED, "live acceptance identity seed failed");
  }
}
