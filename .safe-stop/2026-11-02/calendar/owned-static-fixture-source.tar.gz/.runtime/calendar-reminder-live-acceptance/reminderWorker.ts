import { PgBoss } from "pg-boss";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import {
  assertLiveAcceptanceConfig,
  assertLiveDatabase,
  assertMatchingLiveEnvironment,
  type LiveAcceptanceOptions,
} from "./seed";

// Invoke only in a fresh dedicated process: the production registrar uses the module-global DB.
export async function startLiveReminderWorker(options: LiveAcceptanceOptions, signal: AbortSignal) {
  const { database } = assertLiveAcceptanceConfig(options);
  await assertMatchingLiveEnvironment(options, signal);
  const { getBoss, setBoss } = await import("@/jobs/boss");
  signal.throwIfAborted();
  if (getBoss() !== null)
    throw new AppError(
      ERROR_IDS.DB_INVARIANT,
      "live reminder adapter requires an empty boss singleton",
    );
  const { db, pool } = await import("@/db/client");
  pool.on("error", () =>
    console.warn("live reminder application pool error", { runId: options.runId }),
  );
  let boss: PgBoss | undefined;
  let closing: Promise<void> | undefined;
  const close = () => {
    closing ??= (async () => {
      try {
        await boss?.stop({ close: true, graceful: true, timeout: 5_000 });
      } finally {
        if (getBoss() === boss) setBoss(null);
        await pool.end();
      }
    })();
    return closing;
  };
  try {
    signal.throwIfAborted();
    await assertLiveDatabase(db, options.runId, signal);
    const ownedBoss = new PgBoss({
      connectionString: options.config.DATABASE_URL,
      application_name: `cal_live_reminder_${options.runId}`,
      max: 2,
      connectionTimeoutMillis: 5_000,
    });
    boss = ownedBoss;
    ownedBoss.on("error", () =>
      console.warn("live reminder worker database error", { runId: options.runId }),
    );
    await ownedBoss.start();
    signal.throwIfAborted();
    setBoss(ownedBoss);
    const { registerReminderWorker } = await import("@/features/activities/reminders");
    signal.throwIfAborted();
    await registerReminderWorker(ownedBoss);
    signal.throwIfAborted();
    return { runId: options.runId, database, close };
  } catch {
    await close();
    signal.throwIfAborted();
    throw new AppError(ERROR_IDS.DB_INVARIANT, "live reminder adapter startup failed");
  }
}
