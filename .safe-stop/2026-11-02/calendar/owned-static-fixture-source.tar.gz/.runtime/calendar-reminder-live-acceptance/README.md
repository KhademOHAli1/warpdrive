# Native in-app reminder live acceptance fixture, source only

Unrun preparation. These modules have no top-level startup and create no process controller,
database, PostgreSQL server, migration, browser, session or authentication token. Parent Biome
checks passed; compilation and runtime remain pending. No service launch, environment-value read
or probe occurred. The existing native integration selection is unchanged.

## Explicit caller contract

The future finite, tool-owned job must first allocate its own PostgreSQL instance/database and
distinct loopback app/WS ports, apply the selected migration lineage, and record ownership and
protected resources. Generate a fresh 32-lowercase-hex run ID. Its database must be exactly
`cal_live_<runId>` and have no CRM users. Protected ports54672,54673,55432,3104 and3116 are rejected
for every resource. Neither old `.runtime/calendar-browser.setup.mts`
nor `.runtime/calendar-reminder-worker.mts` is executed or imported.

Construct the validated `Env` explicitly from a clean OS whitelist before importing application
modules. Use package-pinned Bun with automatic env-file loading disabled (`--no-env-file`), not
private dotenv/config files or an inherited application environment. Every `*_FILE` variable
must be absent: the application's env boundary resolves those files before validation. Helpers
cannot prove absence without bypassing that existing boundary. Do not inspect/export private
environment values while constructing the job.

Required generated synthetic configuration, consistent across web, seed and both workers:

- `DATABASE_URL`: explicit postgres/postgresql URL, authenticated loopback `127.0.0.1`, allocated
  nonprivileged port, exact owned database, no URL query/fragment. Generate database credentials;
  do not put this URL in logs or command-line arguments.
- `BASE_URL=http://127.0.0.1:<allocated-app-port>` and
  `WS_PUBLIC_URL=ws://127.0.0.1:<allocated-ws-port>`, both root paths; `WS_HOST=127.0.0.1`.
  Use a fresh isolated browser context/profile; do not inherit cookies or change preferences in
  a user's existing context. Loopback cookies share a host even across different app ports.
- Independently generated `AUTH_SECRET` and `WS_TICKET_SECRET`, at least 32 characters; independently
  generated `TOKEN_ENCRYPTION_KEY`, base64 of 32 random bytes. App and WS must use the same ticket
  secret. No key, password, cookie, ticket or session token is printed or persisted by these helpers.
- `NODE_ENV=test` or `development`, never production; `AUTH_ALLOW_PASSWORD=true`,
  `AUTH_ALLOW_PASSKEY=false`, `AUTH_GOOGLE_ENABLED=false`, `AUTH_MAIL_TRANSPORT=capture`, empty
  `AUTH_SMTP_HOST`, `AUTH_SMTP_USER`, `AUTH_SMTP_PASSWORD`.
- Empty Google login/Calendar OAuth ID and secret, empty Microsoft credentials,
  `AUTH_OIDC_PROVIDERS=[]`; no provider accounts, grants, refresh tokens, watch or Meet setup.
  `MCP_ENABLED=false`, `OAUTH_REGISTRATION=disabled`, `ALLOW_FIRST_LOGIN_ADMIN=false`, empty
  `SEED_ADMIN_EMAIL`.
- `DISABLE_TELEMETRY=true`, `DISABLE_UPDATE_CHECK=true`, empty `POSTHOG_KEY`/`POSTHOG_HOST`.
  Satisfy the env schema's required MinIO values with caller-generated synthetic credentials and
  a fail-closed loopback endpoint such as port 1. This journey does not start/use object storage.
- Retain only required OS variables such as PATH, HOME, TMPDIR, LANG/LC_ALL, TERM and TZ. No external
  service credentials or inherited application settings. The caller owns redaction of failures.

## Functions and owned shutdown

`seedLiveAcceptance(db, {runId, config, password}, signal)` takes an already-connected owned `Db`.
The caller generates the future password (24 to 128 characters), retains it privately for actual
password login, and never logs it. The helper checks `current_database()`, takes an exclusive
identity-table lock and rejects a nonempty CRM user table. It hashes through the actual
`createBetterAuth(...).$context.password.hash` before opening the transaction, then creates a regular CRM user with its
own `REGULAR_DEFAULT_FLAGS` permission set, matching verified auth user and credential account,
FA/Persian/Asia-Tehran preferences, and notification preference in-app on/email off. It does not
overwrite/upsert an identity or manufacture a login session. It checks AbortSignal across I/O and
hash steps; the password hash itself has no cancellation API. The caller closes its seed pool.

`startLiveReminderWorker({runId, config}, signal)` requires a fresh dedicated process because the
production `registerReminderWorker(boss)` API uses the application's global DB. It checks exact
typed ambient/explicit DB and auth/WS values before importing that DB, verifies the owned database,
starts only its PgBoss instance, and calls only the production reminder registrar. No full worker
or older email worker is registered. Its idempotent `close()` stops its own boss, clears only its
own singleton and ends the exported application pool. A shared long-lived process is unsupported.

`startLiveWsWorker({runId, config, port}, signal)` requires the allocated explicit WS port matching
`WS_PUBLIC_URL`; there is no 8080 default. It owns its injected DB pool, dedicated LISTEN client,
real relay and `startWsServer` listener on `127.0.0.1`. `close()` terminates only sockets belonging
to that returned server, closes it, then ends its relay client and pool. Server/socket teardown is
the existing production behavior; it exposes no awaited per-session teardown API. Relay shutdown
can therefore race best-effort UNLISTEN cleanup, without authorizing cleanup of another resource.

The finite session caller must invoke these exported functions and retain handles. It must put
both `close()` calls and its app/browser/seed/database teardown in `finally`, including signal/error
paths. Startup errors attempt owned cleanup. AbortSignal covers startup checks, not a permanent
worker lifetime. Installed PgBoss supports a 5-second graceful stop request, but pool shutdown and
engine I/O have no overall deadline guarantee. Normal finite tool sessions own termination,
terminal cleanup verification and disposal of only their database/instance. No supervisor,
background launcher, periodic test driver or generic cleanup controller is supplied.

## Acceptance still outstanding

Biome formatting/lint passed for these three source fixtures. They remain uncompiled and unrun,
with no live worker or browser evidence.
The future journey must really password-login, schedule/edit with notification-only personal rules,
observe the saved native event and owner notification feed, and record delivery/retry behavior.
The real registrar performs one startup outbox send and schedules its existing minute sweep;
this preparation proves neither startup dispatch nor a periodic sweep fired. Do not manually
invoke the handler or dispatch and call that live scheduling acceptance. Verify separate real
wall-clock/worker/WS/browser observations and cleanup. Email, Google/provider, watch and Meet
acceptance remain excluded. No application API change has been made or assumed.
