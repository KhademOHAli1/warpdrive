import { Pool } from 'pg';
import { readFileSync } from 'node:fs';
const fixture=JSON.parse(readFileSync('.runtime/calendar-browser-fixture.json','utf8'));
const pool=new Pool({host:'127.0.0.1',port:54673,user:'calendar_browser',database:fixture.database});
const activities=await pool.query(`select id, subject, version, location, due_at, end_at, event_time_zone, calendar_id, all_day, done from activities where id=$1 or subject=$2 order by created_at`,['3ee802b0-d564-46e3-b608-e0ac1f6567a9','آزمون تحویل یادآوری ۳۱ اکتبر']);
const reminders=await pool.query(`select i.id,i.activity_id,i.state,i.due_at,i.fire_at,i.notification_id,i.email_enqueued_at from activity_reminder_intents i join activities a on a.id=i.activity_id where a.subject=$1`,['آزمون تحویل یادآوری ۳۱ اکتبر']);
const notes=await pool.query(`select n.id,n.type,n.payload->>'activityId' as activity_id,n.payload->>'subject' as subject from notifications n where n.payload->>'subject'=$1`,['آزمون تحویل یادآوری ۳۱ اکتبر']);
console.log(JSON.stringify({activities:activities.rows,reminders:reminders.rows,notifications:notes.rows},null,2));
await pool.end();
