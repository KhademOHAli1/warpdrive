import { defineConfig } from 'vitest/config';
import base from '../vitest.config';
const { projects, ...test } = base.test;
export default defineConfig({ ...base, test: { ...test,
  name: 'calendar-pg', maxWorkers: 2,
  include: ['src/features/activities/calendarLeadBoundary.integration.test.ts','src/features/activities/reminderOutboxRecovery.integration.test.ts','src/features/activities/reminderOutbox.integration.test.ts','src/features/notifications/reminderEmailLifecycle.integration.test.ts','src/features/notifications/calendarPrivacy.integration.test.ts','src/features/activities/availability.test.ts','src/features/activities/calendarReminderDelivery.integration.test.ts','src/features/activities/calendars.integration.test.ts','src/features/activities/calendarConcurrency.integration.test.ts','src/features/activities/calendarEventRoundTrip.integration.test.ts', 'src/features/activities/getForEdit.test.ts', 'src/features/activities/getForEdit.links.test.ts', 'src/features/activities/activityAllDay.integration.test.ts'],
  globalSetup: ['.runtime/calendar-pg.setup.mts'],
} });
