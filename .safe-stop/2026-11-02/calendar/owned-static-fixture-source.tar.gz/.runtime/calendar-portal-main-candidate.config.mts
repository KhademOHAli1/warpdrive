import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";
import base from "../vitest.config";

// The packet is outside the repository. Resolve its bare imports from this pinned dependency tree.
const require = createRequire(import.meta.url);
// These packages expose different import/require entry points. Keep Vitest on their ESM entries.
const importEntries: Record<string, string> = {
  vitest: join(dirname(require.resolve("vitest/package.json")), "dist/index.js"),
  "@testing-library/jest-dom/vitest": join(
    dirname(require.resolve("@testing-library/jest-dom/package.json")),
    "dist/vitest.mjs",
  ),
};
const packages = [
  "react", "react/jsx-runtime", "react/jsx-dev-runtime", "react-dom", "react-dom/client",
  "@testing-library/react", "@testing-library/jest-dom/vitest", "vitest", "lucide-react",
  "next/link", "next/navigation", "next/dynamic",
];
const packageAliases = packages.map((name) => ({
  find: new RegExp(`^${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`),
  replacement: importEntries[name] ?? require.resolve(name),
}));

export default defineConfig({
  ...base,
  envDir: false,
  server: {
    fs: { allow: [fileURLToPath(new URL("..", import.meta.url)), "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01"] },
  },
  resolve: {
    dedupe: ["react", "react-dom"],
    alias: [
      ...packageAliases,
    { find: "@/features/activities/agendaLayout", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/agendaLayout.ts" },
    { find: "@/features/activities/agendaScroll", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/agendaScroll.ts" },
    { find: "@/features/activities/calendarActivityTarget", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/calendarActivityTarget.ts" },
    { find: "@/features/activities/followUpAfterDone", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/followUpAfterDone.tsx" },
    { find: "@/features/activities/followUpLinks", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/followUpLinks.ts" },
    { find: "@/features/activities/useLocalNow", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/useLocalNow.ts" },
    { find: "@/features/activities/weekAgenda", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/weekAgenda.ts" },
    { find: "@/features/activities/activityTemporal", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/activityTemporal.ts" },
    { find: "@/features/activities/calendarSystem", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/calendarSystem.ts" },
    { find: "@/features/activities/calendarView", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/calendarView.ts" },
    { find: "@/features/activities/monthGrid", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/monthGrid.ts" },
    { find: "@/features/activities/FollowUpActivityDialog", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/FollowUpActivityDialog.tsx" },
    { find: "@/features/activities/calendar", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/calendar.ts" },
    { find: "@/features/activities/calendarMessages", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/calendarMessages.ts" },
      { find: "@/features/activities/activityRowTarget", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/activityRowTarget.ts" },
      { find: "@/features/activities/dayHeading", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/dayHeading.ts" },
      { find: "@/features/activities/weekGrid", replacement: "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/features/activities/weekGrid.ts" },
      { find: "@", replacement: fileURLToPath(new URL("../src", import.meta.url)) },
    ],
  },
  test: {
    ...base.test,
    maxWorkers: 1,
    fileParallelism: false,
    testTimeout: 10_000,
    hookTimeout: 10_000,
    env: {
      NODE_ENV: "test",
      DATABASE_URL: "postgres://synthetic:synthetic@127.0.0.1:1/calendar_global_unused",
      BASE_URL: "https://calendar-test.example.invalid",
      GOOGLE_CALENDAR_OAUTH_CLIENT_ID: "",
      GOOGLE_CALENDAR_OAUTH_CLIENT_SECRET: "",
      AUTH_MAIL_TRANSPORT: "capture",
      AUTH_SMTP_HOST: "",
    },
    projects: [{
      extends: true,
      test: {
        name: "unit",
        include: [
          "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/app/(app)/activities/calendar/CalendarPortalShortcut.test.tsx",
          "/Users/ali/Documents/Codex/2026-10-31/warpdrive-calendar-continuation/outputs/Calendar_Portal_C_Main_Increment_2026-11-01/candidate/src/app/(app)/activities/calendar/CalendarNavigation.test.tsx",
        ],
      },
    }],
  },
});
