import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { Pool } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { env } from '../src/config/env';
const fixture = JSON.parse(readFileSync('.runtime/calendar-browser-fixture.json', 'utf8'));
const target = new URL(env.DATABASE_URL);
if (target.hostname !== '127.0.0.1' || target.port !== '54673' || target.pathname !== `/${fixture.database}`)
  throw new Error('Only the preserved isolated Calendar browser fixture is allowed');
const pool = new Pool({ connectionString: env.DATABASE_URL, max: 2 });
try {
  const columns = await pool.query("SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='activities' AND column_name='reminder_authored_at'");
  if (columns.rowCount !== 0) throw new Error('Migration already applied; preserve the original before/after receipt');
  const snapshot = async (after = false) => (await pool.query(`SELECT coalesce(jsonb_agg(${after ? "to_jsonb(a)-'reminder_authored_at'" : 'to_jsonb(a)'} ORDER BY id),'[]'::jsonb) AS events FROM activities a`)).rows[0].events;
  const before = await snapshot();
  await migrate(drizzle(pool), { migrationsFolder: resolve('drizzle') });
  const after = await snapshot(true);
  if (JSON.stringify(before) !== JSON.stringify(after)) throw new Error('Migration changed shared event fields or revisions');
  const authored = (await pool.query('SELECT id,version,reminder_authored_at=created_at AS backfilled_from_creation FROM activities ORDER BY id')).rows;
  if (!authored.every((row: {backfilled_from_creation:boolean}) => row.backfilled_from_creation)) throw new Error('Authorship backfill differs from original creation time');
  const evidence = { observedAt: new Date().toISOString(), migration: '0090_calendar_reminder_activation', fixture: fixture.database, eventCount: before.length, allSharedFieldsAndVersionsPreserved: true, authored, databaseRecreated: false };
  writeFileSync('.runtime/calendar-browser-activation-migration.json', JSON.stringify(evidence, null, 2)+'\n');
  console.log(JSON.stringify({migration:evidence.migration,eventCount:before.length,allSharedFieldsAndVersionsPreserved:true,databaseRecreated:false}));
} finally { await pool.end(); }
