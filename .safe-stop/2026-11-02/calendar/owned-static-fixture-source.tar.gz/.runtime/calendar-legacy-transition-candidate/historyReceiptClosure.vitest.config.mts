import { defineConfig } from "vitest/config";
import base from "../../vitest.config";

const baseTest = base.test ?? {};
const setupFiles =
  typeof baseTest.setupFiles === "string" ? [baseTest.setupFiles] : (baseTest.setupFiles ?? []);

export default defineConfig({
  ...base,
  envDir: false,
  test: {
    ...baseTest,
    setupFiles: [
      ...setupFiles,
      ".runtime/calendar-existing-edit-atomicity-draft/existingEditAtomicity.setup.ts",
    ],
    env: {
      NODE_ENV: "test",
      DATABASE_URL: "postgres://synthetic:synthetic@127.0.0.1:1/calendar_global_unused",
      BASE_URL: "https://calendar-test.example.invalid",
      GOOGLE_CALENDAR_OAUTH_CLIENT_ID: "",
      GOOGLE_CALENDAR_OAUTH_CLIENT_SECRET: "",
      AUTH_MAIL_TRANSPORT: "capture",
      AUTH_SMTP_HOST: "",
    },
    maxWorkers: 1,
    fileParallelism: false,
    testNamePattern:
      /^(?:retains authentic legacy inbox history across engine and automation changes while rechecking current access|resolves a no-ID delivered receipt by its notification backlink and respects email-off|resolves a no-ID personal reader receipt without requiring assignment|a cancelled no-ID backlink fails closed without legacy fallback|a ambiguous no-ID backlink fails closed without legacy fallback|a recipientMismatch no-ID backlink fails closed without legacy fallback|a dueMismatch no-ID backlink fails closed without legacy fallback|a activityMismatch no-ID backlink fails closed without legacy fallback|a malformedActivity no-ID backlink fails closed without legacy fallback|unlinked notice cannot bypass own none policy before rebuild|unlinked notice cannot bypass own notificationOnly policy before rebuild|unlinked notice cannot bypass own calendarDefault policy before rebuild|unlinked notice cannot bypass own malformed policy before rebuild|retains an eligible unlinked legacy notice without an own policy, ignoring other users' choices|a provided null activity reference cannot inherit a valid entity reference|keeps unlinked all-day inbox history but refuses email when its original civil date is unprovable|rechecks calendar access after revocation for feed and unread count|drops a queued email after calendar membership revocation|retains legacy activity and ungated system notifications|denies a stale or forged automationDisabled reminder receipt in both channels|denies a stale or forged malformedReceipt reminder receipt in both channels|denies a stale or forged missingReceipt reminder receipt in both channels)$/,
    projects: [
      {
        extends: true,
        test: {
          name: "integration",
          include: [
            ".runtime/calendar-legacy-transition-candidate/legacyReceiptVisibility.integration.test.ts",
            "src/features/notifications/legacyReminderPolicy.integration.test.ts",
            "src/features/notifications/calendarPrivacy.integration.test.ts",
            "src/features/notifications/reminderChannels.integration.test.ts",
          ],
          globalSetup: [
            ".runtime/calendar-existing-edit-atomicity-draft/existingEditAtomicity.globalSetup.ts",
          ],
        },
      },
    ],
  },
});
