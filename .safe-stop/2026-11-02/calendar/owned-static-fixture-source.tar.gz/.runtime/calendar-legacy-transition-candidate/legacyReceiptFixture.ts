import { eq } from "drizzle-orm";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import { activities, activityTypes, calendarMembers, calendars, deals } from "@/db/schema";
import { seedPipelineWithStages, seedUser } from "@/db/testing/factories";
import { getFeed, getUnreadCount } from "@/features/notifications/feed";
import { setPreference } from "@/features/notifications/preferences";
import { createNotification } from "@/features/notifications/produce";
import type { AuthUser } from "@/features/permissions/types";
import type { TestDb } from "@/test/db";

export async function legacyReceiptFixture(ctx: TestDb, signal: AbortSignal) {
  signal.throwIfAborted();
  const owner = await seedUser(ctx.db, { name: "Legacy calendar owner" });
  signal.throwIfAborted();
  const recipient = await seedUser(ctx.db, { name: "Legacy receipt recipient" });
  signal.throwIfAborted();
  const { pipeline, stages } = await seedPipelineWithStages(ctx.db, ["Open"]);
  signal.throwIfAborted();
  const stage = stages[0];
  if (stage === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "legacy receipt stage absent");
  const [deal] = await ctx.db
    .insert(deals)
    .values({
      title: "Legacy receipt parent",
      pipelineId: pipeline.id,
      stageId: stage.id,
      ownerId: recipient.id,
      visibilityLevel: "owner",
    })
    .returning();
  signal.throwIfAborted();
  const [calendar] = await ctx.db
    .insert(calendars)
    .values({ ownerId: owner.id, name: "Legacy receipt calendar", timeZone: "Asia/Tehran" })
    .returning();
  signal.throwIfAborted();
  const [type] = await ctx.db.select().from(activityTypes).where(eq(activityTypes.key, "meeting"));
  signal.throwIfAborted();
  if (deal === undefined || calendar === undefined || type === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "legacy receipt parents absent");
  await ctx.db.insert(calendarMembers).values({
    calendarId: calendar.id,
    userId: recipient.id,
    role: "reader",
  });
  signal.throwIfAborted();
  const dueAt = new Date("2026-01-15T09:00:00Z");
  // A raw old writer has no engine choice, personal policy, intent or modern backlink.
  const [activity] = await ctx.db
    .insert(activities)
    .values({
      typeId: type.id,
      ownerId: owner.id,
      assigneeId: recipient.id,
      calendarId: calendar.id,
      dealId: deal.id,
      subject: "Authentic pre-policy reminder",
      dueAt,
      allDay: false,
    })
    .returning();
  signal.throwIfAborted();
  if (activity === undefined)
    throw new AppError(ERROR_IDS.DB_INVARIANT, "legacy receipt activity absent");
  await setPreference(
    ctx.db,
    recipient.id,
    "activity_reminder",
    { inApp: true, email: false },
    signal,
  );
  signal.throwIfAborted();
  const produced = await createNotification(
    ctx.db,
    {
      recipientId: recipient.id,
      type: "activity_reminder",
      actorId: null,
      entityType: "deal",
      entityId: deal.id,
      payload: { activityId: activity.id, subject: activity.subject, dueAt: dueAt.toISOString() },
    },
    signal,
  );
  signal.throwIfAborted();
  if (!produced.ok) throw produced.error;
  if (!("notificationId" in produced.value))
    throw new AppError(ERROR_IDS.DB_INVARIANT, "authorized legacy receipt suppressed");
  const actor: AuthUser = {
    id: recipient.id,
    type: "regular",
    isActive: true,
    groupIds: new Set(),
  };
  return {
    owner,
    recipient,
    deal,
    calendar,
    activity,
    actor,
    notificationId: produced.value.notificationId,
  };
}

export async function inbox(ctx: TestDb, actor: AuthUser, signal: AbortSignal) {
  signal.throwIfAborted();
  const [feed, unread] = await Promise.all([
    getFeed(ctx.db, actor, 20, signal),
    getUnreadCount(ctx.db, actor, signal),
  ]);
  signal.throwIfAborted();
  return { ids: feed.map((row) => row.id), unread };
}
