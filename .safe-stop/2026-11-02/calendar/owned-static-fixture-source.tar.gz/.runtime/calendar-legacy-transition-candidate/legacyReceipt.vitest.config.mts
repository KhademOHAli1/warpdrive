import { defineConfig } from "vitest/config";
import base from "../../vitest.config";

const baseTest = base.test ?? {};
const setupFiles =
  typeof baseTest.setupFiles === "string" ? [baseTest.setupFiles] : (baseTest.setupFiles ?? []);

export default defineConfig({
  ...base,
  envDir: false,
  test: {
    ...baseTest,
    setupFiles: [
      ...setupFiles,
      ".runtime/calendar-existing-edit-atomicity-draft/existingEditAtomicity.setup.ts",
    ],
    env: {
      NODE_ENV: "test",
      DATABASE_URL: "postgres://synthetic:synthetic@127.0.0.1:1/calendar_global_unused",
      BASE_URL: "https://calendar-test.example.invalid",
      GOOGLE_CALENDAR_OAUTH_CLIENT_ID: "",
      GOOGLE_CALENDAR_OAUTH_CLIENT_SECRET: "",
      AUTH_MAIL_TRANSPORT: "capture",
      AUTH_SMTP_HOST: "",
    },
    maxWorkers: 1,
    fileParallelism: false,
    projects: [
      {
        extends: true,
        test: {
          name: "integration",
          include: [
            ".runtime/calendar-legacy-transition-candidate/legacyReceiptVisibility.integration.test.ts",
          ],
          globalSetup: [
            ".runtime/calendar-existing-edit-atomicity-draft/existingEditAtomicity.globalSetup.ts",
          ],
        },
      },
    ],
  },
});
