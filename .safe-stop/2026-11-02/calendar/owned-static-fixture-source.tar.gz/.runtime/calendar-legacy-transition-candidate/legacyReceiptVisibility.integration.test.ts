import { and, eq } from "drizzle-orm";
import { expect, it } from "vitest";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import {
  activities,
  activityReminderIntents,
  activityReminderSettings,
  calendarMembers,
  calendarReminderDefaults,
  deals,
  notifications,
} from "@/db/schema";
import { canDeliverActivityReminder } from "@/features/notifications/calendarPrivacy";
import { makeTestDb } from "@/test/db";
import { inbox, legacyReceiptFixture } from "./legacyReceiptFixture";

it("retains authentic legacy inbox history across engine and automation changes while rechecking current access", async () => {
  const signal = AbortSignal.timeout(10_000);
  signal.throwIfAborted();
  const ctx = await makeTestDb();
  try {
    signal.throwIfAborted();
    const f = await legacyReceiptFixture(ctx, signal);
    signal.throwIfAborted();
    expect(f.activity.reminderEngine).toBe("legacy");
    expect(f.activity.reminderAutomationEnabled).toBe(true);
    const receipt = await ctx.db
      .select()
      .from(notifications)
      .where(eq(notifications.id, f.notificationId));
    signal.throwIfAborted();
    expect(receipt).toMatchObject([
      { id: f.notificationId, userId: f.recipient.id, readAt: null, entityId: f.deal.id },
    ]);
    expect(receipt[0]?.payload).not.toHaveProperty("reminderIntentId");
    const original = receipt[0];
    if (original === undefined) throw new AppError(ERROR_IDS.DB_INVARIANT, "legacy receipt absent");
    const visible = { ids: [f.notificationId], unread: 1 };
    const hidden = { ids: [], unread: 0 };
    expect(await inbox(ctx, f.actor, signal)).toEqual(visible);
    expect(await canDeliverActivityReminder(ctx.db, f.recipient.id, original, signal)).toBe(true);
    signal.throwIfAborted();

    // Both current access gates must still apply to authentic historical receipts.
    await ctx.db.update(deals).set({ ownerId: f.owner.id }).where(eq(deals.id, f.deal.id));
    signal.throwIfAborted();
    expect(await inbox(ctx, f.actor, signal)).toEqual(hidden);
    await ctx.db.update(deals).set({ ownerId: f.recipient.id }).where(eq(deals.id, f.deal.id));
    signal.throwIfAborted();
    expect(await inbox(ctx, f.actor, signal)).toEqual(visible);
    await ctx.db
      .delete(calendarMembers)
      .where(
        and(
          eq(calendarMembers.calendarId, f.calendar.id),
          eq(calendarMembers.userId, f.recipient.id),
        ),
      );
    signal.throwIfAborted();
    expect(await inbox(ctx, f.actor, signal)).toEqual(hidden);
    await ctx.db.insert(calendarMembers).values({
      calendarId: f.calendar.id,
      userId: f.recipient.id,
      role: "reader",
    });
    signal.throwIfAborted();
    expect(await inbox(ctx, f.actor, signal)).toEqual(visible);

    // This is a read-compatibility control, not proof of an atomic worker takeover.
    await ctx.db
      .update(activities)
      .set({ reminderEngine: "intent" })
      .where(eq(activities.id, f.activity.id));
    signal.throwIfAborted();
    expect(await inbox(ctx, f.actor, signal)).toEqual(visible);
    await ctx.db
      .update(activities)
      .set({ reminderAutomationEnabled: false })
      .where(eq(activities.id, f.activity.id));
    signal.throwIfAborted();
    const [current, settings, intents, defaults, stored] = await Promise.all([
      ctx.db.select().from(activities).where(eq(activities.id, f.activity.id)),
      ctx.db
        .select()
        .from(activityReminderSettings)
        .where(eq(activityReminderSettings.activityId, f.activity.id)),
      ctx.db
        .select()
        .from(activityReminderIntents)
        .where(eq(activityReminderIntents.activityId, f.activity.id)),
      ctx.db
        .select()
        .from(calendarReminderDefaults)
        .where(
          and(
            eq(calendarReminderDefaults.calendarId, f.calendar.id),
            eq(calendarReminderDefaults.userId, f.recipient.id),
          ),
        ),
      ctx.db.select().from(notifications).where(eq(notifications.id, f.notificationId)),
    ]);
    signal.throwIfAborted();
    expect(current).toMatchObject([
      {
        id: f.activity.id,
        reminderEngine: "intent",
        reminderAutomationEnabled: false,
        assigneeId: f.recipient.id,
        calendarId: f.calendar.id,
        dealId: f.deal.id,
        dueAt: f.activity.dueAt,
      },
    ]);
    expect({ settings, intents, defaults }).toEqual({ settings: [], intents: [], defaults: [] });
    expect(stored).toEqual(receipt);

    // Expected RED: the automation guard currently hides both feed and unread history.
    expect(await inbox(ctx, f.actor, signal)).toEqual(visible);
    // Restore legacy ownership so email refusal cannot be explained by an engine transition.
    await ctx.db
      .update(activities)
      .set({ reminderEngine: "legacy" })
      .where(eq(activities.id, f.activity.id));
    signal.throwIfAborted();
    expect(await inbox(ctx, f.actor, signal)).toEqual(visible);
    expect(await canDeliverActivityReminder(ctx.db, f.recipient.id, original, signal)).toBe(false);
    signal.throwIfAborted();
  } finally {
    await ctx.close();
  }
});
