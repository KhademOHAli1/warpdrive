import { and, eq, isNull } from "drizzle-orm";
import type { z } from "zod";
import { AppError, ERROR_IDS } from "@/constants/errorIds";
import type { Db } from "@/db/client";
import {
  type Activity,
  activities,
  activityGuests,
  activityParticipants,
  activityTypes,
  deals,
} from "@/db/schema";
import { sanitizeAuthorHtml } from "@/features/email/sanitizeHtml";
import type { PermSetUser } from "@/features/permissions/effective";
import { assertReferenceVisible } from "@/features/permissions/referenceCheck";
import type { DbOrTx } from "@/server/realtime/channelVersions";
import { err, ok, type Result } from "@/types/result";
import { activityAccountPreferences } from "./accountTimeZone";
import { guardActivityMutation } from "./activityAccessGuard";
import { applyActivityReminders } from "./activityReminderWrite";
import { canonicalUpdateDates, civilEndBeforeStart } from "./activityTemporalWrite";
import { activityTransaction } from "./activityTransaction";
import { assertCalendarWritable } from "./calendars";
import { recomputeDealsActivityDates } from "./nextActivity";
import { type ActivityUpdateInput, activityUpdateInput } from "./schemas";

type ParsedUpdate = z.infer<typeof activityUpdateInput>;

// Mirror of repo.ts's toVisibilitySession: builds a DealVisibilitySession from a
// PermSetUser so assertReferenceVisible can gate the assigneeId reference.
function toVisibilitySession(actor: PermSetUser) {
  return {
    userId: actor.id,
    isActive: actor.isActive,
    sessionLive: true,
    isAdmin: actor.type === "admin",
    visibilityGroupIds: Array.from(actor.groupIds),
    managedUserIds: Array.from(actor.managedUserIds ?? []),
  };
}

// A patched typeId must reference an existing, non-archived activity type. Archived types
// stay valid on rows that already reference them, but must not be assignable going forward.
async function assertTypeActive(
  tx: DbOrTx,
  typeId: string,
  signal: AbortSignal,
): Promise<Result<undefined, AppError>> {
  const [row] = await tx
    .select({ archivedAt: activityTypes.archivedAt })
    .from(activityTypes)
    .where(eq(activityTypes.id, typeId));
  signal.throwIfAborted();
  if (row === undefined || row.archivedAt !== null) {
    return err(
      new AppError(ERROR_IDS.ACTIVITY_TYPE_INVALID, "activity type not found or archived", {
        typeId,
      }),
    );
  }
  return ok(undefined);
}

// Only include columns the patch actually provided (activityUpdateInput.refine already requires
// at least one), so an omitted field never clobbers existing data with an implicit null write.
// Re-sanitizes note through the same helper createActivity uses (sanitizeAuthorHtml).
// Columns copied verbatim when their key is present (Zod already validated the values).
const PASS_THROUGH_KEYS = [
  "subject",
  "eventTimeZone",
  "calendarId",
  "eventVisibility",
  "availability",
  "typeId",
  "priority",
  "durationMinutes",
  "location",
  "assigneeId",
  "videoCallUrl",
  "dealId",
  "personId",
  "orgId",
] as const;

function buildPatch(input: ParsedUpdate): Partial<typeof activities.$inferInsert> {
  const patch: Partial<typeof activities.$inferInsert> = {};
  const sink = patch as Record<string, unknown>;
  for (const key of PASS_THROUGH_KEYS) {
    if (input[key] !== undefined) sink[key] = input[key];
  }
  // Transformed columns: dates are coerced and the note is re-sanitized (same helper as create).
  if (input.dueAt !== undefined) {
    patch.dueAt = input.dueAt === null ? null : new Date(input.dueAt);
    // Clearing the date clears the claim with it; otherwise the flag follows what was sent,
    // so removing a time on an existing activity actually removes it.
    patch.allDay = input.dueAt !== null && (input.allDay ?? false);
  } else if (input.allDay !== undefined) {
    patch.allDay = input.allDay;
  }
  if (input.endAt !== undefined) patch.endAt = input.endAt === null ? null : new Date(input.endAt);
  if (input.note !== undefined) {
    patch.note = input.note === null ? null : sanitizeAuthorHtml(input.note);
  }
  return patch;
}

type RefKind = "deal" | "person" | "organization" | "user";

// Every entity a patch may newly reference, so assertPatchRefsVisible gates them in one loop
// (mirrors createActivity's collectReferences). Guest/participant sets and the deal/person/org
// re-links are included; a null link clears the field and needs no visibility check.
function patchReferences(input: ParsedUpdate): Array<{ kind: RefKind; id: string }> {
  const refs: Array<{ kind: RefKind; id: string }> = [];
  const singles: Array<[RefKind, string | null | undefined]> = [
    ["deal", input.dealId],
    ["person", input.personId],
    ["organization", input.orgId],
    ["user", input.assigneeId],
  ];
  for (const [kind, id] of singles) {
    if (id !== null && id !== undefined) refs.push({ kind, id });
  }
  for (const gid of input.guestPersonIds ?? []) refs.push({ kind: "person", id: gid });
  for (const uid of input.participantUserIds ?? []) refs.push({ kind: "user", id: uid });
  return refs;
}

// Validate every entity a patch references is visible to the actor, mirroring createActivity's gate.
async function assertPatchRefsVisible(
  tx: DbOrTx,
  actor: PermSetUser,
  input: ParsedUpdate,
  signal: AbortSignal,
): Promise<Result<undefined, AppError>> {
  if (input.typeId !== undefined) {
    const typeCheck = await assertTypeActive(tx, input.typeId, signal);
    if (!typeCheck.ok) return typeCheck;
  }
  const refActor = toVisibilitySession(actor);
  for (const ref of patchReferences(input)) {
    const refCheck = await assertReferenceVisible(tx, refActor, ref, signal);
    if (!refCheck.ok) return refCheck;
  }
  return ok(undefined);
}

// Multi-day guard for edits: the effective end (patched or current) must not precede the
// effective start (patched or current). No-op when either resolved bound is null.
function assertUpdateEndOrder(current: Activity, input: ParsedUpdate): Result<undefined, AppError> {
  const start = input.dueAt !== undefined ? toDate(input.dueAt) : current.dueAt;
  const end = input.endAt !== undefined ? toDate(input.endAt) : current.endAt;
  if (start === null || end === null) return ok(undefined);
  if (end.getTime() < start.getTime()) {
    return err(
      new AppError(ERROR_IDS.ACTIVITY_END_BEFORE_START, "activity end is before its start", {
        id: current.id,
      }),
    );
  }
  return ok(undefined);
}

function toDate(iso: string | null): Date | null {
  return iso === null ? null : new Date(iso);
}

export async function updateActivity(
  db: Db,
  actor: PermSetUser,
  raw: ActivityUpdateInput,
  signal: AbortSignal,
): Promise<Result<Activity, AppError>> {
  const parsed = activityUpdateInput.safeParse(raw);
  if (!parsed.success) {
    return err(
      new AppError(ERROR_IDS.ACTIVITY_UPDATE_INPUT_INVALID, "activity update input invalid", {
        issues: parsed.error.issues,
      }),
    );
  }
  const input = parsed.data;

  const prefs = await activityAccountPreferences(db, actor.id);
  return activityTransaction(db, async (tx) => {
    const [current] = await tx
      .select()
      .from(activities)
      .where(and(eq(activities.id, input.id), isNull(activities.deletedAt)))
      .for("no key update");

    if (current === undefined) {
      return err(
        new AppError(ERROR_IDS.ACTIVITY_NOT_FOUND, "activity not found", { id: input.id }),
      );
    }

    const allowed = await guardActivityMutation(
      tx,
      actor,
      current,
      "activity.edit",
      signal,
      input.expectedVersion,
    );
    if (!allowed.ok) return allowed;
    if (input.calendarId !== undefined && input.calendarId !== current.calendarId) {
      const target = await assertCalendarWritable(tx, actor, input.calendarId, signal);
      if (!target.ok) return target;
    }
    const refsOk = await assertPatchRefsVisible(tx, actor, input, signal);
    if (!refsOk.ok) return refsOk;

    const orderOk = assertUpdateEndOrder(current, input);
    if (!orderOk.ok) return orderOk;

    const archivedOk = await assertRelinkDealNotArchived(tx, current, input, signal);
    if (!archivedOk.ok) return archivedOk;

    // Touch the row even for participant-only edits so every successful edit advances its revision.
    const civilDates = canonicalUpdateDates(
      current,
      input,
      input.eventTimeZone ?? current.eventTimeZone ?? prefs.timeZone,
    );
    if (civilEndBeforeStart(civilDates))
      return err(
        new AppError(ERROR_IDS.ACTIVITY_END_BEFORE_START, "activity end is before its start", {
          id: current.id,
        }),
      );
    const patch = {
      ...buildPatch(input),
      ...civilDates,
      updatedAt: new Date(),
    };
    const [row] = await tx
      .update(activities)
      .set(patch)
      .where(eq(activities.id, input.id))
      .returning();
    if (row === undefined) {
      return err(new AppError(ERROR_IDS.DB_INSERT_FAILED, "activity update returned no rows", {}));
    }

    await reconcileGuestsAndParticipants(tx, row.id, input);

    // Recompute next_activity for the new deal AND the previous one when the link moved.
    const affectedDeals = new Set<string>();
    if (row.dealId !== null) affectedDeals.add(row.dealId);
    if (current.dealId !== null && current.dealId !== row.dealId) affectedDeals.add(current.dealId);
    await recomputeDealsActivityDates(tx, affectedDeals, signal);

    const reminders = await applyActivityReminders(tx, actor, row, input.personalReminders, signal);
    if (!reminders.ok) return reminders;
    return ok(row);
  });
}

// Re-linking to a NEW deal cannot target an archived deal (mirrors createActivity's guard).
async function assertRelinkDealNotArchived(
  tx: DbOrTx,
  current: Activity,
  input: ParsedUpdate,
  signal: AbortSignal,
): Promise<Result<undefined, AppError>> {
  if (input.dealId == null || input.dealId === current.dealId) return ok(undefined);
  const [dealRow] = await tx
    .select({ archivedAt: deals.archivedAt })
    .from(deals)
    .where(eq(deals.id, input.dealId));
  signal.throwIfAborted();
  if (dealRow?.archivedAt != null) {
    return err(
      new AppError(
        ERROR_IDS.DEAL_ARCHIVED_NO_ACTIVITY,
        "Cannot add an activity to an archived deal",
        { dealId: input.dealId },
      ),
    );
  }
  return ok(undefined);
}

// Guest/participant sets replace wholesale when provided; an omitted key leaves the set untouched.
async function reconcileGuestsAndParticipants(
  tx: DbOrTx,
  activityId: string,
  input: ParsedUpdate,
): Promise<void> {
  if (input.guestPersonIds !== undefined) {
    await tx.delete(activityGuests).where(eq(activityGuests.activityId, activityId));
    if (input.guestPersonIds.length > 0) {
      await tx
        .insert(activityGuests)
        .values(input.guestPersonIds.map((personId) => ({ activityId, personId })));
    }
  }
  if (input.participantUserIds !== undefined) {
    await tx.delete(activityParticipants).where(eq(activityParticipants.activityId, activityId));
    if (input.participantUserIds.length > 0) {
      await tx
        .insert(activityParticipants)
        .values(input.participantUserIds.map((userId) => ({ activityId, userId })));
    }
  }
}
