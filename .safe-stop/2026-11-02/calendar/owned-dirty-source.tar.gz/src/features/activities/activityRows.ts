import { and, asc, desc, eq, isNull, type SQL, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import type { VisibilityLevel } from "@/constants/visibility";
import type { Db } from "@/db/client";
import { activities, activityTypes, users } from "@/db/schema";
import { deals } from "@/db/schema/deals";
import { leads } from "@/db/schema/leads";
import { organizations } from "@/db/schema/organizations";
import { persons } from "@/db/schema/persons";
import { pipelines } from "@/db/schema/pipelines";
import { canSee } from "@/features/permissions/canSee";
import type { PermSetUser } from "@/features/permissions/effective";
import { addCivilDays } from "@/lib/zonedDateTime";
import { assertNever } from "@/types/result";
import { activityDueDaySql } from "./activityDateSql";
import { buildActivityVisibility } from "./activityVisibility";
import { loadCalendarAccess } from "./calendarAccess";
import { linkedParentVisible } from "./parentLinkVisibility";
import type { ActivityListFilter, ActivitySort, ActivitySortField } from "./schemas";
import { loadParentlessParticipants } from "./visibility";

// Two aliases of `users` so a single query can join both the assignee and the owner by name
// (a row's assigneeId and ownerId can reference different users).
const assigneeUser = alias(users, "assignee_user");
const ownerUser = alias(users, "owner_user");

// A fully-populated activities-table row (Pipedrive columns). dueAt is an ISO string so it can
// cross the server/client boundary.
export interface ActivityTableRow {
  id: string;
  subject: string;
  typeKey: string;
  priority: string | null;
  done: boolean;
  dueAtIso: string | null;
  endAtIso?: string | null;
  // No time was set; the list shows a date only.
  allDay: boolean;
  dueDate?: string | null;
  endDate?: string | null;
  durationMinutes: number | null;
  location: string | null;
  assigneeId: string;
  assigneeName: string;
  ownerName: string;
  dealId: string | null;
  dealTitle: string | null;
  leadId: string | null;
  leadTitle: string | null;
  personId: string | null;
  personName: string | null;
  personEmail: string | null;
  personPhone: string | null;
  orgId: string | null;
  orgName: string | null;
}

// Structural contact-point shape (persons.phones jsonb) to avoid a nominal type-import mismatch.
type Point = { value: string; primary?: boolean };

function primaryPoint(points: Point[] | null): string | null {
  if (points === null || points.length === 0) return null;
  return (points.find((p) => p.primary === true) ?? points[0])?.value ?? null;
}

interface LinkGateColumns {
  leadVisibleId: string | null;
  leadOwnerId: string | null;
  leadLevel: VisibilityLevel | null;
  leadGroupId: string | null;
  leadVisibleTo: string[] | null;
  personVisibleId: string | null;
  personOwnerId: string | null;
  personLevel: VisibilityLevel | null;
  personGroupId: string | null;
  personVisibleTo: string[] | null;
  orgVisibleId: string | null;
  orgOwnerId: string | null;
  orgLevel: VisibilityLevel | null;
  orgGroupId: string | null;
  orgVisibleTo: string[] | null;
}

interface LinkGates {
  leadOk: boolean;
  personOk: boolean;
  orgOk: boolean;
}

function linkGates(actor: PermSetUser, row: LinkGateColumns): LinkGates {
  return {
    leadOk: linkedParentVisible(actor, "lead", row.leadVisibleId, {
      ownerId: row.leadOwnerId,
      level: row.leadLevel,
      groupId: row.leadGroupId,
      visibleTo: row.leadVisibleTo,
    }),
    personOk: linkedParentVisible(actor, "person", row.personVisibleId, {
      ownerId: row.personOwnerId,
      level: row.personLevel,
      groupId: row.personGroupId,
      visibleTo: row.personVisibleTo,
    }),
    orgOk: linkedParentVisible(actor, "organization", row.orgVisibleId, {
      ownerId: row.orgOwnerId,
      level: row.orgLevel,
      groupId: row.orgGroupId,
      visibleTo: row.orgVisibleTo,
    }),
  };
}

// Map a sort field to its ORDER BY column. subject is NOT NULL; dueAt/priority/duration rely on
// Postgres's default null placement (NULLS LAST on ASC, NULLS FIRST on DESC), which matches the
// brief's "due_at NULLS LAST" default for the (also ASC) fallback sort.
function activitySortColumn(field: ActivitySortField): SQL {
  switch (field) {
    case "subject":
      return sql`${activities.subject}`;
    case "dueAtIso":
      return sql`${activities.dueAt}`;
    case "priority":
      return sql`${activities.priority}`;
    case "duration":
      return sql`${activities.durationMinutes}`;
    default:
      return assertNever(field);
  }
}

// Visible activities enriched with deal/org/contact detail + priority for the Activities table.
// Parent visibility columns are pulled in the same joined query (soft-deleted parents are excluded
// by the join predicate), and parentless-activity participants are fetched in one batched query, so
// visibility resolves in memory (buildActivityVisibility) with no per-row round-trips. This mirrors
// the audited resolver's dominant-parent precedence, so list and calendar never disagree.
// Build the WHERE predicate list from the list filter, always anchored on the not-deleted guard.
// ownerId narrows by assigneeId: Pipedrive's Activities "Owner" filter is really the assigned
// user, not activities.ownerId (which just tracks who created the row).
function activityFilterPredicates(filter: ActivityListFilter, timeZone: string): SQL[] {
  const preds: SQL[] = [isNull(activities.deletedAt)];
  if (filter.ownerId !== null) preds.push(eq(activities.assigneeId, filter.ownerId));
  if (filter.done === "open") preds.push(eq(activities.done, false));
  else if (filter.done === "done") preds.push(eq(activities.done, true));
  if (filter.from !== null) preds.push(sql`${activityDueDaySql(timeZone)} >= ${filter.from}`);
  if (filter.to !== null)
    preds.push(sql`${activityDueDaySql(timeZone)} < ${addCivilDays(filter.to, 1)}`);
  if (filter.typeKey !== null) preds.push(eq(activityTypes.key, filter.typeKey));
  return preds;
}

export async function listActivityRows(
  db: Db,
  actor: PermSetUser,
  filter: ActivityListFilter,
  signal: AbortSignal,
  sort?: ActivitySort,
  timeZone = "UTC",
): Promise<ActivityTableRow[]> {
  signal.throwIfAborted();
  // No explicit sort: due date ascending (Postgres default places NULLs last on ASC), id as a
  // stable tiebreaker so pagination-free clients still get a deterministic row order.
  const direction = sort === undefined || sort.dir === "asc" ? asc : desc;
  const orderColumn =
    sort === undefined ? sql`${activities.dueAt}` : activitySortColumn(sort.field);
  const rows = await db
    .select({
      id: activities.id,
      subject: activities.subject,
      dueAt: activities.dueAt,
      endAt: activities.endAt,
      allDay: activities.allDay,
      dueDate: activities.dueDate,
      endDate: activities.endDate,
      done: activities.done,
      durationMinutes: activities.durationMinutes,
      location: activities.location,
      assigneeId: activities.assigneeId,
      assigneeName: assigneeUser.name,
      ownerName: ownerUser.name,
      typeKey: activityTypes.key,
      priority: activities.priority,
      dealId: activities.dealId,
      personId: activities.personId,
      orgId: activities.orgId,
      dealTitle: deals.title,
      leadVisibleId: leads.id,
      leadTitle: leads.title,
      leadOwnerId: leads.ownerId,
      leadLevel: leads.visibilityLevel,
      leadGroupId: leads.visibilityGroupId,
      leadVisibleTo: leads.visibleToUserIds,
      dealOwnerId: deals.ownerId,
      dealLevel: deals.visibilityLevel,
      dealGroupId: deals.visibilityGroupId,
      dealVisibleTo: deals.visibleToUserIds,
      pipelineVg: pipelines.visibilityGroupId,
      pipelineArchived: pipelines.isArchived,
      personVisibleId: persons.id,
      orgVisibleId: organizations.id,
      personName: persons.name,
      personEmail: persons.primaryEmail,
      personPhones: persons.phones,
      personOwnerId: persons.ownerId,
      personLevel: persons.visibilityLevel,
      personGroupId: persons.visibilityGroupId,
      personVisibleTo: persons.visibleToUserIds,
      orgName: organizations.name,
      orgOwnerId: organizations.ownerId,
      orgLevel: organizations.visibilityLevel,
      orgGroupId: organizations.visibilityGroupId,
      orgVisibleTo: organizations.visibleToUserIds,
    })
    .from(activities)
    .innerJoin(activityTypes, eq(activities.typeId, activityTypes.id))
    .leftJoin(deals, and(eq(deals.id, activities.dealId), isNull(deals.deletedAt)))
    .leftJoin(pipelines, eq(pipelines.id, deals.pipelineId))
    .leftJoin(leads, and(eq(leads.id, activities.leadId), isNull(leads.deletedAt)))
    .leftJoin(persons, and(eq(persons.id, activities.personId), isNull(persons.deletedAt)))
    .leftJoin(
      organizations,
      and(eq(organizations.id, activities.orgId), isNull(organizations.deletedAt)),
    )
    .leftJoin(assigneeUser, eq(assigneeUser.id, activities.assigneeId))
    .leftJoin(ownerUser, eq(ownerUser.id, activities.ownerId))
    .where(and(...activityFilterPredicates(filter, timeZone)))
    // Stable server ORDER BY so this pagination-free list is deterministic across calls: the
    // requested (or default due-date) column, then id as a tiebreaker for equal sort keys.
    .orderBy(direction(orderColumn), asc(activities.id));
  signal.throwIfAborted();

  const participantsByActivity = await loadParentlessParticipants(db, rows, signal);
  const calendarAccess = await loadCalendarAccess(
    db,
    actor,
    rows.map((row) => row.id),
    signal,
  );

  const out: ActivityTableRow[] = [];
  for (const row of rows) {
    const vis = buildActivityVisibility(row, participantsByActivity.get(row.id) ?? []);
    if (vis === null || !canSee(actor, vis) || calendarAccess.get(row.id)?.read === false) continue;
    out.push(toTableRow(row, linkGates(actor, row)));
  }
  return out;
}

type JoinedRow = LinkGateColumns & {
  id: string;
  subject: string;
  typeKey: string;
  priority: string | null;
  done: boolean;
  dueAt: Date | null;
  endAt?: Date | null;
  allDay: boolean;
  dueDate?: string | null;
  endDate?: string | null;
  durationMinutes: number | null;
  location: string | null;
  assigneeId: string;
  assigneeName: string | null;
  ownerName: string | null;
  dealId: string | null;
  dealTitle: string | null;
  leadTitle: string | null;
  personName: string | null;
  personEmail: string | null;
  personPhones: Point[] | null;
  orgName: string | null;
};

function toTableRow(row: JoinedRow, gates: LinkGates): ActivityTableRow {
  return {
    id: row.id,
    subject: row.subject,
    typeKey: row.typeKey,
    priority: row.priority,
    done: row.done,
    dueAtIso: row.dueAt === null ? null : row.dueAt.toISOString(),
    endAtIso: row.endAt?.toISOString() ?? null,
    allDay: row.allDay,
    dueDate: row.dueDate,
    endDate: row.endDate,
    durationMinutes: row.durationMinutes,
    location: row.location,
    assigneeId: row.assigneeId,
    assigneeName: row.assigneeName ?? "",
    ownerName: row.ownerName ?? "",
    dealId: row.dealId,
    dealTitle: row.dealTitle,
    leadId: gates.leadOk ? row.leadVisibleId : null,
    leadTitle: gates.leadOk ? row.leadTitle : null,
    personId: gates.personOk ? row.personVisibleId : null,
    personName: gates.personOk ? row.personName : null,
    personEmail: gates.personOk ? row.personEmail : null,
    personPhone: gates.personOk ? primaryPoint(row.personPhones) : null,
    orgId: gates.orgOk ? row.orgVisibleId : null,
    orgName: gates.orgOk ? row.orgName : null,
  };
}
