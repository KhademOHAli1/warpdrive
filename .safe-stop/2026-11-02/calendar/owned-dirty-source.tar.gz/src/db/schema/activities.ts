import { sql } from "drizzle-orm";
import {
  boolean,
  check,
  date,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { activityTypes } from "./activityTypes";
import { calendars } from "./calendars";
import { deals } from "./deals";
import { users } from "./identity";
import { leads } from "./leads";
import { organizations } from "./organizations";
import { persons } from "./persons";

export const activities = pgTable(
  "activities",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    typeId: uuid("type_id")
      .notNull()
      .references(() => activityTypes.id),
    subject: text("subject").notNull(),
    // A database trigger advances this for every writer, including older composers and imports.
    version: integer("version").notNull().default(1),
    eventTimeZone: text("event_time_zone"),
    calendarId: uuid("calendar_id").references(() => calendars.id),
    eventVisibility: text("event_visibility")
      .$type<"default" | "private">()
      .notNull()
      .default("default"),
    availability: text("availability").$type<"busy" | "free">().notNull().default("busy"),
    dueAt: timestamp("due_at", { withTimezone: true }),
    // No chosen clock time. New/date-edited rows use due_date/end_date as canonical
    // civil dates; due_at/end_at remain compatibility anchors. Null dates denote legacy.
    allDay: boolean("all_day").notNull().default(false),
    // Canonical Gregorian civil dates for new/date-edited all-day records; null denotes legacy.
    dueDate: date("due_date"),
    endDate: date("end_date"),
    // Multi-day parity (Pipedrive): an explicit end timestamp for activities that span
    // more than a single day. Null for same-day activities (their span, if any, is the
    // start/end time captured as durationMinutes). Ordering (endAt >= dueAt) is enforced
    // in the create/update repo, not by a DB check, so a bad payload returns an AppError.
    endAt: timestamp("end_at", { withTimezone: true }),
    durationMinutes: integer("duration_minutes"),
    // Optional priority (Pipedrive Low/Medium/High); null = unset. Key resolved to name+color in UI.
    priority: text("priority"),
    // Old writers retain their delivery authority until an explicit engine takeover.
    reminderEngine: text("reminder_engine")
      .$type<"legacy" | "intent">()
      .notNull()
      .default("legacy"),
    reminderAutomationEnabled: boolean("reminder_automation_enabled").notNull().default(true),
    // Semantic schedule edits authorize late reminders; unrelated shared edits do not.
    reminderAuthoredAt: timestamp("reminder_authored_at", { withTimezone: true })
      .notNull()
      .default(sql`clock_timestamp()`),
    done: boolean("done").notNull().default(false),
    doneAt: timestamp("done_at", { withTimezone: true }),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id),
    assigneeId: uuid("assignee_id")
      .notNull()
      .references(() => users.id),
    // Nullable links: an activity may attach to a deal, person, and/or org.
    dealId: uuid("deal_id").references(() => deals.id),
    // A lead-scoped activity (Leads Inbox timeline). Mutually exclusive with dealId
    // (a row links at most one primary parent), enforced by the check below.
    leadId: uuid("lead_id").references(() => leads.id),
    personId: uuid("person_id").references(() => persons.id),
    orgId: uuid("org_id").references(() => organizations.id),
    customFields: jsonb("custom_fields").notNull().default(sql`'{}'::jsonb`),
    // Pipedrive parity: free-text location and a rich-text note (sanitized HTML).
    location: text("location"),
    note: text("note"),
    // Pipedrive parity (B3): a generated token-based video-call link (plain URL string; no
    // external Meet/Zoom OAuth). Null when the activity has no video call.
    videoCallUrl: text("video_call_url"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => [
    // Index: assignee's to-do list, sorted by completion + due date.
    index("activity_assignee_idx").on(t.assigneeId, t.done, t.dueAt),
    index("activity_calendar_idx").on(t.calendarId, t.dueAt),
    check("activity_event_visibility", sql`${t.eventVisibility} in ('default','private')`),
    check("activity_availability", sql`${t.availability} in ('busy','free')`),
    check("activity_reminder_engine", sql`${t.reminderEngine} in ('legacy','intent')`),
    // Index: FK lookups by linked record.
    index("activity_deal_idx").on(t.dealId),
    index("activity_lead_idx").on(t.leadId),
    index("activity_person_idx").on(t.personId),
    index("activity_org_idx").on(t.orgId),
    // Partial: due reminders only consider open (not-done) activities.
    index("activity_reminder_idx").on(t.dueAt).where(sql`done = false`),
    // A row links at most one primary parent (deal XOR lead, or neither).
    check("activity_single_parent", sql`num_nonnulls(${t.dealId}, ${t.leadId}) <= 1`),
  ],
);

export type Activity = typeof activities.$inferSelect;
export type NewActivity = typeof activities.$inferInsert;
